const ds = window.location.hostname === "localhost" ? null : window.ds;

export const getInStatementArray = (values) => {
  if (window.location.hostname === "localhost") {
    // Localhost logic
    if (values && values.length > 0) {
      return `{'` + values.join(`', '`) + `'}`;
    } else {
      return "{}";
    }
  } else {
    // Production logic
    if (values && values.length > 0) {
      return ds.getInStatement(values);
    } else {
      return ds.getInStatement([]);
    }
  }
};
