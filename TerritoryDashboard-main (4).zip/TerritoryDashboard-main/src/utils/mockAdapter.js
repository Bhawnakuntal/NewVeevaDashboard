// MockAdapter.js - Simple mock data provider for local development

import CateData from "../data/CategoryShare.json";
import RegionAvg from "../data/RegionAvg.json";
import suggestions from "../data/suggestion.json";
import User from "../data/User.json";
import elyeaData from "../data/EyleaHDUnits.json";
import PortfolioData from "../data/PortfolioComposition.json";
import callData from "../data/engagementData.json";
import UserTerLink from "../data/Ter2Association.json";
import expandedEnagement from "../data/expEngagementData.json";
import account22 from "../data/Account.json";
import event11 from "../data/Events.json";
import territory2 from "../data/Territory.json";

// Simple mock adapter - just returns the mock data
const mockAdapter = {
  // Simulates ds.runQuery - returns mock data based on object name
  runQuery: (queryConfig) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const { object } = queryConfig;

        // Map object names to their mock data
        const dataMap = {
          User: User,
          Account: account22,
          Suggestion_vod__c: suggestions,
          UserTerritory2Association: UserTerLink,
          Territory2: territory2,
          REG_HCOTerritoryDetail__c: elyeaData,
          REG_Territory_Portfolio_Composition__c: PortfolioData,
          REG_RegionalAverage__c: RegionAvg,
          REG_Territory_Omnichannel_Engagements__c: callData,
          REG_Territory_Omnichannel_Eng_Expansion__c: expandedEnagement,
          REG_Territory_Category_Share__c: CateData,
          Medical_Event_vod__c: event11,
        };

        // Return the data for the requested object
        const data = dataMap[object] || [];
        resolve({ data });
      }, 100);
    });
  },

  // Simulates ds.getDataForCurrentObject - returns mock user
  getDataForCurrentObject: () => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          User: {
            Id: "005360000035yy0AAA",
          },
        });
      }, 100);
    });
  },
};

export default mockAdapter;
