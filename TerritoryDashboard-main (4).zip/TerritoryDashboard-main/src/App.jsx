import { useState, useContext, useRef } from "react";
import "./App.css";
import EyleaHDUnits from "./components/EyleaHDUnits";
import PortfolioComposition from "./components/PortfolioComposition";
import CategoryShare from "./components/C13WaVEGF";
import OmnichannelEngagements from "./components/OmnichannelEngagements";
import News from "./components/News";
import AllVeevaInsights from "./components/AllVeevaInsights";
import UpcomingEvents from "./components/UpcomingEvents";
import LocationOrdering from "./components/LocationOrdering";
import { DataContext } from "./Context/DataCenter";
import ParentFilter from "./components/ParentFilter";
// import "@fontsource/open-sans";
function App() {
  const [expandedComponent, setExpandedComponent] = useState(null);
  const { feedbackData, feedbackData1, testData } = useContext(DataContext);
  const componentRefs = {
    EyleaHDUnits: useRef(null),
    AllVeevaInsights: useRef(null),
    UpcomingEvents: useRef(null),
    OmnichannelEngagements: useRef(null),
  };

  const handleExpand = (component) => {
    setExpandedComponent(expandedComponent === component ? null : component);
    setTimeout(() => {
      if (componentRefs[component]?.current) {
        componentRefs[component].current.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }
    }, 100); // Adding a small delay to ensure the expanded state has been set before scrolling
  };

  return (
    <div className="w-full p-2 h-[92vh] flex flex-col">
      {/* Unexpanded View */}
      {!expandedComponent && (
        <div className="grid grid-cols-3 gap-2 mb-0 pb-0">
          {/* First Column */}
          <div className="col-span-1 ">
            <EyleaHDUnits
              onExpand={() => handleExpand("EyleaHDUnits")}
              expanded={false}
            />
            <LocationOrdering />
            <PortfolioComposition />
          </div>

          {/* Second Column */}
          <div className="col-span-1 ">
            <CategoryShare />
            <AllVeevaInsights
              onExpand={() => handleExpand("AllVeevaInsights")}
              expanded={false}
            />
          </div>

          {/* Third Column */}
          <div className="col-span-1 ">
            <div className="flex flex-row justify-between">
              <News />
              <ParentFilter />
            </div>
            <UpcomingEvents
              onExpand={() => handleExpand("UpcomingEvents")}
              expanded={false}
            />
            <OmnichannelEngagements
              onExpand={() => handleExpand("OmnichannelEngagements")}
              expanded={false}
            />
          </div>
        </div>
      )}

      {/* Expanded EyleaHDUnits */}
      {expandedComponent === "EyleaHDUnits" && (
        <div className="w-full h-full">
          <EyleaHDUnits
            onExpand={() => handleExpand("EyleaHDUnits")}
            expanded={true}
          />
          {/* Display the rest of the components below the expanded EyleaHD */}
          <div className="grid grid-cols-3 gap-2 mt-">
            <div className="col-span-1">
              <PortfolioComposition />
            </div>
            <div className="col-span-1">
              <CategoryShare />
              <AllVeevaInsights
                onExpand={() => handleExpand("AllVeevaInsights")}
                expanded={false}
              />
            </div>
            <div className="col-span-1">
              <div className="flex flex-row justify-between">
                <News />
                <ParentFilter />
              </div>
              <UpcomingEvents
                onExpand={() => handleExpand("UpcomingEvents")}
                expanded={false}
              />
              <OmnichannelEngagements
                onExpand={() => handleExpand("OmnichannelEngagements")}
                expanded={false}
              />
            </div>
          </div>
        </div>
      )}

      {/* Expanded OmnichannelEngagements */}
      {expandedComponent === "OmnichannelEngagements" && (
        <div className="w-full h-full">
          {/* Components Above OmnichannelEngagements */}
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-1">
              <EyleaHDUnits
                onExpand={() => handleExpand("EyleaHDUnits")}
                expanded={false}
              />
              <LocationOrdering />
            </div>
            <div className="col-span-1">
              <CategoryShare />
            </div>
            <div className="col-span-1">
              <div className="flex flex-row justify-between">
                <News />
                <ParentFilter />
              </div>
              <UpcomingEvents
                onExpand={() => handleExpand("UpcomingEvents")}
                expanded={false}
              />
            </div>
          </div>

          {/* OmnichannelEngagements Component */}
          <OmnichannelEngagements
            onExpand={() => handleExpand("OmnichannelEngagements")}
            expanded={true}
          />

          {/* Components Below OmnichannelEngagements */}
          <div className="grid grid-cols-3 gap-2 mt-2 flex-grow">
            <div className="col-span-1">
              <PortfolioComposition />
            </div>
            <div className="col-span-1">
              <AllVeevaInsights
                onExpand={() => handleExpand("AllVeevaInsights")}
                expanded={false}
              />
            </div>
          </div>
        </div>
      )}

      {/* Expanded AllVeevaInsights or UpcomingEvents */}
      {(expandedComponent === "AllVeevaInsights" ||
        expandedComponent === "UpcomingEvents") && (
        <div className="flex flex-col w-full">
          <div className="grid grid-cols-3 gap-2 mb-0">
            <div className="col-span-1">
              <EyleaHDUnits
                onExpand={() => handleExpand("EyleaHDUnits")}
                expanded={false}
              />
              <LocationOrdering />
            </div>
            <div className="col-span-1">
              <CategoryShare />
            </div>
            <div className="col-span-1">
              <div className="flex flex-row justify-between">
                <News />
                <ParentFilter />
              </div>
              <UpcomingEvents onExpand={() => handleExpand("UpcomingEvents")} />
            </div>
          </div>

          <div className="w-full">
            {expandedComponent === "AllVeevaInsights" && (
              <AllVeevaInsights
                onExpand={() => handleExpand("AllVeevaInsights")}
                expanded={true}
              />
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 mt-">
            <div className="col-span-1">
              <PortfolioComposition />
            </div>
            <div className="col-span-1">
              {/* <OmnichannelEngagements onExpand={() => handleExpand('OmnichannelEngagements')} expanded={false} /> */}
            </div>
            <div className="col-span-1">
              <OmnichannelEngagements
                onExpand={() => handleExpand("OmnichannelEngagements")}
                expanded={false}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
