import React, { useContext } from "react";
import { DataContext } from "../Context/DataCenter"; // Assuming your context is in a file called DataContext

const ParentFilter = () => {
  const { timePeriod, setTimePeriod } = useContext(DataContext); // Access context state

  // Toggle handler
  const toggleTimePeriod = () => {
    setTimePeriod((prev) => (prev === "QTD" ? "C13W" : "QTD"));
  };

  return (
    <div
      className="flex flex-col mb-2 items-center justify-start border-1 rounded-lg px-2 mx-1 h-[16vh] bg-white w-[160px] shadow"
      onClick={toggleTimePeriod}
    >
      <div className="font-bold text-[0.9375rem] text-center w-full text-[#44546A] mt-2 mb-0">
        Time Period
      </div>
      <div className="flex flex-col items-center">
        <span
          className={`text-[.625rem]  mb-1 lg:text-[.75rem] ${timePeriod === "QTD" ? "font-semibold" : ""}`}
        >
          QTD v PFQ
        </span>

        {/* Vertical toggle switch */}
        <div
          className="relative w-4 h-8 mb-1 rounded-full bg-gray-300 cursor-pointer flex flex-col items-center"
          style={{
            justifyContent: timePeriod === "QTD" ? "flex-start" : "flex-end",
            padding: "2px",
          }}
        >
          <div className="w-3 h-4 bg-white  rounded-full shadow"></div>
        </div>

        <span
          className={`text-[.625rem] my-1 lg:text-[.75rem] ${timePeriod === "C13W" ? "font-semibold" : ""}`}
        >
          C13W v P13W
        </span>
      </div>
    </div>
  );
};

export default ParentFilter;
