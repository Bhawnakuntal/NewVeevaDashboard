import React, { useState, useEffect, useContext } from "react";
import { FaExpandAlt, FaSort, FaSortUp, FaSortDown } from "react-icons/fa";
import { DataContext } from "../Context/DataCenter";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";

const EyleaDataView = ({ onExpand, expanded }) => {
  const {
    elyea,
    timePeriod,
    account,
    loadingStates,
    dataLoaded,
    tcErrorState,
  } = useContext(DataContext);
  const [data, setData] = useState([]);
  const [tableVisible, setTableVisible] = useState(false);
  const [selectedTab, setSelectedTab] = useState("All HCOs");
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const [showTooltip, setShowTooltip] = useState(false);

  // Conditionally use fields based on timePeriod (QTD or C13W)
  const isQTD = timePeriod === "QTD";

  const volumeField = isQTD ? "REG_QTD__c" : "REG_C13W_Volume__c";
  const pField = isQTD ? "REG_PFQ__c" : "REG_P13W_Volume__c";
  const growthField = isQTD
    ? "REG_PerGrowthQTDvsPFQ__c"
    : "REG_PerGrowthC13WvsP13W__c";

  const volGrowthField = isQTD
    ? "REG_VolGrowthQTDvsPFQ__c"
    : "REG_VolGrowthC13WvsP13W__c";
  const perGrowthField = isQTD
    ? "REG_PerGrowthQTDvsPFQ__c"
    : "REG_PerGrowthC13WvsP13W__c";

  // Additional fields for PFQ calculations
  const pfqField = "REG_PFQ__c";
  const pfqMinus1Field = "REG_PFQ_Minus_1__c";
  const pfqMinus2Field = "REG_PFQ_Minus_2__c";

  //Tooltip date
  // Get today's date
  const today = new Date();
  // Get the last Sunday
  const lastSunday = new Date(today);
  lastSunday.setDate(today.getDate() - today.getDay()); // Adjust to last Sunday
  // If today is Sunday (0) or Monday (1), or Tuesday(2) take the previous Sunday
  if (today.getDay() < 3) {
    lastSunday.setDate(lastSunday.getDate() - 7);
  }
  // Format date as "MMM D YYYY" (e.g., "FEB 16 2025")
  const formattedDate = lastSunday
    .toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
    .toUpperCase()
    .replace(",", ""); // Remove comma
  // console.log(formattedDate);

  useEffect(() => {
    const filteredByTerritory = elyea.filter(
      (item) =>
        item.REG_ProductName__c?.value === "EYLEA HD" &&
        item.REG_ProductType__c?.value === "all"
    );

    // console.log(filteredByTerritory);
    setData(filteredByTerritory);
  }, [elyea]);

  useEffect(() => {
    if (!expanded) {
      setTableVisible(false);
    } else {
      setTableVisible(true);
    }
  }, [expanded]);

  useEffect(() => {
    if (selectedTab === "Growing") {
      setSortConfig({ key: growthField, direction: "desc" });
    } else if (selectedTab === "Declining") {
      setSortConfig({ key: growthField, direction: "asc" });
    } else if (selectedTab === "Ordering this") {
      setSortConfig({ key: volumeField, direction: "desc" });
    } else if (selectedTab === "First Time Orders") {
      setSortConfig({ key: volumeField, direction: "desc" });
    } else if (selectedTab === "Lapsed") {
      setSortConfig({ key: volumeField, direction: "asc" });
    } else {
      setSortConfig({ key: null, direction: "asc" });
    }
  }, [selectedTab, growthField, volumeField]);

  // Key metrics calculations - independent of timePeriod filter
  const p13wVolume = data.reduce(
    (sum, item) => sum + (item.REG_P13W_Volume__c?.value || 0),
    0
  );
  const c13wVolume = data.reduce(
    (sum, item) => sum + (item.REG_C13W_Volume__c?.value || 0),
    0
  );
  const qtdVolume = data.reduce(
    (sum, item) => sum + (item.REG_QTD__c?.value || 0),
    0
  );
  const pqtdVolume = data.reduce(
    (sum, item) => sum + (item.REG_PQTD__c?.value || 0),
    0
  );
  const growthQtdVsPqtd = pqtdVolume
    ? ((qtdVolume - pqtdVolume) / pqtdVolume) * 100
    : 0;

  const getValue = (value) => {
    if (value === null || value === undefined || value === "") return "N/A";
    if (typeof value === "boolean") return value ? "true" : "false";
    if (typeof value === "number") return value.toFixed(0);
    if (typeof value === "object" && value instanceof Date)
      return value.toISOString().split("T")[0];
    return value;
  };

  // Helper function to get the ordinal suffix for a day
  const formatDate = (date) => {
    // Return empty string if date is null, undefined, or empty
    if (!date) return "";
    if (!(date instanceof Date)) {
      date = new Date(date);
    }
    // Get month, day, and year
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const year = String(date.getFullYear()).slice(-2);
    return `${month}/${day}/${year}`;
  };

  const handleExpandClick = () => {
    if (expanded) {
      setTableVisible(false);
      onExpand();
    } else {
      setTableVisible(true);
      onExpand();
    }
  };

  const handleSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const sortedData = () => {
    let sortableData = [...filteredData()]; // Clone the filtered data
    if (sortConfig.key) {
      sortableData.sort((a, b) => {
        const aValue = a[sortConfig.key]?.value ?? "";
        const bValue = b[sortConfig.key]?.value ?? "";
        // Special case for date sorting
        if (sortConfig.key === "REG_Date_of_last_Order__c") {
          const aDate = new Date(aValue);
          const bDate = new Date(bValue);
          return sortConfig.direction === "asc" ? aDate - bDate : bDate - aDate;
        }
        // Handle numeric fields
        const aNum = parseFloat(aValue);
        const bNum = parseFloat(bValue);
        if (!isNaN(aNum) && !isNaN(bNum)) {
          return sortConfig.direction === "asc" ? aNum - bNum : bNum - aNum;
        }
        const aStr = String(aValue).toLowerCase();
        const bStr = String(bValue).toLowerCase();
        if (aStr < bStr) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (aStr > bStr) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }

        return 0; // Equal values
      });
    }
    return sortableData;
  };

  // Apply tab-specific filters
  const filteredData = () => {
    switch (selectedTab) {
      case "All HCOs":
        return data; // No filtering
      case "Ordering this":
        return data.filter((item) => item[volumeField]?.value > 0); // Current ordering
      case "First Time Orders":
        return data.filter((item) => item[volumeField]?.value === 1); // First time ordering
      case "Lapsed":
        return data.filter(
          (item) => item[volumeField]?.value === 0 && item[pField]?.value > 0
        ); // Lapsed
      case "Growing":
        return data.filter((item) => item[growthField]?.value > 0); // Growing based on percentage growth
      case "Declining":
        return data.filter((item) => item[growthField]?.value < 0); // Declining based on percentage growth
      default:
        return data;
    }
  };

  const getQuarterLabel = (offset) => {
    const currentDate = new Date();
    let currentQuarter = Math.floor((currentDate.getMonth() + 3) / 3); // Determine the current quarter
    let currentYear = currentDate.getFullYear();

    // Adjust to the Previous Fiscal Quarter (PFQ)
    let PFQQuarter = currentQuarter - 1;
    let PFQYear = currentYear;
    if (PFQQuarter === 0) {
      PFQQuarter = 4;
      PFQYear -= 1;
    }

    // Calculate the desired quarter and year based on the offset
    let quarter = PFQQuarter - offset;
    let year = PFQYear;

    // Handle cases where the quarter goes below 1 (wrap around to previous years)
    while (quarter <= 0) {
      quarter += 4;
      year -= 1;
    }

    return `Q${quarter} ${year}`;
  };

  const getCurrentQuarterLabel = () => {
    const date = new Date();
    const year = date.getFullYear();
    const quarter = Math.ceil((date.getMonth() + 1) / 3); // Calculate quarter (1-4)
    return `Q${quarter} ${year}`;
  };

  function runViewRecordAcc(id) {
    // console.log(id);
    try {
      var configObject = {
        object: "Account",
        fields: { Id: id },
      };
      // eslint-disable-next-line
      ds.viewRecord(configObject).then(
        function (resp) {
          return resp;
        },
        function (err) {
          console.log(err);
        }
      );
    } catch (error) {
      let line = error.stack;
      //   setAccountFetchError(error, line);
    }
  }

  // console.log(sortedData());

  // Loading state - show spinner when data is being fetched
  if (loadingStates.elyea || !dataLoaded) {
    return (
      <div className="bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[21vh]">
        {/* Heading at the top */}
        <h3 className="font-bold text-[.9375rem] text-[#44546A] text-center mb-1">
          Total EYLEA HD Units
        </h3>

        {/* Spinner centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-[#44546A] text-sm">Loading data...</p>
        </div>
      </div>
    );
  }

  // Error state - if there's an error loading data
  if (tcErrorState && data.length === 0) {
    return (
      <div
        className={`bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[21vh] items-center justify-center`}
      >
        <h3 className="font-bold text-[.9375rem] mb-[.8rem] lg:mb-[0rem] text-[#44546A]">
          Total EYLEA HD Units
        </h3>
        <div className="flex flex-col items-center justify-center">
          <div className="text-4xl text-red-400 mb-2">⚠️</div>
          <p className="text-red-500 text-sm">Error loading data</p>
          <p className="text-gray-500 text-xs mt-1">
            Please try refreshing the page
          </p>
        </div>
      </div>
    );
  }

  // Empty state - show when no data is available
  if (data.length === 0 && dataLoaded) {
    return (
      <div
        className={`bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[21vh] items-center justify-center`}
      >
        <h3 className="font-bold text-[.9375rem] mb-[.8rem] lg:mb-[0rem] text-[#44546A]">
          Total EYLEA HD Units
        </h3>
        <div className="flex flex-col items-center justify-center">
          <div className="text-4xl text-gray-400 mb-2">📊</div>
          <p className="text-[#44546A] text-sm">No data available</p>
        </div>
      </div>
    );
  }

  // Main component return - only reached when data is loaded and available
  return (
    <div
      className={`bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col ${
        !expanded ? "w-full min-h-[21vh]" : "min-h-screen lg:min-h-[90vh]"
      }`}
    >
      {/* Eylea HD Units Section */}
      <div className="mt- mb-4 w-full">
        <div className="flex flex-row justify-between ">
          {/* Centered Title */}
          <div>
            {!expanded ? (
              <div className={`${expanded ? "" : ""}`}>
                <div className="inline-block text-left ">
                  {/* Tooltip Button */}
                  <button
                    type="button"
                    className="focus:outline-none"
                    onClick={() => setShowTooltip(!showTooltip)}
                  >
                    <InfoOutlinedIcon className="text-gray-600 text-[1.25rem]  right-0 top-0 ml-[-.3rem] mt-[-0.7rem]" />
                  </button>

                  {/* Tooltip Content */}
                  {showTooltip && (
                    <div className=" z-10 mt-2 w-56 bg-white border border-gray-300 absolute rounded shadow-lg">
                      <div className="px-2 py-2 text-sm text-gray-700">
                        Sales data through {formattedDate}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <></>
            )}
          </div>

          <h3 className="font-bold text-[.9375rem] mb-[.8rem] lg:mb-[0rem] text-[#44546A] text-center flex-grow">
            Total EYLEA HD Units
          </h3>
          <div>
            {expanded ? (
              <>
                <button
                  onClick={handleExpandClick}
                  className="cursor-pointer  text-[1.5rem]  right-0 top-0"
                >
                  ✕
                </button>
              </>
            ) : (
              <FaExpandAlt
                onClick={handleExpandClick}
                className="cursor-pointer text-[1.25rem] text-[#44546A]  right-0 top-0 mr-[-0.4rem] mt-[-.2rem]"
              />
            )}
          </div>
        </div>
        <div className="flex justify-around lg:mt-2">
          <div className="cursor-pointer">
            <div className="text-[#44546A] text-[1.25rem] font-bold text-center my-2">
              {p13wVolume.toLocaleString("en-US")}
            </div>
            <div className="text-[.9375rem] text-[#637077]">P13W</div>
          </div>
          <div className="cursor-pointer">
            <div className="text-[#44546A] text-[1.25rem] font-bold text-center my-2">
              {c13wVolume.toLocaleString("en-US")}{" "}
              <span style={{ fontSize: "12px" }}>
                (
                {c13wVolume === 0
                  ? "-100%"
                  : (((c13wVolume - p13wVolume) / p13wVolume) * 100).toFixed(1)}
                %)
              </span>
            </div>
            <div className="text-[.9375rem] text-[#637077]">C13W (v P13W)</div>
          </div>
          <div className="cursor-pointer">
            <div className="text-[#44546A] text-[1.25rem] my-2 font-bold text-center">
              {qtdVolume.toLocaleString("en-US")}{" "}
              <span style={{ fontSize: "12px" }}>
                ({growthQtdVsPqtd.toFixed(1)}%)
              </span>
            </div>
            <div className="text-[.9375rem] text-[#637077]">QTD (v PQTD)</div>
          </div>
        </div>
      </div>

      {/* Table and Tabs only when tableVisible is true */}
      {tableVisible && (
        <>
          {/* Tabs */}
          <div className="flex justify-center w-[90%] space-x-4 py-2">
            {[
              "All HCOs",
              "Ordering this",
              "Lapsed",
              "Growing",
              "Declining",
            ].map((tab) => (
              <span
                key={tab}
                onClick={() => setSelectedTab(tab)}
                className={`inline-block cursor-pointer text-[.9375rem] px-4 py-2 rounded-md transition-all 
        ${
          selectedTab === tab
            ? "bg-blue-500 text-white font-semibold shadow-md" // Selected tab
            : "bg-gray-100 text-gray-600 hover:bg-gray-300 hover:text-gray-800"
        }`}
              >
                {tab} {tab !== "All HCOs" && `[${timePeriod}]`}
              </span>
            ))}
          </div>
          <div className="mt-0 w-full">
            <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
              <table
                className="w-full border-collapse border border-gray-300"
                style={{ tableLayout: "fixed", width: "100%" }}
              >
                <colgroup>
                  <col style={{ width: "120px" }} />
                  <col style={{ width: "120px" }} />
                  <col style={{ width: "110px" }} />
                  <col style={{ width: "70px" }} />
                  <col style={{ width: "120px" }} />
                  <col style={{ width: "60px" }} />
                  <col style={{ width: "60px" }} />
                  <col style={{ width: "70px" }} />
                  <col style={{ width: "60px" }} />
                  <col style={{ width: "50px" }} />
                  <col style={{ width: "50px" }} />
                  <col style={{ width: "50px" }} />
                </colgroup>
                <thead className="sticky top-0 z-10">
                  {/* Main Section Headers */}
                  <tr className="bg-[#818791] text-white">
                    {/* Account Information - Always 6 columns */}
                    <th
                      colSpan={5}
                      className="border text-[.9375rem] text-center py-2"
                    >
                      Account Information
                    </th>

                    {/* EYLEA HD Ordering - Adjusted Dynamically */}
                    <th
                      colSpan={isQTD ? 7 : 5}
                      className="border text-center py-2 text-[.9375rem]"
                    >
                      EYLEA HD Ordering
                    </th>
                  </tr>

                  {/* Sub-Headers with Sort Icons */}
                  <tr className="bg-[#A1A9B4]">
                    {[
                      {
                        key: "REG_NavigatorAccountGroup__c",
                        label: "Navigator Account Group",
                      },
                      { key: "REG_AccountName__c", label: "Veeva HCO Name" },
                      { key: "REG_AccountAddress__c", label: "Address" },
                      {
                        key: "REG_Account_Eylea_Quintile__c",
                        label: "Account Eylea Quintile",
                      },
                      {
                        key: "REG_PE_if_Applicable__c",
                        label: "PE Applicable",
                      },
                      {
                        key: "REG_Date_of_last_Order__c",
                        label: "Date of Last Order",
                      },
                      {
                        key: perGrowthField,
                        label: `% Growth ${timePeriod} vs ${
                          isQTD ? "PFQ" : "P13W"
                        }`,
                      },
                      {
                        key: volGrowthField,
                        label: `Abs Growth ${timePeriod} vs ${
                          isQTD ? "PFQ" : "P13W"
                        }`,
                      },
                      ...(isQTD
                        ? [
                            { key: pfqMinus2Field, label: getQuarterLabel(2) },
                            { key: pfqMinus1Field, label: getQuarterLabel(1) },
                            { key: pfqField, label: getQuarterLabel(0) },
                          ]
                        : [{ key: "REG_P13W_Volume__c", label: "P13W" }]),
                      {
                        key: volumeField,
                        label:
                          timePeriod === "QTD"
                            ? getCurrentQuarterLabel()
                            : timePeriod,
                      },
                    ].map((column) => (
                      <th
                        key={column.key}
                        onClick={() => handleSort(column.key)}
                        style={{ whiteSpace: "normal", wordWrap: "break-word" }}
                        className="border px-1 py-4 bg-[#A1A9B4] text-white text-center text-[12px] font-medium cursor-pointer"
                      >
                        <span className="flex justify-center items-center">
                          {column.label}
                          {/* Conditionally render the sort icon */}
                          {sortConfig.key === column.key ? (
                            sortConfig.direction === "asc" ? (
                              <FaSortUp width="10" />
                            ) : (
                              <FaSortDown width="10" />
                            )
                          ) : (
                            <FaSort width="10" />
                          )}
                        </span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sortedData().map((item, index) => (
                    <tr
                      key={index}
                      className={`${
                        index % 2 === 0 ? "bg-[#F2F2F2]" : "bg-[#FFFFFF]"
                      } text-[#000]`}
                    >
                      <td className="border border-gray-300 px-2 py-1 text-[10px]">
                        {getValue(item.REG_NavigatorAccountGroup__c?.value)}
                      </td>
                      <td
                        className={`border border-gray-300 px-2 py-1 text-[10px] 
                          ${
                            account.some((acc) => {
                              return (
                                acc.Id.value === item.REG_Account__c?.value
                              );
                            })
                              ? "text-[#297cd4] cursor-pointer"
                              : "text-black"
                          }`}
                        onClick={() =>
                          runViewRecordAcc(item.REG_Account__c.value)
                        }
                      >
                        {getValue(item.REG_AccountName__c?.value)}
                      </td>

                      <td className="border border-gray-300 px-2 py-1 text-[10px]">
                        {getValue(item.REG_AccountAddress__c?.value)}
                      </td>
                      <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                        {getValue(item.REG_Account_Eylea_Quintile__c?.value)}
                      </td>
                      <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                        {item.REG_PE_if_Applicable__c?.value?.startsWith("PE_")
                          ? getValue(item.REG_PE_if_Applicable__c?.value)
                          : ""}
                      </td>
                      <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                        {formatDate(item.REG_Date_of_last_Order__c?.value)}
                      </td>

                      <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                        {parseFloat(item[perGrowthField]?.value || 0).toFixed(
                          1
                        )}{" "}
                        %
                      </td>
                      <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                        {getValue(item[volGrowthField]?.value)}
                      </td>
                      {isQTD ? (
                        <>
                          <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                            {getValue(
                              item[pfqMinus2Field]?.value
                            ).toLocaleString("en-US")}
                          </td>
                          <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                            {getValue(
                              item[pfqMinus1Field]?.value
                            ).toLocaleString("en-US")}
                          </td>
                          <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                            {getValue(item[pfqField]?.value).toLocaleString(
                              "en-US"
                            )}
                          </td>
                        </>
                      ) : (
                        <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                          {getValue(item.REG_P13W_Volume__c?.value)}
                        </td>
                      )}

                      <td className="border border-gray-300 px-2 py-1 text-[10px] text-center">
                        {getValue(item[volumeField]?.value)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default EyleaDataView;
