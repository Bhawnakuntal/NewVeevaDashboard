import React, { useState, useEffect, useContext, useRef } from "react";
import * as d3 from "d3";
import { DataContext } from "../Context/DataCenter";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";

const PortfolioComposition = () => {
  const [data, setData] = useState([]);
  const [isVolume, setIsVolume] = useState(true);
  const [chartsInitialized, setChartsInitialized] = useState(false);
  const {
    mergedPortfolio,
    timePeriod,
    loadingStates,
    dataLoaded,
    tcErrorState,
  } = useContext(DataContext);

  const [showTooltip, setShowTooltip] = useState(false);
  const totalChartRef = useRef(null);
  const quintileChartRef = useRef(null);

  const isQTD = timePeriod === "QTD";

  //Tooltip date
  const today = new Date();
  const lastSunday = new Date(today);
  lastSunday.setDate(today.getDate() - today.getDay());
  if (today.getDay() < 3) {
    lastSunday.setDate(lastSunday.getDate() - 7);
  }

  const formattedDate = lastSunday
    .toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
    .toUpperCase()
    .replace(",", "");

  useEffect(() => {
    if (mergedPortfolio) {
      setData(mergedPortfolio);
    }
  }, [mergedPortfolio]);

  // Chart rendering useEffect - FIXED with proper timing
  useEffect(() => {
    if (data.length === 0 || loadingStates.mergedPortfolio || !dataLoaded)
      return;

    // Use requestAnimationFrame to ensure DOM is ready
    const renderCharts = () => {
      if (!totalChartRef.current || !quintileChartRef.current) {
        // If refs aren't ready, try again on next frame
        requestAnimationFrame(renderCharts);
        return;
      }

      // 1) Total Chart Calculations
      const totalHDValue = data
        .filter((item) =>
          isVolume
            ? item.REG_Subject__c === "units"
            : item.REG_Subject__c === "BV"
        )
        .reduce((sum, item) => {
          const fieldValue =
            item[getFieldName("eyleaHD", isVolume ? "units" : "bv")];
          return fieldValue ? sum + parseValue(fieldValue.value) : sum;
        }, 0);

      const total2mgValue = data
        .filter((item) =>
          isVolume
            ? item.REG_Subject__c === "units"
            : item.REG_Subject__c === "BV"
        )
        .reduce((sum, item) => {
          const fieldValue =
            item[getFieldName("eylea2mg", isVolume ? "units" : "bv")];
          return fieldValue ? sum + parseValue(fieldValue.value) : sum;
        }, 0);

      const totalValue = totalHDValue + total2mgValue;
      const totalHDPercentage =
        totalValue > 0 ? (totalHDValue / totalValue) * 100 : 0;
      const total2mgPercentage =
        totalValue > 0 ? (total2mgValue / totalValue) * 100 : 0;

      // 2) Quintile Chart Calculations
      const quintiles = ["1", "2", "3", "4", "5"];

      const chartData = quintiles.map((qVal) => {
        const eyleaHDValue = data
          .filter((item) => {
            const isCorrectQuintile = item.REG_Quintile__c?.value === qVal;
            const isCorrectSubject = isVolume
              ? item.REG_Subject__c === "units"
              : item.REG_Subject__c === "BV";
            return isCorrectQuintile && isCorrectSubject;
          })
          .reduce((sum, item) => {
            const fieldValue =
              item[getFieldName("eyleaHD", isVolume ? "units" : "bv")];
            return fieldValue ? sum + parseValue(fieldValue.value) : sum;
          }, 0);

        const eylea2mgValue = data
          .filter((item) => {
            const isCorrectQuintile = item.REG_Quintile__c?.value === qVal;
            const isCorrectSubject = isVolume
              ? item.REG_Subject__c === "units"
              : item.REG_Subject__c === "BV";
            return isCorrectQuintile && isCorrectSubject;
          })
          .reduce((sum, item) => {
            const fieldValue =
              item[getFieldName("eylea2mg", isVolume ? "units" : "bv")];
            return fieldValue ? sum + parseValue(fieldValue.value) : sum;
          }, 0);

        const totalQuintileValue = eyleaHDValue + eylea2mgValue;

        const eyleaHDPercentage =
          totalQuintileValue > 0
            ? (eyleaHDValue / totalQuintileValue) * 100
            : 0;
        const eylea2mgPercentage =
          totalQuintileValue > 0
            ? (eylea2mgValue / totalQuintileValue) * 100
            : 0;

        return {
          quintileValue: qVal,
          quintileLabel: "Q" + qVal,
          "Eylea HD": eyleaHDPercentage,
          "Eylea 2mg": eylea2mgPercentage,
          totalHDValue: eyleaHDValue,
          total2mgValue: eylea2mgValue,
          totalQuintileValue,
        };
      });

      const maxTotalValue = Math.max(
        ...chartData.map((d) => d.totalQuintileValue)
      );

      // Draw the charts
      drawTotalChart(
        totalHDPercentage,
        total2mgPercentage,
        totalHDValue,
        total2mgValue,
        isVolume
      );
      drawQuintileChart(chartData, maxTotalValue, isVolume);

      setChartsInitialized(true);
    };

    // Start the rendering process
    requestAnimationFrame(renderCharts);
  }, [data, isVolume, timePeriod, loadingStates.mergedPortfolio, dataLoaded]);

  const parseValue = (value) => {
    const parsed = parseFloat(value);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Hardcoded field names for EYLEA 2mg and EYLEA HD
  const fieldMapping = {
    eyleaHD: {
      units: isQTD
        ? "REG_NoofEYLEAHDunitsinQTD__c"
        : "REG_NoofEYLEAHDunitsinC13W__c",
      bv: isQTD ? "REG_NoofEYLEAHDBVinQTD__c" : "REG_NoofEYLEAHDBVinC13W__c",
    },
    eylea2mg: {
      units: isQTD
        ? "REG_NoofEYLEA2mgunitsinQTD__c"
        : "REG_NoofEYLEA2mgunitsinC13W__c",
      bv: isQTD ? "REG_NoofEYLEA2mgBVinQTD__c" : "REG_NoofEYLEA2mgBVinC13W__c",
    },
  };

  const getFieldName = (product, type) => {
    return fieldMapping[product][type];
  };

  const drawTotalChart = (
    totalHDPercentage,
    total2mgPercentage,
    totalHDValue,
    total2mgValue,
    isVolume
  ) => {
    if (!totalChartRef.current) {
      // console.log("drawTotalChart: totalChartRef is null");
      return;
    }

    const svg = d3.select(totalChartRef.current);
    svg.selectAll("*").remove();

    const svgNode = svg.node();
    if (!svgNode) {
      // console.log("drawTotalChart: SVG node not found");
      return;
    }

    const width = svgNode.clientWidth || 400;
    const height = svgNode.clientHeight || 400;

    if (width === 0 || height === 0) {
      // console.log("drawTotalChart: SVG has zero dimensions", width, height);
      return;
    }

    // console.log("drawTotalChart: Drawing with dimensions", width, height);

    const margin = { top: 10, right: 20, bottom: 30, left: 20 };

    const totalXScale = d3
      .scaleBand()
      .domain(["Total"])
      .range([margin.left, width - margin.right])
      .padding(0.4);

    const totalYScale = d3
      .scaleLinear()
      .domain([0, 100])
      .range([height - margin.bottom, margin.top]);

    // **Tooltip Setup (Ensure It Exists)**
    let tooltip = d3.select("body").select(".tooltip");
    if (tooltip.empty()) {
      tooltip = d3
        .select("body")
        .append("div")
        .attr("class", "tooltip")
        .style("position", "absolute")
        .style("background", "#fff")
        .style("color", "black")
        .style("padding", "6px 10px")
        .style("border", "1px solid #DCDCDC")
        .style("border-radius", "4px")
        .style("font-size", "12px")
        .style("pointer-events", "none")
        .style("opacity", 0);
    }

    // **Tooltip Function to Show Both HD & 2mg Data**
    const showTooltip = (event) => {
      const touch = event.touches ? event.touches[0] : event;
      tooltip
        .html(
          `
        <div style="font-weight: bold; margin-bottom: 5px;">Total Distribution</div>
        <div>
          <span style="color:#32D000;">● EYLEA HD:</span> 
          ${totalHDValue.toLocaleString()} (${totalHDPercentage.toFixed(1)}%)
        </div>
        <div style="margin-top: 3px;">
          <span style="color:#0056B3;">● EYLEA 2mg:</span> 
          ${total2mgValue.toLocaleString()} (${total2mgPercentage.toFixed(1)}%)
        </div>
      `
        )
        .style("opacity", 1)
        .style("left", touch.pageX + 10 + "px")
        .style("top", touch.pageY - 20 + "px");
    };

    const hideTooltip = () => {
      tooltip.style("opacity", 0);
    };

    // **Group for the stacked bar**
    const barGroup = svg.append("g");

    // **Eylea HD Portion (Green)**
    barGroup
      .append("rect")
      .attr("x", totalXScale("Total"))
      .attr("y", totalYScale(totalHDPercentage))
      .attr("width", totalXScale.bandwidth())
      .attr("height", totalYScale(0) - totalYScale(totalHDPercentage))
      .attr("fill", "#32D000")
      .on("mouseover", showTooltip)
      .on("mousemove", showTooltip)
      .on("mouseout", hideTooltip)
      .on("touchstart", showTooltip)
      .on("touchmove", showTooltip)
      .on("touchend", hideTooltip);

    // **Eylea 2mg Portion (Blue)**
    barGroup
      .append("rect")
      .attr("x", totalXScale("Total"))
      .attr("y", totalYScale(totalHDPercentage + total2mgPercentage))
      .attr("width", totalXScale.bandwidth())
      .attr(
        "height",
        totalYScale(totalHDPercentage) -
          totalYScale(totalHDPercentage + total2mgPercentage)
      )
      .attr("fill", "#0056B3")
      .on("mouseover", showTooltip)
      .on("mousemove", showTooltip)
      .on("mouseout", hideTooltip)
      .on("touchstart", showTooltip)
      .on("touchmove", showTooltip)
      .on("touchend", hideTooltip);

    // ** Region Reference Line** -> Replace with a Triangle
    const overallRegionValue = getOverallRegionReferenceValue();
    if (overallRegionValue !== null) {
      const referenceY = totalYScale(overallRegionValue);
      const triangleSize = 10;

      const triangleX = totalXScale("Total") + totalXScale.bandwidth() + 2;

      svg
        .append("polygon")
        .attr(
          "points",
          `
            ${triangleX},${referenceY}
            ${triangleX + triangleSize},${referenceY - triangleSize / 2}
            ${triangleX + triangleSize},${referenceY + triangleSize / 2}
            `
        )
        .attr("fill", "black");

      svg
        .append("text")
        .attr("x", triangleX + triangleSize + 1)
        .attr("y", referenceY + 1)
        .attr("fill", "black")
        .attr("text-anchor", "start")
        .attr("dominant-baseline", "middle")
        .style("font-size", "10px")
        .style("font-weight", "bold")
        .text(`${overallRegionValue.toFixed(1)}%`);
    }

    // **Labels inside the stacked bar (Pointer Events Disabled)**
    const addLabel = (x, y, text, color = "white") => {
      svg
        .append("text")
        .attr("x", x)
        .attr("y", y)
        .attr("fill", color)
        .attr("text-anchor", "middle")
        .attr("dominant-baseline", "middle")
        .style("font-size", "12px")
        .style("pointer-events", "none")
        .text(text);
    };
    if (totalHDValue > 0) {
      addLabel(
        totalXScale("Total") + totalXScale.bandwidth() / 2,
        totalYScale(totalHDPercentage / 2),
        `${totalHDPercentage.toFixed(1)}%`
      );

      addLabel(
        totalXScale("Total") + totalXScale.bandwidth() / 2,
        totalYScale(totalHDPercentage / 2) + 10,
        `(${totalHDValue.toLocaleString()})`
      );
    }

    if (total2mgValue > 0) {
      addLabel(
        totalXScale("Total") + totalXScale.bandwidth() / 2,
        totalYScale(totalHDPercentage + total2mgPercentage / 2),
        `${total2mgPercentage.toFixed(1)}%`
      );

      addLabel(
        totalXScale("Total") + totalXScale.bandwidth() / 2,
        totalYScale(totalHDPercentage + total2mgPercentage / 2) + 10,
        `(${total2mgValue.toLocaleString()})`
      );
    }

    //Total Territory
    svg
      .append("text")
      .attr("x", totalXScale("Total") + totalXScale.bandwidth() / 2)
      .attr("y", height - margin.bottom + 10)
      .attr("fill", "black")
      .attr("text-anchor", "middle")
      .attr("dominant-baseline", "hanging")
      .style("font-size", "10px")
      .style("font-weight", "bold")
      .selectAll("tspan")
      .data(["Total", "Territory"])
      .enter()
      .append("tspan")
      .attr("x", totalXScale("Total") + totalXScale.bandwidth() / 2)
      .attr("dy", (d, i) => (i === 0 ? "0em" : "1.2em"))
      .text((d) => d);
  };

  const drawQuintileChart = (chartData, maxTotalValue, isVolume) => {
    if (!quintileChartRef.current) {
      // console.log("drawQuintileChart: quintileChartRef is null");
      return;
    }

    const svg = d3.select(quintileChartRef.current);
    svg.selectAll("*").remove();

    const svgNode = svg.node();
    if (!svgNode) {
      // console.log("drawQuintileChart: SVG node not found");
      return;
    }

    const width = svgNode.clientWidth;
    const height = svgNode.clientHeight;

    if (width === 0 || height === 0) {
      // console.log("drawQuintileChart: SVG has zero dimensions", width, height);
      return;
    }

    // console.log("drawQuintileChart: Drawing with dimensions", width, height);

    const margin = { top: 10, right: 0, bottom: 15, left: 65 };

    const xScale = d3
      .scaleLinear()
      .domain([0, maxTotalValue])
      .range([margin.left, width - margin.right]);

    const yScale = d3
      .scaleBand()
      .domain(chartData.map((d) => d.quintileValue))
      .range([margin.top, height - margin.bottom])
      .padding(0.2);

    // **Create a single tooltip div (outside loop)**
    const tooltip = d3
      .select("body")
      .append("div")
      .attr("class", "tooltip")
      .style("position", "absolute")
      .style("background", "#fff")
      .style("color", "black")
      .style("padding", "6px 10px")
      .style("border", "1px solid #DCDCDC")
      .style("border-radius", "4px")
      .style("font-size", "12px")
      .style("pointer-events", "none")
      .style("opacity", 0);

    // **Loop through data and create bars**
    chartData.forEach((d) => {
      const barY = yScale(d.quintileValue);
      const barHeight = yScale.bandwidth();
      const barX = xScale(0);
      const eyleaHDWidth = xScale(d.totalHDValue) - xScale(0);
      const eylea2mgWidth =
        xScale(d.total2mgValue + d.totalHDValue) - xScale(d.totalHDValue);

      // **Create a group for both bars and text**
      const barGroup = svg
        .append("g")
        .on("mouseover", (event) => showTooltip(event, d))
        .on("mousemove", (event) => showTooltip(event, d))
        .on("mouseout", hideTooltip)
        .on("touchstart", (event) => showTooltip(event, d))
        .on("touchmove", (event) => showTooltip(event, d))
        .on("touchend", hideTooltip);

      // **Eylea HD (Green) Portion**
      barGroup
        .append("rect")
        .attr("x", barX)
        .attr("y", barY - 3)
        .attr("width", eyleaHDWidth)
        .attr("height", barHeight - 7)
        .attr("fill", "#32D000");

      // **Eylea 2mg (Blue) Portion**
      barGroup
        .append("rect")
        .attr("x", barX + eyleaHDWidth)
        .attr("y", barY - 3)
        .attr("width", eylea2mgWidth)
        .attr("height", barHeight - 7)
        .attr("fill", "#0056B3");

      // **Show "Q1", "Q2", etc. on the left side**
      svg
        .append("text")
        .attr("x", margin.left - 10)
        .attr("y", barY + barHeight / 2)
        .attr("fill", "#000")
        .attr("text-anchor", "end")
        .attr("dominant-baseline", "middle")
        .style("font-size", "12px")
        .text(d.quintileLabel);

      // **Volume-Based Reference Triangle**
      const referenceLinePercentage = getReferenceLinePercentage(
        d.quintileValue
      );
      if (referenceLinePercentage !== null) {
        const referenceX = xScale(
          (d.totalQuintileValue * referenceLinePercentage) / 100
        );
        const referenceY = barY - 5;
        const triangleSize = 6;

        // **Triangle Pointer (▼)**
        svg
          .append("polygon")
          .attr(
            "points",
            `
              ${referenceX},${referenceY}
              ${referenceX - triangleSize / 2},${referenceY - triangleSize}
              ${referenceX + triangleSize / 2},${referenceY - triangleSize}
            `
          )
          .attr("fill", "black");

        // **Reference Percentage Text**
        svg
          .append("text")
          .attr("x", referenceX + 3)
          .attr("y", referenceY - triangleSize / 3)
          .attr("fill", "black")
          .attr("text-anchor", "start")
          .attr("dominant-baseline", "middle")
          .style("font-size", "10px")
          .style("font-weight", "bold")
          .text(`${referenceLinePercentage.toFixed(1)}%`);
      }

      // **Labels inside the bars (now with pointer-events disabled)**
      const addLabel = (x, y, text, color = "white") => {
        barGroup
          .append("text")
          .attr("x", x)
          .attr("y", y)
          .attr("fill", color)
          .attr("text-anchor", "middle")
          .attr("dominant-baseline", "middle")
          .style("font-size", "10px")
          .style("pointer-events", "none")
          .text(text);
      };

      if (d.totalHDValue > 0) {
        addLabel(
          barX + eyleaHDWidth / 2,
          barY + barHeight / 2 - 11,
          `${d.totalHDValue.toLocaleString("en-US")}`
        );
        addLabel(
          barX + eyleaHDWidth / 2,
          barY + barHeight / 2 + 2,
          `(${d["Eylea HD"].toFixed(0)}%)`
        );
      }

      if (d.total2mgValue > 0) {
        addLabel(
          barX + eyleaHDWidth + eylea2mgWidth / 2,
          barY + barHeight / 2 - 11,
          `${d.total2mgValue.toLocaleString("en-US")}`
        );
        addLabel(
          barX + eyleaHDWidth + eylea2mgWidth / 2,
          barY + barHeight / 2 + 2,
          `(${d["Eylea 2mg"].toFixed(0)}%)`
        );
      }

      // **Tooltip Functions**
      function showTooltip(event, data) {
        const touch = event.touches ? event.touches[0] : event;
        const quintiles = ["1", "2", "3", "4", "5"];
        const index = quintiles.findIndex((q) =>
          data.quintileLabel.includes(q)
        );
        const displayQuintile = index !== -1 ? quintiles[index] : "N/A";
        tooltip
          .html(
            `
          <strong>Quintile ${displayQuintile}</strong><br/>
          <span style="color:#32D000">● EYLEA HD:</span> ${data.totalHDValue.toLocaleString(
            "en-US"
          )} (${data["Eylea HD"].toFixed(0)}%)<br/>
          <span style="color:#0056B3">● EYLEA 2mg:</span> ${data.total2mgValue.toLocaleString(
            "en-US"
          )} (${data["Eylea 2mg"].toFixed(0)}%)
        `
          )
          .style("opacity", 1)
          .style("left", touch.pageX + 10 + "px")
          .style("top", touch.pageY - 20 + "px");
      }

      function hideTooltip() {
        tooltip.style("opacity", 0);
      }
    });
  };

  // Reference line: overall region-level (for the total bar)
  const getOverallRegionReferenceValue = () => {
    const fieldName = isQTD
      ? "REG_OverallRegPerQTD__c"
      : "REG_OverallRegPerC13W__c";

    const filteredData = isVolume
      ? data.filter((item) => item.REG_Subject__c === "units")
      : data.filter((item) => item.REG_Subject__c === "BV");

    const overallRegionAvg = filteredData.find((item) => item[fieldName]);
    if (overallRegionAvg && overallRegionAvg[fieldName]) {
      const parsedValue = parseFloat(
        overallRegionAvg[fieldName].value || overallRegionAvg[fieldName]
      );
      return isNaN(parsedValue) || parsedValue < 0 ? null : parsedValue;
    }
    return null;
  };

  const getReferenceLinePercentage = (qVal) => {
    const fieldName = isQTD
      ? `REG_Q${qVal}RegPerQTD__c`
      : `REG_Q${qVal}RegPerC13W__c`;

    const filteredData = isVolume
      ? data.filter((item) => item.REG_Subject__c === "units")
      : data.filter((item) => item.REG_Subject__c === "BV");

    const regionData = filteredData.find((item) => item[fieldName]);
    if (regionData && regionData[fieldName]) {
      const parsedValue = parseFloat(
        regionData[fieldName].value || regionData[fieldName]
      );
      return isNaN(parsedValue) ? null : Math.min(parsedValue, 100);
    }
    return null;
  };

  // Loading state - show spinner when data is being fetched
  if (loadingStates.mergedPortfolio || !dataLoaded) {
    return (
      <div className="bg-white py-1 h-[47vh] border-1 rounded-lg shadow w-full px-2 flex flex-col">
        <div className="flex flex-row justify-between">
          <div></div>
          <h3 className="text-center text-[.9375rem] font-bold text-[#44546A] lg:pt-[0.25rem]">
            {isQTD ? "QTD" : "C13W"} Portfolio Composition
          </h3>
          <div></div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-[#44546A] text-sm">Loading data...</p>
        </div>
      </div>
    );
  }

  // Error state - if there's an error loading data
  if (tcErrorState && data.length === 0) {
    return (
      <div className="bg-white py-1 h-[47vh] border-1 rounded-lg shadow w-full px-2 flex flex-col">
        <div className="flex flex-row justify-between">
          <div></div>
          <h3 className="text-center text-[.9375rem] font-bold text-[#44546A] lg:pt-[0.25rem]">
            {isQTD ? "QTD" : "C13W"} Portfolio Composition
          </h3>
          <div></div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-4xl text-red-400 mb-2">⚠️</div>
          <p className="text-red-500 text-sm">Error loading data</p>
          <p className="text-gray-500 text-xs mt-1">
            Please try refreshing the page
          </p>
        </div>
      </div>
    );
  }

  // Empty state - show when no data is available
  if (data.length === 0 && dataLoaded) {
    return (
      <div className="bg-white py-1 h-[47vh] border-1 rounded-lg shadow w-full px-2 flex flex-col">
        <div className="flex flex-row justify-between">
          <div></div>
          <h3 className="text-center text-[.9375rem] font-bold text-[#44546A] lg:pt-[0.25rem]">
            {isQTD ? "QTD" : "C13W"} Portfolio Composition
          </h3>
          <div></div>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-4xl text-gray-400 mb-2">📊</div>
          <p className="text-[#44546A] text-sm">No data available</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white py-1 h-[47vh] border-1 rounded-lg shadow w-full px-2">
      {/* Header Elements */}
      <div className="flex flex-row justify-between">
        <div className="">
          <div className="inline-block text-left">
            <button
              type="button"
              className="focus:outline-none"
              onClick={() => setShowTooltip(!showTooltip)}
            >
              <InfoOutlinedIcon className="text-gray-600" />
            </button>

            {showTooltip && (
              <div className="absolute z-10 mt-2 w-40 bg-white border border-gray-300 rounded shadow-lg">
                <div className="p-2 text-sm text-gray-700">
                  Sales data through {formattedDate}, E4U data through{" "}
                  {formattedDate}
                </div>
              </div>
            )}
          </div>
        </div>
        <h3 className="text-center text-[.9375rem] font-bold text-[#44546A] lg:pt-[0.25rem]">
          {isQTD ? "QTD" : "C13W"} Portfolio Composition
        </h3>

        <div></div>
      </div>

      {/* Toggle for Volume / BV */}
      <div className="flex justify-center text-[.75rem] lg:text-[.82rem] pb-1">
        <span
          className={`pt-[1px] mr-2 font-bold ${
            isVolume ? "text-[#44546A]" : "text-[#a7a5a5]"
          }`}
        >
          Volume Composition
        </span>
        <div
          onClick={() => setIsVolume(!isVolume)}
          className="relative w-8 h-4 mt-[2px] rounded-full bg-gray-300 cursor-pointer flex items-center"
          style={{
            justifyContent: isVolume ? "flex-start" : "flex-end",
            padding: "2px",
          }}
        >
          <div className="w-4 h-3 bg-white rounded-full shadow"></div>
        </div>
        <span
          className={`pt-[1px] ml-2 font-bold ${
            !isVolume ? "text-[#44546A]" : "text-[#a7a5a5]"
          }`}
        >
          BV Composition
        </span>
      </div>

      {/* Legends */}
      <div className="flex justify-center space-x-4 items-center">
        <div className="flex items-center">
          <div className="w-2 h-2 bg-[#0056B3] mr-2"></div>
          <span className="text-gray-600 font-semibold text-[.625rem] lg:text-[.75rem]">
            EYLEA 2mg
          </span>
        </div>

        <div className="flex items-center">
          <div className="w-2 h-2 bg-[#32D000] mr-2"></div>
          <span className="text-gray-600 font-semibold text-[.625rem] lg:text-[.75rem]">
            EYLEA HD
          </span>
        </div>

        <div className="flex items-center">
          <div className="w-0 h-0 border-l-4 border-l-transparent border-r-4 border-r-transparent border-b-8 border-b-black"></div>
          <span className="text-gray-600 font-semibold text-[.625rem] lg:text-[.75rem] ml-2">
            Region
          </span>
        </div>
      </div>

      {/* Charts */}
      <div className="flex flex-row items-center h-[95%] lg:h-[90%] ml-[-3rem] gap-x-2">
        <div className="flex-shrink-0 w-[40%] lg:w-[30%] h-[84%] mb-[26px]">
          <svg ref={totalChartRef} width="100%" height="100%"></svg>
        </div>

        <div className="flex-grow h-[88%] ml-[-2.5rem] mb-6">
          <svg ref={quintileChartRef} width="100%" height="100%"></svg>
        </div>
      </div>
    </div>
  );
};

export default PortfolioComposition;
