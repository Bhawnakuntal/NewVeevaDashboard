import React, { useState, useContext, useEffect } from "react";
import { DataContext } from "../Context/DataCenter";
import { FaExpandAlt } from "react-icons/fa";
import { FaSort, FaSortUp, FaSortDown } from "react-icons/fa";

const OmnichannelEngagements = ({ expanded, onExpand }) => {
  const {
    engagementData,
    timePeriod,
    expMergedData,
    loadingStates,
    dataLoaded,
    tcErrorState,
  } = useContext(DataContext);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });

  const [selectedTarget, setSelectedTarget] = useState("RS"); // 'HCP' or 'RS'
  const [filteredData, setFilteredData] = useState([]);
  const [filteredExpData, setFilteredExpData] = useState([]);

  const handleTargetChange = (target) => {
    setSelectedTarget(target);
  };

  // Filter the data based on the user's territory and update filteredData state
  useEffect(() => {
    if (expMergedData) {
      // Filter for main engagement data
      const territoryData = engagementData;
      setFilteredData(territoryData);

      // Filter for expanded engagement data (expEngagementData)
      const territoryExpData = expMergedData.filter(
        (item) => item.REG_Timeframe__c?.value === timePeriod
      );
      setFilteredExpData(territoryExpData);
    }
  }, [engagementData, expMergedData, timePeriod]);

  // Loading state - show spinner when data is being fetched
  if (loadingStates.engagementData || !dataLoaded) {
    return (
      <div
        className={`shadow px-1 border-1 rounded-lg bg-white w-full mt-0 flex flex-col ${
          expanded ? "min-h-[75vh]" : "min-h-[47vh]"
        }`}
      >
        {/* Heading at the top */}
        <div className="flex justify-center pt-2">
          <h2 className="text-center text-[.9375rem] w-full px-0 font-bold text-[#44546A] lg:my-0">
            {timePeriod} Omni-Channel Engagement
          </h2>
        </div>

        {/* Spinner centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-[#44546A] text-sm">Loading data...</p>
        </div>
      </div>
    );
  }

  // Error state - if there's an error loading data
  if (tcErrorState && engagementData.length === 0) {
    return (
      <div
        className={`shadow px-1 border-1 rounded-lg bg-white w-full mt-0 flex flex-col ${
          expanded ? "min-h-[75vh]" : "min-h-[47vh]"
        }`}
      >
        {/* Heading at the top */}
        <div className="flex justify-center pt-2">
          <h2 className="text-center text-[.9375rem] w-full px-0 font-bold text-[#44546A] lg:my-0">
            {timePeriod} Omni-Channel Engagement
          </h2>
        </div>

        {/* Error content centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-4xl text-red-400 mb-2">⚠️</div>
          <p className="text-red-500 text-sm">Error loading data</p>
          <p className="text-gray-500 text-xs mt-1">
            Please try refreshing the page
          </p>
        </div>
      </div>
    );
  }

  // Empty state - show when no data is available
  if (engagementData.length === 0 && dataLoaded) {
    return (
      <div
        className={`shadow px-1 border-1 rounded-lg bg-white w-full mt-0 flex flex-col ${
          expanded ? "min-h-[75vh]" : "min-h-[47vh]"
        }`}
      >
        {/* Heading at the top */}
        <div className="flex justify-center pt-2">
          <h2 className="text-center text-[.9375rem] w-full px-0 font-bold text-[#44546A] lg:my-0">
            {timePeriod} Omni-Channel Engagement
          </h2>
        </div>

        {/* Empty state content centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-4xl text-gray-400 mb-2">📊</div>
          <p className="text-[#44546A] text-sm">No data available</p>
        </div>
      </div>
    );
  }

  // Use timePeriod to choose the field names for QTD or C13W
  const isQTD = timePeriod === "QTD";

  // Choose the field names dynamically based on the parent timePeriod and the selected target
  const engagementsField =
    selectedTarget === "RS"
      ? isQTD
        ? "REG_EngagementsinQTDRS__c"
        : "REG_EngagementsinC13WRS__c"
      : isQTD
      ? "REG_EngagementsinQTD__c"
      : "REG_Engagements_in_C13W__c";
  const reachField =
    selectedTarget === "RS"
      ? isQTD
        ? "REG_PerReachQTDRS__c"
        : "REG_PerReachC13WRS__c"
      : isQTD
      ? "REG_PerReachQTD__c"
      : "REG_PerReachC13W__c";
  const changeField =
    selectedTarget === "RS"
      ? isQTD
        ? "REG_ChangevsPFQRS__c"
        : "REG_Change_vs_P13W_RS__c"
      : isQTD
      ? "REG_ChangevsPFQ__c"
      : "REG_Change_vs_P13W__c";

  // DS Script function for onClick
  function runViewRecordAcc(id) {
    try {
      var configObject = {
        object: "Account",
        fields: { Id: id },
      };
      // eslint-disable-next-line
      ds.viewRecord(configObject).then(
        function (resp) {
          return resp;
        },
        function (err) {
          console.log(err);
        }
      );
    } catch (error) {
      let line = error.stack;
      //   setAccountFetchError(error, line);
    }
  }
  //Sorting
  const handleSort = (key) => {
    let direction = "asc";

    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }

    setSortConfig({ key, direction });
  };

  // Filter the expanded data based on selected target (HCP or RS)
  const filteredExpandedData = filteredExpData.filter((item) => {
    if (selectedTarget === "RS") {
      return item.REG_IsRSTarget__c?.value === "Y"; // Filter only RS Targets
    }
    return true; // For HCP, return all data
  });

  // NEW: Aggregate duplicate accounts by summing engagement counts
  const aggregatedAccountsData = filteredExpandedData.reduce((acc, item) => {
    const accountId = item.REG_Account__c?.value;

    if (!acc[accountId]) {
      // First time seeing this account - create base object
      acc[accountId] = {
        ...item,
        // Initialize all engagement fields to ensure they exist
        REG_MyF2FEngagement__c: {
          value: Number(item.REG_MyF2FEngagement__c?.value) || 0,
        },
        REG_VirtualEngagement__c: {
          value: Number(item.REG_VirtualEngagement__c?.value) || 0,
        },
        REG_EmailEngagement__c: {
          value: Number(item.REG_EmailEngagement__c?.value) || 0,
        },
        REG_MediaEngagement__c: {
          value: Number(item.REG_MediaEngagement__c?.value) || 0,
        },
        REG_RTEEngagement__c: {
          value: Number(item.REG_RTEEngagement__c?.value) || 0,
        },
        // Add other engagement fields if needed
      };
    } else {
      // Already seen this account - sum up the engagement counts
      const current = acc[accountId];
      current.REG_MyF2FEngagement__c.value +=
        Number(item.REG_MyF2FEngagement__c?.value) || 0;
      current.REG_VirtualEngagement__c.value +=
        Number(item.REG_VirtualEngagement__c?.value) || 0;
      current.REG_EmailEngagement__c.value +=
        Number(item.REG_EmailEngagement__c?.value) || 0;
      current.REG_MediaEngagement__c.value +=
        Number(item.REG_MediaEngagement__c?.value) || 0;
      current.REG_RTEEngagement__c.value +=
        Number(item.REG_RTEEngagement__c?.value) || 0;
    }

    return acc;
  }, {});

  // Convert back to array
  const uniqueAccountsData = Object.values(aggregatedAccountsData);

  // Now sort the unique accounts data instead of the raw filtered data
  const sortedData = [...uniqueAccountsData].sort((a, b) => {
    if (!sortConfig.key) return 0;

    let valueA, valueB;

    if (sortConfig.key === "REG_MSF2FEngagement__c/REG_DEMSF2FEngagement__c") {
      const getSum = (item) => {
        const val1 = item["REG_MSF2FEngagement__c"]?.value || 0;
        const val2 = item["REG_DEMSF2FEngagement__c"]?.value || 0;
        return val1 + val2;
      };
      valueA = getSum(a);
      valueB = getSum(b);
    } else if (sortConfig.key === "primaryParentName") {
      valueA = a[sortConfig.key] || "";
      valueB = b[sortConfig.key] || "";
    } else {
      valueA = a[sortConfig.key]?.value || 0;
      valueB = b[sortConfig.key]?.value || 0;
    }

    if (typeof valueA === "string") {
      return sortConfig.direction === "asc"
        ? valueA.localeCompare(valueB)
        : valueB.localeCompare(valueA);
    }

    if (typeof valueA === "number") {
      return sortConfig.direction === "asc" ? valueA - valueB : valueB - valueA;
    }

    return 0;
  });

  const currentData = sortedData;

  return (
    <div
      className={`shadow px-1 border-1 rounded-lg bg-white w-full mt-0 flex flex-col ${
        expanded ? "min-h-[75vh]" : "min-h-[47vh]"
      }`}
    >
      <div className="flex justify-center pt-2">
        <h2 className="text-center text-[.9375rem] w-full px-0 font-bold text-[#44546A] lg:my-0">
          {timePeriod} Omni-Channel Engagement
        </h2>

        {expanded ? (
          <button
            className="cursor-pointer text-[1.5rem] mr-2 mt-[-.2rem]"
            onClick={onExpand}
          >
            ✕
          </button>
        ) : (
          <button
            className="cursor-pointer xl:mr-1 mr-[0.2rem]"
            onClick={onExpand}
          >
            <FaExpandAlt
              className="text-[#44546A] text-[1.25rem]"
              onClick={() => onExpand()}
            />
          </button>
        )}
      </div>

      {/* Target Filter Buttons - Available in both expanded and non-expanded views */}
      {!expanded && (
        <div className="flex flex-row font-bold justify-center space-x-2 mt-1 mb-3 xl:mt-[.2rem]">
          <span
            className={`text-[.75rem] pt-[1px] ${
              selectedTarget === "RS" ? "text-gray-400" : "text-[#44546A]"
            }`}
          >
            All HCP
          </span>

          <div
            onClick={() =>
              handleTargetChange(selectedTarget === "RS" ? "HCP" : "RS")
            }
            className="relative w-8 h-4  mt-[2px] rounded-full bg-gray-300 cursor-pointer flex items-center"
            style={{
              justifyContent:
                selectedTarget === "RS" ? "flex-end" : "flex-start",
              padding: "2px",
            }}
          >
            <div className="w-4 h-3 bg-white rounded-full shadow"></div>
          </div>

          <span
            className={`text-[.75rem] pt-[1px] ${
              selectedTarget === "RS" ? "text-[#44546A]" : "text-gray-400"
            }`}
          >
            RS Targets
          </span>
        </div>
      )}

      {/* Filters as Headers for Expanded View */}
      {expanded && (
        <div className="flex justify-center mt-2 mb-2 space-x-6">
          {[
            { key: "HCP", label: "All HCPs Engaged" },
            { key: "RS", label: "RS Targets Engaged" },
          ].map(({ key, label }) => (
            <div
              key={key}
              className={`px-4 py-2 text-[.875rem] font-bold cursor-pointer rounded-md transition-all
            ${
              selectedTarget === key
                ? "bg-blue-500 text-white shadow-md" // Selected tab
                : "bg-gray-100 text-gray-600 hover:bg-gray-300 hover:text-gray-800"
            }`}
              onClick={() => handleTargetChange(key)}
            >
              {label}
            </div>
          ))}
        </div>
      )}

      {/* Hide the total engagement table when expanded */}
      {!expanded && (
        <>
          {/* Summary Table */}
          <div className="w-full px-1 xl:pb-0 lg:pb-[0.rem]">
            <table className="min-w-full border-gray-300">
              <thead className="bg-[#A1A9B4]">
                <tr>
                  <th className="p-2 text-left text-[0.75rem] xl:text-[0.825rem] text-gray-100 border-b">
                    Channel
                  </th>
                  <th className="p-2 text-center text-[0.75rem] xl:text-[0.825rem] text-gray-100 border-b">
                    % Reach
                  </th>
                  <th className="p-2 text-center text-[0.75rem] xl:text-[0.825rem] text-gray-100 border-b">
                    Engagement
                  </th>
                  <th className="p-2 text-center text-[0.75rem] xl:text-[0.825rem] text-gray-100 border-b">
                    vs {isQTD ? "PFQ" : "P13W"}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white">
                {[
                  "3rd Party Media",
                  "Broadcast emails",
                  "In Person",
                  "RTE",
                  "Virtual",
                  "Virtual Promo Program",
                  "Overall",
                ].map((channel, index) => {
                  // Filter ALL records for this channel
                  const items = filteredData.filter(
                    (data) => data.REG_Channel__c?.value === channel
                  );

                  // Aggregate values
                  const aggregated = items.reduce(
                    (acc, item) => {
                      return {
                        reachSum:
                          acc.reachSum + (Number(item[reachField]?.value) || 0),
                        engagements:
                          acc.engagements +
                          (Number(item[engagementsField]?.value) || 0),
                        changeSum:
                          acc.changeSum +
                          (Number(item[changeField]?.value) || 0),
                        count: acc.count + 1,
                      };
                    },
                    { reachSum: 0, engagements: 0, changeSum: 0, count: 0 }
                  );

                  // Calculate AVERAGE percentage reach
                  const averageReach =
                    aggregated.count > 0
                      ? aggregated.reachSum / aggregated.count
                      : 0;

                  // Calculate AVERAGE percentage change
                  const averageChange =
                    aggregated.count > 0
                      ? aggregated.changeSum / aggregated.count
                      : 0;

                  const isOverall = channel === "Overall";
                  const rowClass = isOverall
                    ? "bg-[#DDE2E6] font-bold text-[#222]"
                    : index % 2 === 0
                    ? "bg-[#F2F2F2]"
                    : "bg-white";

                  return (
                    <tr key={channel} className={`text-left ${rowClass}`}>
                      <td className="p-1 lg:p-2 text-left text-[0.625rem] lg:text-[.75rem] text-[#44546A]">
                        {channel === "Virtual"
                          ? "My Virtual Engagements"
                          : channel === "In Person"
                          ? "My In Person Engagements"
                          : channel === "RTE"
                          ? "My RTEs"
                          : channel}
                      </td>
                      <td className="p-1 lg:p-2 text-center text-[0.625rem] lg:text-[.75rem] text-[#44546A]">
                        {averageReach.toFixed(1)}%
                      </td>
                      <td className="p-1 lg:p-2 text-center text-[0.625rem] lg:text-[.75rem] text-[#44546A]">
                        {aggregated.engagements}
                      </td>
                      <td className="p-1 lg:p-2 text-center text-[0.625rem] lg:text-[.75rem]">
                        <div className="flex justify-between items-center pl-4">
                          {averageChange > 0 ? (
                            <span className="flex items-center">
                              <span className="text-[#44546A]">▲</span>
                              <span className="ml-1 text-[#44546A]">
                                {Math.abs(averageChange.toFixed(1))}%
                              </span>
                            </span>
                          ) : (
                            <span className="flex items-center">
                              <span className="text-[#44546A]">▼</span>
                              <span className="ml-1 text-[#44546A]">
                                {Math.abs(averageChange.toFixed(1))}%
                              </span>
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Expanded Detailed Table */}
      {expanded && (
        <div className="mt-4 w-full px-2 overflow-x-auto max-h-[500px] overflow-y-auto">
          <table className="w-full border-collapse">
            <colgroup>
              <col style={{ width: "180px" }} />
              <col style={{ width: "220px" }} />
            </colgroup>
            <thead className="bg-[#A1A9B4] text-center text-white sticky top-0 z-10">
              <tr>
                {[
                  { key: "REG_AccountName__c", label: "HCP Full Name" },
                  { key: "primaryParentName", label: "HCO Primary Parent" },
                  {
                    key: "REG_MyF2FEngagement__c?",
                    label: "Reached F2F (self)",
                  },
                  {
                    key: "REG_MyF2FEngagement__c",
                    label: "My F2F Engagements",
                  },
                  { key: "REG_VirtualEngagement__c", label: "My Virtual" },
                  { key: "REG_EmailEngagement__c", label: "Broadcast Email" },
                  { key: "REG_MediaEngagement__c", label: "3rd Party Media" },
                  { key: "REG_RTEEngagement__c", label: "My RTEs" },
                  // Add other columns similarly
                ].map((col, index) => (
                  <th
                    key={col.key}
                    className="border border-gray-300 p-2 text-center text-[.75rem] cursor-pointer"
                    onClick={() => {
                      // Only allow sorting for columns other than 3rd and 4th
                      if (index !== 2) {
                        handleSort(col.key);
                      }
                    }}
                  >
                    <span className="flex justify-center items-center">
                      {col.label}
                      {index !== 2 && (
                        <>
                          {sortConfig.key === col.key ? (
                            sortConfig.direction === "asc" ? (
                              <FaSortUp
                                className="ml-1"
                                width="12"
                                height="12"
                              />
                            ) : (
                              <FaSortDown
                                className="ml-1"
                                width="12"
                                height="12"
                              />
                            )
                          ) : (
                            <FaSort className="ml-1" width="12" height="12" />
                          )}
                        </>
                      )}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {currentData.map((item, index) => (
                <tr
                  key={index}
                  className={`${index % 2 === 0 ? "bg-gray-100" : "bg-white"}`}
                >
                  <td
                    className="border border-gray-300 p-2 text-center text-[.625rem] text-[#297cd4] cursor-pointer"
                    onClick={() => runViewRecordAcc(item.REG_Account__c.value)}
                  >
                    {item.REG_AccountName__c?.value}
                  </td>
                  <td
                    className="border border-gray-300 p-2 text-center text-[.625rem] text-[#297cd4] cursor-pointer"
                    onClick={() => runViewRecordAcc(item.primaryParentId)}
                  >
                    {item.primaryParentName}
                  </td>
                  <td className="border border-gray-300 p-2 text-center text-[.625rem]">
                    {item.REG_MyF2FEngagement__c?.value >= 1 ? "Y" : "N"}
                  </td>
                  <td className="border border-gray-300 p-2 text-center text-[.625rem]">
                    {item.REG_MyF2FEngagement__c.value || 0}
                  </td>
                  <td className="border border-gray-300 p-2 text-center text-[.625rem]">
                    {item.REG_VirtualEngagement__c?.value || 0}
                  </td>
                  <td className="border border-gray-300 p-2 text-center text-[.625rem]">
                    {item.REG_EmailEngagement__c?.value || 0}
                  </td>
                  <td className="border border-gray-300 p-2 text-center text-[.625rem]">
                    {item.REG_MediaEngagement__c?.value || 0}
                  </td>
                  <td className="border border-gray-300 p-2 text-center text-[.625rem]">
                    {item.REG_RTEEngagement__c?.value || 0}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default OmnichannelEngagements;
