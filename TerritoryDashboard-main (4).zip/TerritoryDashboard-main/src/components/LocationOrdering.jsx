import React, { useState, useEffect, useContext } from "react";
import { DataContext } from "../Context/DataCenter";

const LocationOrdering = ({ onExpand, expanded }) => {
  const [data, setData] = useState([]);
  const [uniqueData, setUniqueData] = useState([]);
  const { elyea, timePeriod, loadingStates, dataLoaded, tcErrorState } =
    useContext(DataContext);

  useEffect(() => {
    // Remove duplicates using Map()
    const uniqueAccounts = Array.from(
      new Map(elyea.map((item) => [item.REG_Account__c.value, item])).values()
    );

    setData(elyea);
    setUniqueData(uniqueAccounts);
  }, [elyea]);

  // Determine field names based on timePeriod
  const isQTD = timePeriod === "QTD";

  // Conditionally use fields based on timePeriod (QTD or C13W)
  const productField = "REG_ProductName__c";
  const volumeField = isQTD ? "REG_QTD__c" : "REG_C13W_Volume__c";
  const pField = isQTD ? "REG_PFQ__c" : "REG_P13W_Volume__c";

  // Key metrics calculations based on the selected time period
  const p13wCount = data.filter(
    (item) => item[pField]?.value > 0 && item[productField].value === "EYLEA HD"
  ).length;
  const c13wCount = data.filter(
    (item) =>
      item[volumeField]?.value > 0 && item[productField].value === "EYLEA HD"
  ).length;

  const lapsedCount = data.filter(
    (item) =>
      item[volumeField]?.value === 0 &&
      item[productField].value === "EYLEA HD" &&
      item[pField]?.value > 0
  ).length;

  // Loading state - show spinner when data is being fetched
  if (loadingStates.elyea || !dataLoaded) {
    return (
      <div className="bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[21vh]">
        {/* Heading at the top */}
        <h3 className="font-bold text-[.9375rem] text-[#44546A] text-center">
          {timePeriod} Locations Ordering EYLEA HD
        </h3>

        {/* Spinner centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-[#44546A] text-sm">Loading data...</p>
        </div>
      </div>
    );
  }

  // Error state - if there's an error loading data
  if (tcErrorState && data.length === 0) {
    return (
      <div
        className={`bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[21vh] items-center justify-center`}
      >
        <h3 className="font-bold text-[.9375rem] mb-[.8rem] lg:mb-[0rem] text-[#44546A]">
          {timePeriod} Locations Ordering EYLEA HD
        </h3>
        <div className="flex flex-col items-center justify-center">
          <div className="text-4xl text-red-400 mb-2">⚠️</div>
          <p className="text-red-500 text-sm">Error loading data</p>
          <p className="text-gray-500 text-xs mt-1">
            Please try refreshing the page
          </p>
        </div>
      </div>
    );
  }

  // Empty state - show when no data is available
  if (data.length === 0 && dataLoaded) {
    return (
      <div
        className={`bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[21vh] items-center justify-center`}
      >
        <h3 className="font-bold text-[.9375rem] mb-[.8rem] lg:mb-[0rem] text-[#44546A]">
          {timePeriod} Locations Ordering EYLEA HD
        </h3>
        <div className="flex flex-col items-center justify-center">
          <div className="text-4xl text-gray-400 mb-2">📊</div>
          <p className="text-[#44546A] text-sm">No data available</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`bg-white px-2 pt-2 mb-2 border-1 rounded-lg min-h-[21vh] shadow ${
        expanded ? "w-full" : ""
      }`}
    >
      <div onClick={onExpand} className="cursor-pointer mb-3">
        <div className="flex flex-row justify-between">
          <div className="right-0 top-0"></div>
          <h3 className="font-bold mb-2 mt-1 text-center text-[.9375rem] px-0 text-[#44546A]">
            {timePeriod} Locations Ordering EYLEA HD
          </h3>
          <div></div>
        </div>

        <div className="flex justify-around">
          <div className="cursor-pointer py-0">
            <div className="text-[#44546A] text-[1.25rem] font-bold text-center mb-2">
              {p13wCount}/{uniqueData.length}
            </div>
            <div className="text-center f text-[.937rem] text-[#637077]">
              Locations
              <br />
              {isQTD ? "PFQ" : "P13W"}
              <br />
            </div>
          </div>
          <div className="cursor-pointer">
            <div className="text-[#44546A] text-[1.25rem] font-bold text-center mb-2">
              {c13wCount}/{uniqueData.length}
            </div>
            <div className="text-center text-[.937rem] text-[#637077]">
              Locations
              <br />
              {isQTD ? "QTD" : "C13W"}
              <br />
            </div>
          </div>
          <div className="cursor-pointer">
            <div className="text-[#44546A] text-[1.25rem] font-bold text-center mb-2">
              {lapsedCount}/{uniqueData.length}
            </div>
            <div className="text-center text-[.937rem] text-[#637077]">
              Lapsed
              <br />
              {isQTD ? "QTD" : "C13W"}
              <br />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationOrdering;
