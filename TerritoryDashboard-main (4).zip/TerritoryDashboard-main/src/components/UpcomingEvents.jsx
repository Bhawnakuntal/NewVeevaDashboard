import React, { useContext, useMemo, useState, useEffect } from "react";
import { DataContext } from "../Context/DataCenter";

const UpcomingEvents = () => {
  const { event, userId, loadingStates, dataLoaded, tcErrorState } =
    useContext(DataContext);
  const [loading, setLoading] = useState(true);
  const [modalData, setModalData] = useState({
    open: false,
    title: "",
    events: [],
  });

  // const userId = { Id: "005360000035yy0AAA" };
  // console.log("Event data is>>>>", event);
  // console.log(userId);

  useEffect(() => {
    if (event && userId) {
      setLoading(false);
    }
  }, [event, userId]);

  const today = new Date(); // Get today's date in 'YYYY-MM-DD' format

  const filteredData = useMemo(() => {
    if (loading || !event || !userId.Id) return [];

    const filteredEvents = event.filter((item) => {
      return new Date(item.End_Date_vod__c?.value) >= today;
    });

    const myEvents = filteredEvents.filter(
      (item) =>
        item.OwnerId?.value === userId?.Id &&
        ["Pending", "Confirmed"].includes(item.Status_vod__c?.value)
    );

    const virtualEvents = filteredEvents.filter(
      (item) =>
        item.PW_Event_Format__c?.value === "Virtual" &&
        ["Pending", "Confirmed"].includes(item.Status_vod__c?.value)
    );

    const categorizedData = [
      {
        category: "HCP Programs",
        myEvents: myEvents.filter(
          (item) =>
            item.PW_Event_Type__c?.value?.includes("Physician's Program") &&
            item.PW_Product__c?.value?.includes("EYLEA")
        ),
        virtualEvents: virtualEvents.filter(
          (item) =>
            item.PW_Event_Type__c?.value?.includes("Physician's Program") &&
            item.PW_Product__c?.value?.includes("EYLEA")
        ),
      },
      {
        category: "Tech Programs",
        myEvents: myEvents.filter((item) =>
          item.PW_Event_Type__c?.value?.includes(
            "Retina Technician Program (RTP)"
          )
        ),
        virtualEvents: virtualEvents.filter((item) =>
          item.PW_Event_Type__c?.value?.includes(
            "Retina Technician Program (RTP)"
          )
        ),
      },
      {
        category: "RAP Programs",
        myEvents: myEvents.filter((item) =>
          item.PW_Event_Type__c?.value?.includes(
            "Retina Administrator Program (RAP)"
          )
        ),
        virtualEvents: virtualEvents.filter((item) =>
          item.PW_Event_Type__c?.value?.includes(
            "Retina Administrator Program (RAP)"
          )
        ),
      },
    ];

    const categorizedMyEventIds = new Set(
      categorizedData.flatMap(({ myEvents }) => myEvents.map((item) => item.Id))
    );

    const categorizedVirtualEventIds = new Set(
      categorizedData.flatMap(({ virtualEvents }) =>
        virtualEvents.map((item) => item.Id)
      )
    );

    categorizedData.push({
      category: "All Others",
      myEvents: myEvents.filter((item) => !categorizedMyEventIds.has(item.Id)),
      virtualEvents: virtualEvents.filter(
        (item) => !categorizedVirtualEventIds.has(item.Id)
      ),
    });

    return categorizedData;
  }, [event, userId, loading]);
  // console.log("filteredData>>>", filteredData);
  const openModal = (title, events) => {
    setModalData({ open: true, title, events });
  };

  const closeModal = () => {
    setModalData({ open: false, title: "", events: [] });
  };
  // Function to view Medical Event record
  function runViewRecordEvent(id) {
    var configObject = {
      object: "Medical_Event_vod__c",
      fields: { Id: id },
    };
    // eslint-disable-next-line
    ds.viewRecord(configObject).then(
      function (resp) {
        return resp;
      },
      function (err) {
        console.log(err);
      }
    );
  }

  // Loading state - show spinner when data is being fetched
  if (loadingStates.event || !dataLoaded) {
    return (
      <div className="px-2 py-[.2rem] lg:py-1 xl:py-1 2xl:py-1 h-[26vh] border-1 rounded-lg mb-2 w-full bg-white shadow flex flex-col">
        {/* Heading at the top */}
        <h2 className="font-bold xl:py-1 my-1 lg:my-1 xl:my-1 text-center text-[#44546A] text-[.9375rem] lg:text-[1rem] xl:text-[1rem]">
          Upcoming Events
        </h2>

        {/* Spinner centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-[#44546A] text-sm">Loading data...</p>
        </div>
      </div>
    );
  }

  // Error state - if there's an error loading data
  if (tcErrorState && event.length === 0) {
    return (
      <div className="px-2 py-[.2rem] lg:py-1 xl:py-1 2xl:py-1 h-[26vh] border-1 rounded-lg mb-2 w-full bg-white shadow flex flex-col">
        {/* Heading at the top */}
        <h2 className="font-bold xl:py-1 my-1 lg:my-1 xl:my-1 text-center text-[#44546A] text-[.9375rem] lg:text-[1rem] xl:text-[1rem]">
          Upcoming Events
        </h2>

        {/* Error content centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-4xl text-red-400 mb-2">⚠️</div>
          <p className="text-red-500 text-sm">Error loading data</p>
          <p className="text-gray-500 text-xs mt-1">
            Please try refreshing the page
          </p>
        </div>
      </div>
    );
  }

  // Empty state - show when no data is available
  if (event.length === 0 && dataLoaded) {
    return (
      <div className="px-2 py-[.2rem] lg:py-1 xl:py-1 2xl:py-1 h-[26vh] border-1 rounded-lg mb-2 w-full bg-white shadow flex flex-col">
        {/* Heading at the top */}
        <h2 className="font-bold xl:py-1 my-1 lg:my-1 xl:my-1 text-center text-[#44546A] text-[.9375rem] lg:text-[1rem] xl:text-[1rem]">
          Upcoming Events
        </h2>

        {/* Empty state content centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-4xl text-gray-400 mb-2">📅</div>
          <p className="text-[#44546A] text-sm">No events available</p>
        </div>
      </div>
    );
  }

  return (
    <div className="px-2 py-[.2rem] lg:py-1 xl:py-1 2xl:py-1 h-[26vh] border-1 rounded-lg mb-2 w-full bg-white shadow">
      <h2 className="font-bold mb-0 xl:py-1 my-1 lg:my-1 xl:my-1 text-center text-[#44546A] text-[.9375rem] lg:text-[1rem] xl:text-[1rem]">
        Upcoming Events
      </h2>
      {filteredData.some(
        (item) => item.myEvents.length > 0 || item.virtualEvents.length > 0
      ) ? (
        <table className="w-full text-center mt-2">
          <thead className="bg-[#A1A9B4]">
            <tr className="border-b">
              <th className="p-2 text-left text-[0.75rem] lg:text-[0.75rem] xl:text-[0.75rem] text-gray-100 border-b">
                Event Type
              </th>
              <th className="p-2 text-center text-[0.75rem] lg:text-[0.75rem] xl:text-[0.75rem] text-gray-100 border-b">
                My Events
              </th>
              <th className="p-2 text-center text-[0.75rem] lg:text-[0.75rem] xl:text-[0.75rem] text-gray-100 border-b">
                Virtual Events Nationally
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((item, index) => (
              <tr
                key={index}
                className={`border-b last:border-b-0 ${
                  index % 2 === 0 ? "bg-gray-100" : "bg-white"
                }`}
              >
                <td className="p-1 lg:p-2 xl:p-1 text-left text-[#44546A] text-[0.625rem] lg:text-[0.7rem] xl:text-[0.75rem]">
                  {item.category}
                </td>
                <td
                  className="p-1 lg:p-2 xl:p-1 text-center text-[#44546A] text-[0.625rem] lg:text-[0.7rem] xl:text-[0.75rem] cursor-pointer underline"
                  onClick={() =>
                    item.myEvents.length > 0 &&
                    openModal(`My Events - ${item.category}`, item.myEvents)
                  }
                >
                  {item.myEvents.length}
                </td>
                <td
                  className="p-1 lg:p-2 xl:p-1 text-center text-[0.625rem] lg:text-[0.7rem] xl:text-[0.75rem] text-[#44546A] cursor-pointer underline"
                  onClick={() =>
                    item.virtualEvents.length > 0 &&
                    openModal(
                      `Virtual Events - ${item.category}`,
                      item.virtualEvents
                    )
                  }
                >
                  {item.virtualEvents.length}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center h-[calc(100%-60px)]">
          <div className="text-4xl text-gray-400 mb-2">📅</div>
          <p className="text-[#44546A] text-sm">No upcoming events</p>
        </div>
      )}

      {/* Modal */}
      {modalData.open && (
        <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-4 rounded-lg shadow-lg w-[40vw] max-h-[80vh]">
            <h3 className="text-lg font-bold mb-2 text-center">
              {modalData.title}
            </h3>
            <div className="max-h-[300px] overflow-y-auto">
              <table className="w-full border-collapse border border-gray-300">
                <thead className="bg-gray-200">
                  <tr>
                    <th className="border border-gray-300 px-3 py-2 text-sm text-gray-700">
                      Event Name
                    </th>
                    <th className="border border-gray-300 px-3 py-2 text-sm text-gray-700">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-300">
                  {modalData.events.length > 0 ? (
                    modalData.events.map((event, i) => (
                      <tr key={i} className="text-gray-700">
                        <td
                          className="border border-gray-300 px-3 py-2 text-sm  text-[#177DDC]"
                          onClick={() => {
                            runViewRecordEvent(event.Id.value);
                          }}
                        >
                          {event.Name.value}
                        </td>
                        <td className="border border-gray-300 px-3 py-2 text-sm">
                          {event.Status_vod__c.value}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan="2"
                        className="text-center py-3 text-gray-500"
                      >
                        No events available.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <button
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 block mx-auto"
              onClick={closeModal}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UpcomingEvents;
