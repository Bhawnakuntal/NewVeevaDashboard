import React, { useState, useRef, useEffect, useContext } from "react";
import { FaExpandAlt } from "react-icons/fa";
import { DataContext } from "../Context/DataCenter";
import WbIncandescentIcon from "@mui/icons-material/WbIncandescent";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
// import "@fontsource/open-sans";

const AllVeevaInsights = ({ onExpand, expanded }) => {
  const {
    account,
    suggestion,
    setSuggestion,
    setTcErrorState,
    loadingStates,
    dataLoaded,
    tcErrorState,
  } = useContext(DataContext); // Fetch data from context
  const scrollRef = useRef(null); // Ref to track the scroll container
  const [isLoading, setIsLoading] = useState(false); // State for loader

  // New state variables for logging responses
  const [executeResponse, setExecuteResponse] = useState(null);
  const [queryResponse, setQueryResponse] = useState(null);

  // console.log(suggestion);
  //Storing Account Id and Name
  const accountMap = new Map(
    account.map((acc) => [acc.Id.value, acc.Name.value])
  );

  // console.log(accountMap);
  const formatDate = (date) => {
    if (!(date instanceof Date)) {
      date = new Date(date);
    }

    // Get month abbreviation and year
    const options = { month: "short" };
    const month = date.toLocaleDateString("en-US", options).toUpperCase();
    // Get day and add ordinal suffix
    const day = date.getDate();
    // const dayWithSuffix = day + getOrdinalSuffix(day);

    // Get full year
    const year = date.getFullYear();

    // Assemble the final formatted date
    // return `${month}, ${dayWithSuffix} ${year}`;
    return `${month} ${day} ${year}`;
  };

  // Function to execute suggestion action and refresh data
  const excuteSuggestionAction = (suggestionId, actionType) => {
    setIsLoading(true);
    // eslint-disable-next-line
    ds.executeSuggestionAction(suggestionId, actionType)
      .then((resp) => {
        // console.log(resp);
        setExecuteResponse(resp); // Store the response for logging

        // Wait for 2 seconds before refreshing data
        setTimeout(() => {
          querySuggestion()
            .then(() => {
              setIsLoading(false);
            })
            .catch((err) => {
              console.error(err);
              setIsLoading(false);
            });
        }, 2000);
      })
      .catch((err) => {
        console.error(err);
        setExecuteResponse(err); // Store the error response
        setIsLoading(false);
      });
  };

  // Function to query suggestions
  function querySuggestion() {
    var queryConfig = {
      object: "Suggestion_vod__c",
      fields: [
        "Id",
        "Title_vod__c",
        "Posted_Date_vod__c",
        "Account_vod__c",
        "Expiration_Date_vod__c",
        "Display_Mark_As_Complete_vod__c",
        "Display_Dismiss_vod__c",
        "Reason_vod__c",
        "Priority_vod__c",
        "Marked_As_Complete_vod__c",
        "Dismissed_vod__c",
        "Reason2__c",
      ],
      sort: ["Posted_Date_vod__c DESC"],
    };
    // eslint-disable-next-line
    return ds
      .runQuery(queryConfig)
      .then(function (resp) {
        // console.log(resp);
        // Filter out suggestions older than 6 months
        const filteredData = resp.data.filter((insight) => {
          const postedDate = new Date(insight.Posted_Date_vod__c.value);
          const sixMonthsAgo = new Date();
          sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 1);
          return postedDate >= sixMonthsAgo;
        });
        // console.log("filteredData>>>", filteredData);
        setSuggestion(filteredData);
        setQueryResponse(resp); // Store the response for logging
      })
      .catch(function (err) {
        console.log(err);
        setQueryResponse(err); // Store the error response
        setTcErrorState(err);
      });
  }

  // Function to view suggestion record
  function runViewRecordAcc(id) {
    var configObject = {
      object: "Account",
      fields: { Id: id },
    };
    // eslint-disable-next-line
    ds.viewRecord(configObject).then(
      function (resp) {
        return resp;
      },
      function (err) {
        console.log(err);
      }
    );
  }

  // Loading state - show spinner when data is being fetched
  if (loadingStates.suggestion || !dataLoaded) {
    return (
      <div
        className={`shadow border-1 rounded-lg px-1 mb-2 bg-white relative transition-all duration-300 overflow-y-auto ${
          expanded
            ? "fixed top-0 left-0 w-full h-[40vh] z-50 p-"
            : "w-full h-[47vh]"
        }`}
      >
        {/* Header */}
        <div className="flex justify-between items-center sticky top-0 bg-white z-10 py-1 px-2">
          <div></div>
          <h2 className="text-[0.9375rem] font-bold mx-auto mb-2 mt-1 text-[#44546A] lg:mt-[0.55rem]">
            Veeva Insights (30 days)
          </h2>
          <div></div>
        </div>

        {/* Spinner centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center h-[calc(100%-60px)]">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-[#44546A] text-sm">Loading data...</p>
        </div>
      </div>
    );
  }

  // Error state - if there's an error loading data
  if (tcErrorState && suggestion.length === 0) {
    return (
      <div
        className={`shadow border-1 rounded-lg px-1 mb-2 bg-white relative transition-all duration-300 overflow-y-auto ${
          expanded
            ? "fixed top-0 left-0 w-full h-[40vh] z-50 p-"
            : "w-full h-[47vh]"
        }`}
      >
        {/* Header */}
        <div className="flex justify-between items-center sticky top-0 bg-white z-10 py-1 px-2">
          <div></div>
          <h2 className="text-[0.9375rem] font-bold mx-auto mb-2 mt-1 text-[#44546A] lg:mt-[0.55rem]">
            Veeva Insights (30 days)
          </h2>
          <div></div>
        </div>

        {/* Error content centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center h-[calc(100%-60px)]">
          <div className="text-4xl text-red-400 mb-2">⚠️</div>
          <p className="text-red-500 text-sm">Error loading data</p>
          <p className="text-gray-500 text-xs mt-1">
            Please try refreshing the page
          </p>
        </div>
      </div>
    );
  }

  // Empty state - show when no data is available
  if (suggestion.length === 0 && dataLoaded) {
    return (
      <div
        className={`shadow border-1 rounded-lg px-1 mb-2 bg-white relative transition-all duration-300 overflow-y-auto ${
          expanded
            ? "fixed top-0 left-0 w-full h-[40vh] z-50 p-"
            : "w-full h-[47vh]"
        }`}
      >
        {/* Header */}
        <div className="flex justify-between items-center sticky top-0 bg-white z-10 py-1 px-2">
          <div></div>
          <h2 className="text-[0.9375rem] font-bold mx-auto mb-2 mt-1 text-[#44546A] lg:mt-[0.55rem]">
            Veeva Insights (30 days)
          </h2>
          <div></div>
        </div>

        {/* Empty state content centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center h-[calc(100%-60px)]">
          <div className="text-4xl text-gray-400 mb-2">💡</div>
          <p className="text-[#44546A] text-sm">No insights available</p>
          <p className="text-gray-500 text-xs mt-1">
            No Veeva insights found for the last 30 days
          </p>
        </div>
      </div>
    );
  }

  // Filter suggestions based on expanded state
  const displayedSuggestions = expanded
    ? suggestion
    : suggestion.filter((insight) => {
        const isCompletedOrDismissed =
          Number(insight.Marked_As_Complete_vod__c.value) === 1 ||
          Number(insight.Dismissed_vod__c.value) === 1;
        return !isCompletedOrDismissed;
      });

  return (
    <div
      ref={scrollRef}
      className={`shadow border-1 rounded-lg  px-1 mb-2 bg-white relative transition-all duration-300 overflow-y-auto ${
        expanded
          ? "fixed top-0 left-0 w-full h-[40vh] z-50 p-"
          : "w-full h-[47vh]"
      }`}
    >
      {/* Header with Expand or Collapse Button */}
      {/* <div className="flex justify-between items-center sticky top-[-10px] bg-white z-10"> */}
      <div className="flex justify-between items-center sticky top-0 bg-white z-10 py-1 px-2">
        <div></div>
        <h2 className="text-[0.9375rem] font-bold mx-auto mb-2 mt-1 text-[#44546A] lg:mt-[0.55rem]">
          Veeva Insights (30 days)
        </h2>
        {expanded ? (
          <button
            className="cursor-pointer text-[1.5rem] absolute right-2 top-2"
            onClick={onExpand}
          >
            ✕
          </button>
        ) : (
          <FaExpandAlt
            onClick={onExpand}
            className="cursor-pointer text-[#44546A] text-[1.25rem]"
          />
        )}
      </div>

      {/* Loader or Insights List */}
      {isLoading ? (
        <div className="flex justify-center items-center mt-4">
          <p>Loading...</p>
        </div>
      ) : (
        <ul className="space-y-2 mt-2">
          {displayedSuggestions.map((insight, index) => {
            const isCompletedOrDismissed =
              Number(insight.Marked_As_Complete_vod__c.value) === 1 ||
              Number(insight.Dismissed_vod__c.value) === 1;

            return (
              <li key={index} className="flex justify-between items-start px-2">
                <div className="flex items-start space-x-2 flex-grow">
                  {/* Icon based on Priority_vod__c.value */}
                  {insight.Priority_vod__c.value === "Urgent_vod" ? (
                    <NotificationsNoneIcon
                      className="text-[#FF0000] flex-shrink-0 mt-1"
                      fontSize="small"
                    />
                  ) : (
                    <WbIncandescentIcon
                      className="text-[#177DDC] flex-shrink-0 mt-1 transform rotate-180"
                      fontSize="small"
                    />
                  )}
                  <div className="flex flex-col w-full">
                    {/* Heading */}
                    <p
                      className={`text-[0.7rem]  ${
                        isCompletedOrDismissed
                          ? "text-gray-400"
                          : expanded
                          ? // ? "text-[#177DDC] font-semibold w-[100%]"
                            "text-[#177DDC] font-semibold w-[100%]"
                          : "text-[#44546A] font-semibold lg:text-[.75rem] w-[95%]"
                      }`}
                    >
                      <span
                        className="block text-[#177DDC]"
                        onClick={() => {
                          runViewRecordAcc(insight.Account_vod__c.value);
                        }}
                      >
                        {accountMap.get(insight.Account_vod__c.value)}
                      </span>
                      <span className="block">
                        {insight.Title_vod__c.value || "N/A"}
                      </span>
                    </p>
                    {/* Reason (only in expanded view) */}
                    {expanded && (
                      <p
                        className={`text-[.625rem] font-semibold ${
                          isCompletedOrDismissed
                            ? "text-gray-400"
                            : "text-gray-500"
                        } w-[100%]`}
                      >
                        Reason: {insight.Reason2__c?.value || "N/A"}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col justify-start items-end w-[30%]">
                    {/* Expiration Date */}
                    <p
                      className={`text-[0.8rem] my-1 ${
                        isCompletedOrDismissed
                          ? "text-gray-400"
                          : "text-gray-500"
                      }`}
                    >
                      {formatDate(insight.Posted_Date_vod__c.value)}
                    </p>
                    {/* Buttons */}
                    {!isCompletedOrDismissed && (
                      <div
                        className={`flex items-center ${
                          expanded ? "" : "lg:w-[120%] w-[120%]"
                        }`}
                      >
                        <span
                          className="text-[#177DDC] cursor-pointer text-[0.625rem] font-semibold"
                          onClick={() =>
                            excuteSuggestionAction(insight.Id.value, "complete")
                          }
                        >
                          Actionable
                        </span>
                        <span className="mx-1 text-[0.625rem] text-[#4F5D72]">
                          |
                        </span>
                        {/* text-[#4F5D72]  */}
                        <span
                          className="cursor-pointer text-[.625rem] text-[#177DDC] font-semibold"
                          onClick={() =>
                            excuteSuggestionAction(insight.Id.value, "dismiss")
                          }
                        >
                          No Action
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};

export default AllVeevaInsights;
