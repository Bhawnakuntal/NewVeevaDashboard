import React from "react";

const News = () => {
  return (
    <div className="shadow w-full h-[16vh] border-1 rounded-lg bg-white text-center font-bold text-[#535252] text-[1rem] mb-2 flex flex-col">
      <h1 className="text-[.9375rem] w-full text-[#44546A] font-bold mt-2">
        Field Notices
      </h1>
      <div className="flex-grow flex items-center justify-center">
        <span className="text-[0.8rem] px-4">
          CONFIDENTIAL. FOR BACKGROUND USE ONLY. NOT FOR DISPLAY OR
          DISTRIBUTION.
        </span>
      </div>
    </div>
  );
};

export default News;
