import React, { useState, useContext, useEffect, useRef } from "react";
import * as d3 from "d3";
import { DataContext } from "../Context/DataCenter";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";

// Hard-coded color palette
const colorPalette = {
  "EYLEA HD": "#32D000",
  "EYLEA 2mg": "#0056B3",
  faricimab: "#B4B52A",
  "bevacizumab est.": "#919191",
  ranibizumab: "#9D52C6 ",
  "ranibizumab biosimilars": "#71498D",
  PAVBLU: "#466490",
  "other branded": "#AAD1EE",
};

// Predefined order of products
const productOrder = [
  "EYLEA HD",
  "EYLEA 2mg",
  "faricimab",
  "bevacizumab est.",
  "ranibizumab",
  "ranibizumab biosimilars",
  "PAVBLU",
  "other branded",
];

// Map product name to canonical key
const getFuzzyKey = (productName) => {
  const lowerCaseName = productName.toLowerCase();
  for (const key of Object.keys(colorPalette)) {
    if (lowerCaseName === key.toLowerCase()) {
      return key;
    }
  }
  return "other branded";
};

// Calculate the data cutoff date
const getFormattedDate = () => {
  const today = new Date();
  const dayOfWeek = today.getDay();
  const lastSunday = new Date(today);
  lastSunday.setDate(today.getDate() - today.getDay());

  const daysToSubtract = dayOfWeek >= 3 ? 14 : 21;
  const finalDate = new Date(lastSunday);
  finalDate.setDate(lastSunday.getDate() - daysToSubtract);

  return finalDate
    .toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
    .toUpperCase()
    .replace(",", "");
};

const CategoryShare = () => {
  const { category, timePeriod, loadingStates, dataLoaded, tcErrorState } =
    useContext(DataContext);
  const chartRef = useRef(null);
  const [showTooltip, setShowTooltip] = useState(false);

  const formattedDate = getFormattedDate();

  // Aggregate and calculate data
  const prepareData = () => {
    const data = { QTD: {}, C13W: {} };

    // Initialize all products
    productOrder.forEach((key) => {
      data.QTD[key] = {
        channel: key,
        units: 0,
        change: 0,
        changeUnits: 0,
        color: colorPalette[key],
      };
      data.C13W[key] = {
        channel: key,
        units: 0,
        change: 0,
        changeUnits: 0,
        color: colorPalette[key],
      };
    });

    // Sum units and changes
    category.forEach((item) => {
      const fuzzyKey = getFuzzyKey(item.REG_Product_Name__c.value.trim());

      data.QTD[fuzzyKey].units += parseFloat(item.REG_QTD_Units__c.value) || 0;
      data.QTD[fuzzyKey].change +=
        parseFloat(item.REG_ChangevsPFQ__c.value) || 0;
      data.QTD[fuzzyKey].changeUnits +=
        parseFloat(item.REG_QTDvsPFQ_Changed_Units__c.value) || 0;

      data.C13W[fuzzyKey].units +=
        parseFloat(item.REG_C13W_Units__c.value) || 0;
      data.C13W[fuzzyKey].change +=
        parseFloat(item.REG_ChangevsP13W__c.value) || 0;
      data.C13W[fuzzyKey].changeUnits +=
        parseFloat(item.REG_C13W_vs_P13W_Changed_Units__c.value) || 0;
    });

    // Calculate total units
    const totalQTDUnits = Object.values(data.QTD).reduce(
      (sum, item) => sum + item.units,
      0
    );
    const totalC13WUnits = Object.values(data.C13W).reduce(
      (sum, item) => sum + item.units,
      0
    );

    // Calculate shares based on units
    Object.keys(data.QTD).forEach((key) => {
      data.QTD[key].share =
        totalQTDUnits > 0
          ? parseFloat(((data.QTD[key].units / totalQTDUnits) * 100).toFixed(1))
          : 0;
      data.C13W[key].share =
        totalC13WUnits > 0
          ? parseFloat(
              ((data.C13W[key].units / totalC13WUnits) * 100).toFixed(1)
            )
          : 0;
    });

    // Convert to sorted arrays
    const sortFn = (a, b) =>
      productOrder.indexOf(a.channel) - productOrder.indexOf(b.channel);
    return {
      QTD: Object.values(data.QTD).sort(sortFn),
      C13W: Object.values(data.C13W).sort(sortFn),
    };
  };

  // Draw stacked bar chart - FIXED with proper null checks
  const drawChart = (dataForChart) => {
    // Check if ref exists first - like your handleScroll pattern
    if (!chartRef.current) return;

    const svg = d3.select(chartRef.current);
    svg.selectAll("*").remove();

    // Get SVG node and check if it exists
    const svgNode = svg.node();
    if (!svgNode) return;

    // Safe bounding client rect access
    const rect = svgNode.getBoundingClientRect();
    if (!rect) return;

    const { width, height } = rect;

    // Ensure valid dimensions
    if (width === 0 || height === 0) return;

    const margin = { top: 0, right: 0, bottom: 30, left: 0 };

    const yScale = d3
      .scaleLinear()
      .domain([0, 100])
      .range([height - margin.bottom, margin.top]);

    let accumulatedHeight = 0;
    dataForChart.forEach((d) => {
      const barHeight = yScale(0) - yScale(d.share);
      svg
        .append("rect")
        .attr("x", margin.left + width / 2 - 20)
        .attr("y", yScale(accumulatedHeight + d.share))
        .attr("width", 60)
        .attr("height", barHeight)
        .attr("fill", d.color);

      accumulatedHeight += d.share;
    });
  };

  // Redraw chart when data changes - FIXED with safe conditions
  useEffect(() => {
    // Only draw chart if all conditions are met
    if (category.length > 0 && dataLoaded && !loadingStates.category) {
      const data = prepareData();
      const chartData = [...data[timePeriod]].reverse();
      drawChart(chartData);
    }
  }, [category, timePeriod, dataLoaded, loadingStates.category]);

  // Loading state - show spinner when data is being fetched
  if (loadingStates.category || !dataLoaded) {
    return (
      <div className="bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[43vh]">
        {/* Heading at the top */}
        <h3 className="font-bold text-[.9375rem] text-[#44546A] text-center">
          {timePeriod === "QTD"
            ? "QTD aVEGF Category Share"
            : "C13W aVEGF Category Share"}
        </h3>

        {/* Spinner centered in remaining space */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-2 text-[#44546A] text-sm">Loading data...</p>
        </div>
      </div>
    );
  }

  // Error state - if there's an error loading data
  if (tcErrorState && category.length === 0) {
    return (
      <div className="bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[43vh] items-center justify-center">
        <h3 className="font-bold text-[.9375rem] mb-[.8rem] text-[#44546A]">
          {timePeriod === "QTD"
            ? "QTD aVEGF Category Share"
            : "C13W aVEGF Category Share"}
        </h3>
        <div className="flex flex-col items-center justify-center">
          <div className="text-4xl text-red-400 mb-2">⚠️</div>
          <p className="text-red-500 text-sm">Error loading data</p>
          <p className="text-gray-500 text-xs mt-1">
            Please try refreshing the page
          </p>
        </div>
      </div>
    );
  }

  // Empty state - show when no data is available
  if (category.length === 0 && dataLoaded) {
    return (
      <div className="bg-white px-4 pt-[.8rem] border-1 rounded-lg mb-2 shadow flex flex-col w-full min-h-[43vh] items-center justify-center">
        <h3 className="font-bold text-[.9375rem] mb-[.8rem] text-[#44546A]">
          {timePeriod === "QTD"
            ? "QTD aVEGF Category Share"
            : "C13W aVEGF Category Share"}
        </h3>
        <div className="flex flex-col items-center justify-center">
          <div className="text-4xl text-gray-400 mb-2">📊</div>
          <p className="text-[#44546A] text-sm">No data available</p>
        </div>
      </div>
    );
  }

  const tableData = prepareData()[timePeriod];

  return (
    <div className="mb-2 py-[.3rem] lg:py-[.3rem] xl:py-[.3rem] h-[43vh] border-1 rounded-lg bg-white w-full shadow">
      {/* Header */}
      <div className="flex flex-row justify-between">
        {/* Tooltip */}
        <div className="top-0">
          <div className="text-left">
            <button
              type="button"
              className="focus:outline-none"
              onClick={() => setShowTooltip(!showTooltip)}
            >
              <InfoOutlinedIcon className="text-gray-600 ml-2" />
            </button>
            {showTooltip && (
              <div className="absolute z-20 mt-2 w-40 bg-white border border-gray-300 rounded shadow-lg">
                <div className="px-2 py-2 text-sm text-gray-700">
                  Sales data through {formattedDate}, Competitive data through{" "}
                  {formattedDate}
                </div>
              </div>
            )}
          </div>
        </div>
        <h1 className="text-center text-[.9375rem] text-[#44546A] font-bold pb-[0.45rem] pt-[.2rem] pl-2">
          {timePeriod === "QTD"
            ? "QTD aVEGF Category Share"
            : "C13W aVEGF Category Share"}
        </h1>
        <div></div>
      </div>

      {/* Main Layout */}
      <div className="flex h-full items-stretch">
        {/* Stacked Bar Chart */}
        <div className="w-[17%] lg:w-[17%] xl:mt-[0rem] flex items-center justify-center h-full">
          <svg ref={chartRef} className="w-[72%] h-full object-contain"></svg>
        </div>

        {/* Data Table */}
        <div className="w-[100%] text-sm mt-0 mx-[2px] h-full">
          <div className="max-h-[92%] overflow-y-auto">
            <table className="h-full w-full">
              <thead className="bg-[#A1A9B4] text-white sticky top-0">
                <tr>
                  <th className="p-1 lg:p-2 text-left text-[0.75rem] lg:text-[.825rem] xl:p-1">
                    Product
                  </th>
                  <th className="p-1 lg:p-2 text-center text-[0.75rem] lg:text-[.825rem] xl:p-1">
                    % Share
                  </th>
                  <th className="p-1 lg:p-2 text-center text-[0.75rem] lg:text-[.825rem] xl:p-1">
                    Units
                  </th>
                  <th className="p-1 lg:p-2 text-center text-[0.75rem] lg:text-[.825rem] xl:p-1">
                    vs {timePeriod === "QTD" ? "PFQ" : "P13W"}
                  </th>
                </tr>
              </thead>
              <tbody>
                {tableData.map((item, index) => (
                  <tr
                    key={index}
                    className={`text-[#44546A] ${
                      index % 2 === 0 ? "bg-[#F2F2F2]" : "bg-white"
                    }`}
                  >
                    <td className="p-1 lg:p-2 xl:p-[5.5px] items-center ">
                      <span
                        className="inline-block w-2 h-2 mr-2 rounded"
                        style={{ backgroundColor: item.color }}
                      ></span>
                      <span className="text-[#44546A] text-[0.625rem] lg:text-[0.75rem]">
                        {item.channel === "ranibizumab biosimilars"
                          ? "ranibizumab biosims"
                          : item.channel === "PAVBLU"
                          ? "aflibercept biosims"
                          : item.channel}
                      </span>
                    </td>
                    <td className="p-1 lg:p-2 xl:p-[5.5px] text-center text-[0.625rem] lg:text-[0.75rem]">
                      {item.share}%
                    </td>
                    <td className="p-1 lg:p-2 xl:p-[5.5px] text-center text-[0.625rem] lg:text-[0.75rem]">
                      {item.units.toLocaleString("en-US")}
                    </td>
                    <td className="p-1 lg:p-2 xl:p-[5.5px] text-center text-[0.625rem] lg:text-[0.75rem]">
                      <div className="flex justify-start items-center">
                        {item.change > 0 ? (
                          <span className="flex items-center text-[#44546A]">
                            ▲
                            <span className="ml-1">
                              {Math.abs(item.change) > 10
                                ? Math.round(item.change)
                                : item.change.toFixed(1)}
                              % ({item.changeUnits.toLocaleString("en-US")})
                            </span>
                          </span>
                        ) : (
                          <span className="flex items-center text-[#44546A]">
                            ▼
                            <span className="ml-1">
                              {Math.abs(item.change) > 10
                                ? Math.round(Math.abs(item.change))
                                : Math.abs(item.change).toFixed(1)}
                              % ({item.changeUnits.toLocaleString("en-US")})
                            </span>
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryShare;
