import React, { createContext, useState, useEffect } from "react";
import mockAdapter from "../utils/mockAdapter";
import * as util from "../utils/util";

// Import mock data (these will only be used by the mock adapter)
import CateData from "../data/CategoryShare.json";
import RegionAvg from "../data/RegionAvg.json";
import suggestions from "../data/suggestion.json";
import User from "../data/User.json";
import elyeaData from "../data/EyleaHDUnits.json";
import PortfolioData from "../data/PortfolioComposition.json";
import callData from "../data/engagementData.json";
import UserTerLink from "../data/Ter2Association.json";
import expandedEnagement from "../data/expEngagementData.json";
import account22 from "../data/Account.json";
import event11 from "../data/Events.json";
import territory2 from "../data/Territory.json";

// Environment-based data source selector
const isLocalDevelopment =
  window.location.hostname === "localhost" || !window.ds;

const ds = isLocalDevelopment ? mockAdapter : window.ds;

export const DataContext = createContext();

export const DataContextProvider = ({ children }) => {
  // Initialize states based on environment
  const [userId, setUserId] = useState(
    isLocalDevelopment ? { Id: "005360000035yy0AAA" } : null
  );
  const [category, setCategory] = useState(isLocalDevelopment ? CateData : []);
  const [suggestion, setSuggestion] = useState(
    isLocalDevelopment ? suggestions : []
  );
  const [user, setUser] = useState(isLocalDevelopment ? User : []);
  const [elyea, setElyea] = useState(isLocalDevelopment ? elyeaData : []);
  const [portfolio, setPortfolio] = useState(
    isLocalDevelopment ? PortfolioData : []
  );
  const [engagementData, setEngagementData] = useState(
    isLocalDevelopment ? callData : []
  );
  const [userTerLink, setUserTerLink] = useState(
    isLocalDevelopment ? UserTerLink : []
  );
  const [allTerritories, setAllTerritories] = useState(
    isLocalDevelopment ? territory2 : []
  );
  const [userTerritory, setUserTerritory] = useState(null);
  const [childTerritories, setChildTerritories] = useState([]);
  const [territoryNamesSet, setTerritoryNamesSet] = useState(new Set());
  const [regionAvg, setRegionAvg] = useState(
    isLocalDevelopment ? RegionAvg : []
  );
  const [terId, setTerId] = useState([]);
  const [expEngagementData, setExpEnagementData] = useState(
    isLocalDevelopment ? expandedEnagement : []
  );
  const [account, setAccount] = useState(isLocalDevelopment ? account22 : []);
  const [event, setEvent] = useState(isLocalDevelopment ? event11 : []);

  const [mergedPortfolio, setMergedPortfolio] = useState();
  const [expMergedData, setExpMergedData] = useState();
  const [tcErrorState, setTcErrorState] = useState(null);
  const [errorState, setErrorState] = useState(null);
  const [timePeriod, setTimePeriod] = useState("QTD");
  const [dataDate, setDataDate] = useState("");

  // Add loading states for each data type
  const [loadingStates, setLoadingStates] = useState({
    userId: true,
    userTerLink: false,
    allTerritories: false,
    userData: false,
    account: false,
    suggestion: false,
    eventData: false,
    regionAvg: false,
    elyea: false,
    portfolio: false,
    engagementData: false,
    expEngagementData: false,
    category: false,
  });

  const [overallLoading, setOverallLoading] = useState(true);
  const [dataLoaded, setDataLoaded] = useState(false);

  // Step 1: Query userId on mount
  useEffect(() => {
    try {
      queryUserId();
    } catch (err) {
      setTcErrorState(err);
      setLoadingStates((prev) => ({ ...prev, userId: false }));
    }
  }, []);

  // Step 2: Once userId is available, trigger ALL independent queries immediately
  useEffect(() => {
    if (userId) {
      // Start territory hierarchy chain
      queryUserTerritoryData();

      // Start all independent queries in parallel (no need to wait for territory)
      queryUserData();
      queryAccount();
      querySuggestion();
      queryEventData();
      regionAvgFet();
    }
  }, [userId]);

  // Step 3: Once userTerLink is available, query all territories
  useEffect(() => {
    if (userTerLink.length > 0) {
      queryAllTerritories();
    }
  }, [userTerLink]);

  // Step 4: Once all territories are loaded, find hierarchical children
  useEffect(() => {
    if (allTerritories.length > 0 && terId) {
      findUserTerritory();
      findAllChildTerritories();
    }
  }, [allTerritories, terId]);

  // Step 5: Create territory names set once hierarchy is established
  useEffect(() => {
    if (userTerritory && childTerritories.length >= 0) {
      buildTerritoryNamesSet();
    }
  }, [userTerritory, childTerritories]);

  // Step 6: Once territory names set is ready, load ONLY territory-filtered data
  useEffect(() => {
    if (territoryNamesSet.size > 0) {
      // Only queries that actually need territory filtering
      OmnichannelData();
      OmnichannelDataExp();
      CategoryShareData();
      PortfolioDatafetcher();
      HCOTerritoryDetailData();
    }
  }, [territoryNamesSet]);

  // Track when all essential data is loaded
  useEffect(() => {
    const essentialDataLoaded =
      userId &&
      userTerLink.length > 0 &&
      allTerritories.length > 0 &&
      territoryNamesSet.size > 0 &&
      !loadingStates.elyea &&
      !loadingStates.portfolio &&
      !loadingStates.engagementData &&
      !loadingStates.category;

    if (essentialDataLoaded) {
      setOverallLoading(false);
      setDataLoaded(true);
    }
  }, [userId, userTerLink, allTerritories, territoryNamesSet, loadingStates]);

  function queryUserId() {
    setLoadingStates((prev) => ({ ...prev, userId: true }));

    ds.getDataForCurrentObject("User", "Id").then(
      function (resp) {
        setUserId(resp.User);
        setLoadingStates((prev) => ({ ...prev, userId: false }));
      },
      function (err) {
        console.log(err);
        setErrorState(err || "Error getting User Id");
        setLoadingStates((prev) => ({ ...prev, userId: false }));
      }
    );
  }

  const queryUserTerritoryData = () => {
    setLoadingStates((prev) => ({ ...prev, userTerLink: true }));

    const queryConfig = {
      object: "UserTerritory2Association",
      fields: ["Id", "UserId", "Territory2Id"],
      where: `UserId = '${userId.Id}'`,
    };

    ds.runQuery(queryConfig)
      .then((resp) => {
        setUserTerLink(resp.data);
        if (resp.data && resp.data.length > 0) {
          setTerId(resp.data[0].Territory2Id.value);
        }
      })
      .catch((err) => {
        console.log(err);
        setTcErrorState(err || "Error querying UserTerritory2Association");
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, userTerLink: false }));
      });
  };

  const queryAllTerritories = () => {
    setLoadingStates((prev) => ({ ...prev, allTerritories: true }));

    const queryConfig = {
      object: "Territory2",
      fields: ["Id", "DeveloperName", "Name", "ParentTerritory2Id"],
    };

    ds.runQuery(queryConfig)
      .then((resp) => {
        setAllTerritories(resp.data);
      })
      .catch((err) => {
        console.log(err);
        setTcErrorState(err || "Error querying all territories");
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, allTerritories: false }));
      });
  };

  const findUserTerritory = () => {
    const territory = allTerritories.find((ter) => ter.Id.value === terId);
    if (territory) {
      setUserTerritory(territory);
    }
  };

  const findAllChildTerritories = () => {
    const children = [];

    // Recursive function to find all descendants
    const findChildren = (parentId) => {
      const directChildren = allTerritories.filter(
        (ter) => ter.ParentTerritory2Id?.value === parentId
      );

      directChildren.forEach((child) => {
        children.push({
          id: child.Id.value,
          name: child.Name.value,
          developerName: child.DeveloperName.value,
          parentId: child.ParentTerritory2Id?.value,
          level: getLevel(child.Id.value),
        });

        // Recursively find children of this child
        findChildren(child.Id.value);
      });
    };

    // Helper function to determine hierarchy level
    const getLevel = (territoryId, level = 1) => {
      const territory = allTerritories.find(
        (ter) => ter.Id.value === territoryId
      );
      if (!territory || !territory.ParentTerritory2Id?.value) {
        return level;
      }
      if (territory.ParentTerritory2Id.value === terId) {
        return level;
      }
      return getLevel(territory.ParentTerritory2Id.value, level + 1);
    };

    // Start the recursive search from user's territory
    findChildren(terId);

    setChildTerritories(children);
  };

  const buildTerritoryNamesSet = () => {
    const namesSet = new Set();

    // Add current user's territory name
    if (userTerritory && userTerritory.Name?.value) {
      namesSet.add(userTerritory.Name.value);
    }

    // Add all child territory names
    childTerritories.forEach((child) => {
      if (child.name && !child.name.startsWith("OD")) {
        namesSet.add(child.name);
      }
    });

    setTerritoryNamesSet(namesSet);
  };

  const queryUserData = () => {
    setLoadingStates((prev) => ({ ...prev, userData: true }));

    const queryConfig = {
      object: "User",
      fields: ["Id", "Profile_Name_vod__c", "Country", "Name", "Title"],
      where: `Id = '${userId.Id}'`,
    };

    ds.runQuery(queryConfig)
      .then((resp) => {
        setUser(resp.data);
      })
      .catch((err) => {
        console.log(err);
        setTcErrorState(err || "Error querying data");
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, userData: false }));
      });
  };

  function queryAccount() {
    setLoadingStates((prev) => ({ ...prev, account: true }));

    var queryConfig = {
      object: "Account",
      fields: ["Id", "Name", "Primary_Parent_vod__c"],
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setAccount(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setTcErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, account: false }));
      });
  }

  function querySuggestion() {
    setLoadingStates((prev) => ({ ...prev, suggestion: true }));

    var queryConfig = {
      object: "Suggestion_vod__c",
      fields: [
        "Id",
        "Title_vod__c",
        "Posted_Date_vod__c",
        "Account_vod__c",
        "Expiration_Date_vod__c",
        "Display_Mark_As_Complete_vod__c",
        "Display_Dismiss_vod__c",
        "Reason_vod__c",
        "Priority_vod__c",
        "Marked_As_Complete_vod__c",
        "Dismissed_vod__c",
        "Reason2__c",
      ],
      sort: ["Posted_Date_vod__c DESC"],
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        const filteredData = resp.data.filter((insight) => {
          const postedDate = new Date(insight.Posted_Date_vod__c.value);
          const oneMonthsAgo = new Date();
          oneMonthsAgo.setMonth(oneMonthsAgo.getMonth() - 1);
          return postedDate >= oneMonthsAgo;
        });
        setSuggestion(filteredData);
      })
      .catch(function (err) {
        console.log(err);
        setTcErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, suggestion: false }));
      });
  }

  function HCOTerritoryDetailData() {
    setLoadingStates((prev) => ({ ...prev, elyea: true }));

    const territoryNames = Array.from(territoryNamesSet);
    const inStatement = util.getInStatementArray(territoryNames);

    var queryConfig = {
      object: "REG_HCOTerritoryDetail__c",
      fields: [
        "Id",
        "REG_UserTerritoryID__c",
        "REG_Account__c",
        "REG_ProductName__c",
        "REG_DEMSTerr__c",
        "REG_MSTerr__c",
        "REG_NavigatorAccountGroup__c",
        "REG_AccountName__c",
        "REG_AccountAddress__c",
        "REG_Account_Eylea_Quintile__c",
        "REG_PE_if_Applicable__c",
        "REG_Date_of_last_Order__c",
        "REG_Active_Current_Insight__c",
        "REG_P13W_Volume__c",
        "REG_C13W_Volume__c",
        "REG_PerGrowthC13WvsP13W__c",
        "REG_QTD__c",
        "REG_PQTD__c",
        "REG_PFQ__c",
        "REG_PerGrowthQTDvsPFQ__c",
        "REG_VolGrowthC13WvsP13W__c",
        "REG_VolGrowthQTDvsPFQ__c",
        "REG_PFQ_Minus_1__c",
        "REG_PFQ_Minus_2__c",
        "REG_PFQ_Minus_3__c",
        "REG_ProductType__c",
      ],
      where: `REG_ProductType__c = 'all' AND REG_UserTerritoryID__c IN ${inStatement}`,
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setElyea(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, elyea: false }));
      });
  }

  function PortfolioDatafetcher() {
    setLoadingStates((prev) => ({ ...prev, portfolio: true }));

    const territoryNames = Array.from(territoryNamesSet);
    const inStatement = util.getInStatementArray(territoryNames);

    var queryConfig = {
      object: "REG_Territory_Portfolio_Composition__c",
      fields: [
        "Id",
        "REG_Territory_Name__c",
        "REG_Quintile__c",
        "REG_Region__c",
        "REG_Product_Name__c",
        "REG_NoofEYLEA2mgunitsinQTD__c",
        "REG_NoofEYLEA2mgunitsinC13W__c",
        "REG_NoofEYLEA2mgBVinQTD__c",
        "REG_NoofEYLEA2mgBVinC13W__c",
        "REG_NoofEYLEAHDunitsinQTD__c",
        "REG_NoofEYLEAHDunitsinC13W__c",
        "REG_NoofEYLEAHDBVinQTD__c",
        "REG_NoofEYLEAHDBVinC13W__c",
      ],
      where: `REG_Territory_Name__c IN ${inStatement}`,
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setPortfolio(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, portfolio: false }));
      });
  }

  function OmnichannelData() {
    setLoadingStates((prev) => ({ ...prev, engagementData: true }));

    const territoryNames = Array.from(territoryNamesSet);
    const inStatement = util.getInStatementArray(territoryNames);

    var queryConfig = {
      object: "REG_Territory_Omnichannel_Engagements__c",
      fields: [
        "Id",
        "REG_Territory_Name__c",
        "REG_Channel__c",
        "REG_Engagements_in_C13W__c",
        "REG_Per_Reach__c",
        "REG_Change_vs_P13W__c",
        "REG_Engagements_in_C13W_RS__c",
        "REG_Per_Reach_RS__c",
        "REG_Change_vs_P13W_RS__c",
        "REG_OverallReachPerC13W__c",
        "REG_PerReachC13W__c",
        "REG_OverallReachPerQTD__c",
        "REG_PerReachC13WRS__c",
        "REG_EngagementsinQTD__c",
        "REG_PerReachQTD__c",
        "REG_ChangevsPFQ__c",
        "REG_EngagementsinQTDRS__c",
        "REG_PerReachQTDRS__c",
        "REG_ChangevsPFQRS__c",
        "REG_EngagementsinC13WRS__c",
      ],
      where: `REG_Territory_Name__c IN ${inStatement}`,
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setEngagementData(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, engagementData: false }));
      });
  }

  function OmnichannelDataExp() {
    setLoadingStates((prev) => ({ ...prev, expEngagementData: true }));

    const territoryNames = Array.from(territoryNamesSet);
    const inStatement = util.getInStatementArray(territoryNames);

    var queryConfig = {
      object: "REG_Territory_Omnichannel_Eng_Expansion__c",
      fields: [
        "Id",
        "REG_TerritoryName__c",
        "REG_Account__c",
        "REG_Timeframe__c",
        "REG_AccountName__c",
        "REG_IsRSTarget__c",
        "REG_MSF2FEngagement__c",
        "REG_DEMSF2FEngagement__c",
        "REG_PromoProgEngagement__c",
        "REG_VirtualEngagement__c",
        "REG_RTEEngagement__c",
        "REG_EmailEngagement__c",
        "REG_WebEngagement__c",
        "REG_MediaEngagement__c",
        "REG_CongressEngagement__c",
        "REG_AllF2FEngagement__c",
        "REG_MyF2FEngagement__c",
        "REG_AllPromoProgram__c",
        "REG_MyPromoProgram__c",
        "REG_AllRTEEngagement__c",
        "REG_MyRTEEngagement__c",
        "REG_AllVirtualEngagement__c",
        "REG_MyVirtualEngagement__c",
        "REG_MSDEMSpartnerf2fengagement__c",
        "REG_RBMpartnerf2f2engagement__c",
        "REG_AllVirtualPromoProgram__c",
        "REG_MyVirtualPromoProgram__c",
      ],
      where: `REG_TerritoryName__c IN ${inStatement}`,
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setExpEnagementData(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, expEngagementData: false }));
      });
  }

  function CategoryShareData() {
    setLoadingStates((prev) => ({ ...prev, category: true }));

    const territoryNames = Array.from(territoryNamesSet);
    const inStatement = util.getInStatementArray(territoryNames);

    var queryConfig = {
      object: "REG_Territory_Category_Share__c",
      fields: [
        "Id",
        "REG_Territory_Name__c",
        "REG_Product_Name__c",
        "REG_C13WPerVEGFshare__c",
        "REG_ChangevsP13W__c",
        "REG_QTDPerVEGFshare__c",
        "REG_ChangevsPFQ__c",
        "REG_C13W_Units__c",
        "REG_QTD_Units__c",
        "REG_C13W_vs_P13W_Changed_Units__c",
        "REG_QTDvsPFQ_Changed_Units__c",
      ],
      where: `REG_Territory_Name__c IN ${inStatement}`,
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setCategory(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, category: false }));
      });
  }

  function regionAvgFet() {
    setLoadingStates((prev) => ({ ...prev, regionAvg: true }));

    var queryConfig = {
      object: "REG_RegionalAverage__c",
      fields: [
        "Id",
        "REG_Region__c",
        "REG_OverallRegPerQTD__c",
        "REG_OverallRegPerC13W__c",
        "REG_Q1RegPerQTD__c",
        "REG_Q2RegPerQTD__c",
        "REG_Q3RegPerQTD__c",
        "REG_Q4RegPerQTD__c",
        "REG_Q5RegPerQTD__c",
        "REG_Q1RegPerC13W__c",
        "REG_Q2RegPerC13W__c",
        "REG_Q3RegPerC13W__c",
        "REG_Q4RegPerC13W__c",
        "REG_Q5RegPerC13W__c",
        "REG_Subject__c",
      ],
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setRegionAvg(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, regionAvg: false }));
      });
  }

  function queryEventData() {
    setLoadingStates((prev) => ({ ...prev, eventData: true }));

    var queryConfig = {
      object: "Medical_Event_vod__c",
      fields: [
        "Id",
        "Name",
        "PW_Product__c",
        "Status_vod__c",
        "OwnerId",
        "PW_Event_Type__c",
        "PW_Event_Format__c",
        "End_Date_vod__c",
      ],
      where: `Status_vod__c = 'Pending' OR Status_vod__c = 'Confirmed'`,
    };

    ds.runQuery(queryConfig)
      .then(function (resp) {
        setEvent(resp.data);
      })
      .catch(function (err) {
        console.log(err);
        setTcErrorState(err);
      })
      .finally(() => {
        setLoadingStates((prev) => ({ ...prev, eventData: false }));
      });
  }

  useEffect(() => {
    const mergeExpandedEngagementWithAccount = () => {
      const mergedData = expEngagementData.map((engagementItem) => {
        const accountMatch = account.find(
          (accountItem) =>
            accountItem.Id.value === engagementItem.REG_Account__c.value
        );

        if (accountMatch) {
          const primaryParent = account.find(
            (accountItem) =>
              accountItem.Id.value === accountMatch.Primary_Parent_vod__c?.value
          );

          return {
            ...engagementItem,
            primaryParentId: primaryParent
              ? primaryParent.Id?.value
              : engagementItem.REG_Account__c.value,
            primaryParentName: primaryParent
              ? primaryParent.Name?.value
              : "Not Available",
          };
        }

        return {
          ...engagementItem,
          primaryParentId: engagementItem.REG_Account__c.value,
          primaryParentName: "Not Available",
        };
      });

      setExpMergedData(mergedData);
    };

    if (expEngagementData.length > 0 && account.length > 0) {
      mergeExpandedEngagementWithAccount();
    }
  }, [expEngagementData, account]);

  useEffect(() => {
    const mergePortfolioAndRegion = () => {
      const merged = portfolio.flatMap((portfolioItem) => {
        const unitData = regionAvg.filter(
          (item) =>
            item.REG_Region__c?.value === portfolioItem.REG_Region__c?.value &&
            item.REG_Subject__c?.value === "units"
        );
        const bvData = regionAvg.filter(
          (item) =>
            item.REG_Region__c?.value === portfolioItem.REG_Region__c?.value &&
            item.REG_Subject__c?.value === "BV"
        );

        const quintile = portfolioItem.REG_Quintile__c.value;
        let quintileFieldQTD, quintileFieldC13W;

        switch (quintile) {
          case "1":
            quintileFieldQTD = "REG_Q1RegPerQTD__c";
            quintileFieldC13W = "REG_Q1RegPerC13W__c";
            break;
          case "2":
            quintileFieldQTD = "REG_Q2RegPerQTD__c";
            quintileFieldC13W = "REG_Q2RegPerC13W__c";
            break;
          case "3":
            quintileFieldQTD = "REG_Q3RegPerQTD__c";
            quintileFieldC13W = "REG_Q3RegPerC13W__c";
            break;
          case "4":
            quintileFieldQTD = "REG_Q4RegPerQTD__c";
            quintileFieldC13W = "REG_Q4RegPerC13W__c";
            break;
          case "5":
            quintileFieldQTD = "REG_Q5RegPerQTD__c";
            quintileFieldC13W = "REG_Q5RegPerC13W__c";
            break;
          default:
            quintileFieldQTD = null;
            quintileFieldC13W = null;
            break;
        }

        const unitItem = {
          ...portfolioItem,
          REG_Subject__c: "units",
          matchingRegionData: unitData,
          [quintileFieldQTD]: unitData[0]?.[quintileFieldQTD]?.value,
          [quintileFieldC13W]: unitData[0]?.[quintileFieldC13W]?.value,
          REG_Region__c: unitData[0]?.REG_Region__c?.value,
          REG_OverallRegPerQTD__c: unitData[0]?.REG_OverallRegPerQTD__c?.value,
          REG_OverallRegPerC13W__c:
            unitData[0]?.REG_OverallRegPerC13W__c?.value,
        };

        const bvItem = {
          ...portfolioItem,
          REG_Subject__c: "BV",
          matchingRegionData: bvData,
          [quintileFieldQTD]: bvData[0]?.[quintileFieldQTD]?.value,
          [quintileFieldC13W]: bvData[0]?.[quintileFieldC13W]?.value,
          REG_Region__c: bvData[0]?.REG_Region__c?.value,
          REG_OverallRegPerQTD__c: bvData[0]?.REG_OverallRegPerQTD__c?.value,
          REG_OverallRegPerC13W__c: bvData[0]?.REG_OverallRegPerC13W__c?.value,
        };

        const regPerValueForUnits =
          timePeriod === "QTD"
            ? unitData[0]?.[quintileFieldQTD]?.value
            : unitData[0]?.[quintileFieldC13W]?.value;

        const regPerValueForBV =
          timePeriod === "QTD"
            ? bvData[0]?.[quintileFieldQTD]?.value
            : bvData[0]?.[quintileFieldC13W]?.value;

        unitItem.regPerValue = isNaN(parseFloat(regPerValueForUnits))
          ? null
          : parseFloat(regPerValueForUnits);
        bvItem.regPerValue = isNaN(parseFloat(regPerValueForBV))
          ? null
          : parseFloat(regPerValueForBV);

        return [unitItem, bvItem];
      });

      setMergedPortfolio(merged);
    };

    if (portfolio.length > 0 && regionAvg.length > 0) {
      mergePortfolioAndRegion();
    }
  }, [portfolio, regionAvg, timePeriod]);

  return (
    <DataContext.Provider
      value={{
        userId,
        category,
        suggestion,
        user,
        elyea,
        portfolio,
        engagementData,
        timePeriod,
        setTimePeriod,
        mergedPortfolio,
        expEngagementData,
        setExpEnagementData,
        setSuggestion,
        setTcErrorState,
        tcErrorState,
        expMergedData,
        dataDate,
        event,
        account,
        userTerritory,
        allTerritories,
        childTerritories,
        territoryNamesSet,
        // Add loading states to context
        loadingStates,
        overallLoading,
        dataLoaded,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};
