# Territory Dashboard

A React-based dashboard application for visualizing territory-level sales and engagement data for Regeneron pharmaceuticals. The dashboard provides interactive visualizations for portfolio composition, engagement metrics, and sales performance across different territories.

## Features

- **Portfolio Composition Analysis**
  - Volume and BV (Business Value) composition views
  - Territory-wise distribution of EYLEA HD and EYLEA 2mg
  - Quintile-based performance analysis
  - Regional benchmark comparisons

- **Data Visualization**
  - Interactive D3.js charts with tooltips
  - Responsive design for various screen sizes
  - Loading, error, and empty states for all components
  - Real-time data updates

- **Territory Insights**
  - QTD (Quarter to Date) and C13W (Current 13 Weeks) views
  - Regional performance benchmarks
  - Quintile-based territory grouping
  - Engagement metrics tracking

## Tech Stack

- **Frontend Framework**: React
- **UI Components**: Material-UI
- **Visualization**: D3.js
- **Styling**: Tailwind CSS
- **Data Management**: React Context API

## Project Structure

```
src/
├── components/         # React components
│   ├── AllVeevaInsights.jsx
│   ├── PortfolioComposition.jsx
│   ├── EyleaHDUnits.jsx
│   └── ...
├── Context/
│   └── DataCenter.jsx  # Centralized data management
├── data/              # Mock data for development
│   ├── Account.json
│   ├── CategoryShare.json
│   └── ...
└── utils/
    ├── mockAdapter.js # Development data adapter
    └── util.js       # Utility functions
```

## Setup

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm start
   ```

## Development Mode

The application supports two data modes:

- **Development**: Uses mock data from `src/data/*.json`
- **Production**: Connects to live data through `window.ds` adapter

Environment detection is automatic based on hostname and `window.ds` availability.

## Component Development Guidelines

1. Follow the established patterns for:
   - Data loading through DataContext
   - D3.js chart integration
   - Loading/error/empty states
   - Responsive design

2. Implement proper cleanup for D3 charts:
   ```jsx
   useEffect(() => {
     if (!data.length) return;
     
     const renderChart = () => {
       const svg = d3.select(chartRef.current);
       svg.selectAll("*").remove();
       // Chart rendering logic
     };

     requestAnimationFrame(renderChart);
   }, [data]);
   ```

3. Use proper data loading patterns:
   ```jsx
   const {
     data,
     loadingStates,
     dataLoaded
   } = useContext(DataContext);

   if (loadingStates.data || !dataLoaded) {
     return <LoadingSpinner />;
   }
   ```

## Data Integration

- Development environment automatically uses mock data
- Production environment expects `window.ds` adapter implementation
- Data structure must match the schemas in `src/data/*.json`

## Deployment

1. Build the production bundle:
   ```bash
   npm run build
   ```
2. Deploy the contents of the `build` directory to your hosting environment

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

1. Follow the established patterns for component development
2. Ensure proper handling of loading/error states
3. Maintain responsive design principles
4. Test with both mock and production data sources