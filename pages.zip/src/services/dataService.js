// Import all your mock JSON files
import engagementData from "../data/REG_ONC_HCO_Engagement_metrics.json";
import patientShareData from "../data/REG_ONC_HCO_Patient_Share.json";
import trendData from "../data/REG_ONC_HCO_LIBTAYO_Weekly_trend.json";
import territoryData from "../data/REG_ONC_LIBTAYO_HCO_Territory_Detail.json";
import competitorShareData from "../data/REG_ONC_HCO_Competitor_Patient_Share.json";
import payerData from "../data/REG_ONC_HCO_Top_Payers.json";

const isLive = import.meta.env.VITE_DATA_SOURCE === "LIVE";
console.log(isLive);

export const getTerritoryData = () => {
  if (isLive && window.dashboardData?.territory) {
    return window.dashboardData.territory;
  }
  return territoryData;
};

/**
 * Used by: VialsAndGrowthCard.jsx
 */
export const getTrendData = () => {
  if (isLive && window.dashboardData?.trends) {
    return window.dashboardData.trends;
  }
  return trendData;
};

/**
 * Used by: PatientShareTable.jsx
 */
export const getPatientShareData = () => {
  if (isLive && window.dashboardData?.patientShare) {
    return window.dashboardData.patientShare;
  }
  return patientShareData;
};

/**
 * Used by: PatientShareByCompetitor.jsx
 */
export const getCompetitorShareData = () => {
  if (isLive && window.dashboardData?.competitorShare) {
    return window.dashboardData.competitorShare;
  }
  return competitorShareData;
};

/**
 * Used by: EngagementMetricsCard.jsx
 */
export const getEngagementData = () => {
  if (isLive && window.dashboardData?.engagement) {
    return window.dashboardData.engagement;
  }
  return engagementData;
};

/**
 * Used by: Top5PayersTable.jsx
 */
export const getPayerData = () => {
  if (isLive && window.dashboardData?.payers) {
    return window.dashboardData.payers;
  }
  return payerData;
};