import { createContext, useContext, useState, useEffect, useMemo } from "react";
// Import your service functions
// Import all your mock JSON files
// import engagementData from "../data/REG_ONC_HCO_Engagement_metrics.json";
// import patientShareData from "../data/REG_ONC_HCO_Patient_Share.json";
// import trendData from "../data/REG_ONC_HCO_LIBTAYO_Weekly_trend.json";
// import territoryData from "../data/REG_ONC_LIBTAYO_HCO_Territory_Detail.json";
// import competitorShareData from "../data/REG_ONC_HCO_Competitor_Patient_Share.json";
// import payerData from "../data/REG_ONC_HCO_Top_Payers.json";
// import PatientShareTable from "../components/Row2/PatientShareTable";

export const DashboardContext = createContext();

// function getWeeksInCurrentQuarter() {
//   const today = new Date();
//   const quarterStartMonth = Math.floor(today.getMonth() / 3) * 3;
//   const quarterStart = new Date(today.getFullYear(), quarterStartMonth, 1);

//   const startOfThisWeek = new Date(today);
//   const day = startOfThisWeek.getDay() || 7;
//   startOfThisWeek.setDate(startOfThisWeek.getDate() - day + 1);

//   const diffMs = startOfThisWeek - quarterStart;
//   const diffWeeks = Math.floor(diffMs / (7 * 24 * 60 * 60 * 1000)) + 1;

//   return Math.max(diffWeeks, 1);
// }

export function DashboardProvider({ children }) {
  // const [timePeriod, setTimePeriod] = useState("C4W");
  const [currHcoId, setCurrHcoId] = useState("null");
  // const [qtdWeeks, setQtdWeeks] = useState(getWeeksInCurrentQuarter());

  // const[territory, setTerritory] = useState(territoryData);
  // const[patientShare, setPatientShare] = useState(patientShareData);
  // const[trend, setTrend] = useState(trendData);
  // const[competitorShare, setCompetitorShare] = useState(competitorShareData);
  // const[engagement, setEngagement] = useState(engagementData);
  // const[payers, setPayers] = useState(payerData);

  // const[territory, setTerritory] = useState();
  const[patientShare, setPatientShare] = useState();
  // const[trend, setTrend] = useState();
  // const[competitorShare, setCompetitorShare] = useState();
  // const[engagement, setEngagement] = useState();
  // const[payers, setPayers] = useState();

  
  useEffect(() => {
    if(currHcoId){
      queryUserData();
    }
  },[currHcoId])
  
  // useEffect(() => {
  //   if (timePeriod === "QTD") {
  //     setQtdWeeks(getWeeksInCurrentQuarter());
  //   }
  // }, [timePeriod]);

  const queryUserData = () => {
    // console.log('user', currentUser.Id)
    const queryConfig = {
      object: "REG_ONC_HCO_Patient_Share",
      fields: ["Id","REG_HCO_Account__c","REG_ProductName__c","REG_Indication__c","REG_Territory_Name__c","REG_C13W_Patient_Volume__c","REG_P13W_Patient_Volume__c","REG_PerGrowthC13WvsP13W_Patient_Volume__c","REG_C13W_Patient_PerMarketShare__c","REG_C4W_Patient_Volume__c","REG_P4W_Patient_Volume__c","REG_PerGrowthC4WvsP4W_Patient_Volume__c","REG_C4W_Patient_PerMarketShare__c","REG_QTD_Patient_Volume__c","REG_PQTD_Patient_Volume__c","REG_PerGrowthQTDvsPQTD_Patient_Volume__c","REG_QTD_Patient_PerMarketShare__c", "REG_ProductName__c"],
      where: `Id = '${currHcoId.Id}'`,
    };

    // eslint-disable-next-line
    ds.runQuery(queryConfig)
      .then((resp) => {
        console.log("REG_ONC_HCO_Patient_Share", resp);
        setPatientShare(resp.data);
        // setFunctionalProfile(resp.data[0].CCRMS_FunctionalProfile__c.value);
      })
      .catch((err) => {
        console.log(err);
        setTcErrorState(err || "Error querying data");
        // setUserDataError(err || "Error querying user data");
      });
  };

  return (
    <DashboardContext.Provider
      value={{
        // timePeriod,
        // setTimePeriod,
        // currHcoId,
        // setCurrHcoId,
        // qtdWeeks,
        // territory,
        // setTerritory,
        // competitorShare,
        // setCompetitorShare,
        // engagement,
        // setEngagement,
        patientShare,
        setPatientShare,
        // payers,
        // setPayers,
        // trend,
        // setTrend
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  return useContext(DashboardContext);
}