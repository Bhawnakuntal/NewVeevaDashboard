import { createContext, useContext, useState, useEffect, useMemo } from "react";
// Import your service functions
import engagementData from "../data/REG_ONC_HCO_Engagement_metrics.json";
import patientShareData from "../data/REG_ONC_HCO_Patient_Share.json";
import trendData from "../data/REG_ONC_HCO_LIBTAYO_Weekly_trend.json";
import territoryData from "../data/REG_ONC_LIBTAYO_HCO_Territory_Detail.json";
import competitorShareData from "../data/REG_ONC_HCO_Competitor_Patient_Share.json";
import payerData from "../data/REG_ONC_HCO_Top_Payers.json";
import PatientShareTable from "../components/Row2/PatientShareTable";

export const DashboardContext = createContext();

function getWeeksInCurrentQuarter() {
  const today = new Date();
  const quarterStartMonth = Math.floor(today.getMonth() / 3) * 3;
  const quarterStart = new Date(today.getFullYear(), quarterStartMonth, 1);

  const startOfThisWeek = new Date(today);
  const day = startOfThisWeek.getDay() || 7;
  startOfThisWeek.setDate(startOfThisWeek.getDate() - day + 1);

  const diffMs = startOfThisWeek - quarterStart;
  const diffWeeks = Math.floor(diffMs / (7 * 24 * 60 * 60 * 1000)) + 1;

  return Math.max(diffWeeks, 1);
}

export function DashboardProvider({ children }) {
  const [timePeriod, setTimePeriod] = useState("C4W");
  const [selectedHcoId, setSelectedHcoId] = useState("808623be-fa43-4554-b34e-e1e647d0bb24");
  const [qtdWeeks, setQtdWeeks] = useState(getWeeksInCurrentQuarter());
  const[territory, setTerritory] = useState(territoryData);
  const[patientShare, setPatientShare] = useState(patientShareData);
  const[trend, setTrend] = useState(trendData);
  const[competitorShare, setCompetitorShare] = useState(competitorShareData);
  const[engagement, setEngagement] = useState(engagementData);
  const[payers, setPayers] = useState(payerData);

  useEffect(() => {
    if (timePeriod === "QTD") {
      setQtdWeeks(getWeeksInCurrentQuarter());
    }
  }, [timePeriod]);

  return (
    <DashboardContext.Provider
      value={{
        timePeriod,
        setTimePeriod,
        selectedHcoId,
        setSelectedHcoId,
        qtdWeeks,
        territory,
        setTerritory,
        competitorShare,
        setCompetitorShare,
        engagement,
        setEngagement,
        patientShare,
        setPatientShare,
        payers,
        setPayers,
        trend,
        setTrend
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  return useContext(DashboardContext);
}