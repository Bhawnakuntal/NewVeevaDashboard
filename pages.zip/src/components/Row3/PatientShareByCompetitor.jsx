import { useMemo } from "react";
import { useDashboard } from "../../context/DashboardContext";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LabelList,
} from "recharts";

/* ================= CONSTANTS ================= */

const COMPETITORS = [
  { key: "Libtayo", color: "#0f447aff" },
  { key: "Keytruda", color: "#f78310ff" },
  { key: "Avastin", color: "#2CA02C" },
  { key: "Opdivo", color: "#36aef3ff" },
];

const WEEK_KEYS = [
  "REG_CW_Minus_12_Patient_PerMarketShare__c",
  "REG_CW_Minus_11_Patient_PerMarketShare__c",
  "REG_CW_Minus_10_Patient_PerMarketShare__c",
  "REG_CW_Minus_9_Patient_PerMarketShare__c",
  "REG_CW_Minus_8_Patient_PerMarketShare__c",
  "REG_CW_Minus_7_Patient_PerMarketShare__c",
  "REG_CW_Minus_6_Patient_PerMarketShare__c",
  "REG_CW_Minus_5_Patient_PerMarketShare__c",
  "REG_CW_Minus_4_Patient_PerMarketShare__c",
  "REG_CW_Minus_3_Patient_PerMarketShare__c",
  "REG_CW_Minus_2_Patient_PerMarketShare__c",
  "REG_CW_Minus_1_Patient_PerMarketShare__c",
  "REG_CW_Patient_PerMarketShare__c",
];

/* HELPERS */

function getWeekStartDates(count) {
  const startOfWeek = new Date();
  startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());

  return Array.from({ length: count }).map((_, i) => {
    const d = new Date(startOfWeek);
    d.setDate(d.getDate() - (count - 1 - i) * 7);
    return d.toLocaleDateString("en-US", {
      month: "2-digit",
      day: "2-digit",
      year: "numeric",
    });
  });
}

/*  MAIN  */
const CustomLegend = () => (
  <div className="flex justify-center  gap-4 mt-1 text-[80%] text-gray-700 font-semibold">
    {COMPETITORS.map(c => (
      <div key={c.key} className="flex items-center gap-1">
        <span
          className="inline-block w-2 h-2 rounded-sm"
          style={{ backgroundColor: c.color }}
        />
        <span>{c.key}</span>
      </div>
    ))}
  </div>
);

export default function PatientShareByCompetitor() {
  const { selectedHcoId, timePeriod, qtdWeeks, competitorShare } = useDashboard();


  /* ---------- FILTER BY HCO ---------- */
  const hcoRows = useMemo(() => {
    return competitorShare.filter(
      r => r.REG_HCO_Account__c?.value === selectedHcoId
    );
  }, [selectedHcoId, competitorShare]);

  /* ---------- ACTIVE WEEKS ---------- */
  const activeWeekCount = useMemo(() => { 
    if (timePeriod === "C4W") return 4;
    if (timePeriod === "C13W") return 13; 
    return qtdWeeks; 
  }, [timePeriod, qtdWeeks]); 

  const activeWeekKeys = WEEK_KEYS.slice(-activeWeekCount);
  const weekLabels = getWeekStartDates(activeWeekCount);

  /* ---------- BUILD STACKED DATA ---------- */
  const chartData = useMemo(() => {
    return activeWeekKeys.map((wk, i) => {
      const row = { week: weekLabels[i] };

      COMPETITORS.forEach(c => {
        const productRow = hcoRows.find(
          r => r.REG_ProductName__c?.value === c.key
        );
        row[c.key] = Number(productRow?.[wk]?.value ?? 0);
      });

      return row;
    });
  }, [activeWeekKeys, hcoRows, weekLabels]);

  return (
    <div className="w-[35%] flex flex-col h-full bg-white border border-[#D8DDE6] rounded-[6px] shadow-md p-1">
      {/* Container: Changed pt-2 to py-2 to balance spacing */}
      
        <div className="text-[1rem] font-bold text-gray-700 pb-3 pt-2 text-center tracking-tight">
          Patient Share by Competitor
        </div>

        {/*  FIXED: Changed h-[16rem] to flex-1 to occupy all available vertical space */}
        <div className="flex-1 min-h-0 flex flex-col">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              stackOffset="expand"
              margin={{ top: 0, right: 10, left: 0, bottom: 0 }}
            >
              <CartesianGrid stroke="#acadb1ff" vertical={false} horizontal={true} />
              
              <XAxis
                dataKey="week"
                angle={-35}
                textAnchor="end"
                tick={{ fontSize: 10, fill: "#666667ff", fontWeight: 600 }}
                tickLine={false}
                axisLine={{ stroke: "#7f8081ff" }}
                height={42}
              />

              <YAxis
                tickFormatter={v => `${Math.round(v * 100)}%`}
                tick={{ fontSize: 11, fill: "#444445ff" }}
                axisLine={false}
                tickLine={false}
                label={{
                  value: "Patient Share, %",
                  angle: -90,
                  position: "insideLeft",
                  offset: 10,
                  style: {
                    textAnchor: "middle",
                    fill: "#3a3a3bff",
                    fontSize: 12,
                    fontWeight: 600,
                  },
                }}
              />

              {COMPETITORS.map(c => (
                <Bar
                  key={c.key}
                  dataKey={c.key}
                  stackId="a"
                  fill={c.color}
                  barSize={40}
                >
                  <LabelList
                    dataKey={c.key}
                    position="center"
                    formatter={v => (v > 10 ? `${Math.round(v)}%` : "")} // Added threshold to avoid cluttering
                    fill="#FFFFFF"
                    fontSize={9}
                    fontWeight={700}
                  />
                </Bar>
              ))}
            </BarChart>
          </ResponsiveContainer>
          
          <CustomLegend />
        </div>
      
    </div>
  );
}