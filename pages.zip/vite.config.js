import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import archiver from "archiver";
import fs from "fs";
import path from "path";
 
// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    {
      name: "html-inject-iife",
      enforce: "post",
      transformIndexHtml(html, ctx) {
        if (!ctx.bundle) return html;
 
        // Find the entry chunk
        let entry = "";
        for (const [fileName, bundle] of Object.entries(ctx.bundle)) {
          if (bundle.isEntry) {
            entry = fileName;
            break;
          }
        }
 
        if (entry) {
          // Remove the default injected module script
          // Matches <script type="module" ... src="..."></script>
          // Note: Vite might put attributes in different orders, so we use a flexible regex or just remove the specific line if we can identify it.
          // However, typically the module script is what we want to replace.
          // Let's blindly replace the closing body tag with our script if we can't find the module tag cleanly,
          // BUT we really want to get rid of the module tag.
          // The output shows: <script type="module" crossorigin src="./assets/index-DLsEHA73.js"></script>
 
          let updatedHtml = html.replace(
            /<script type="module"[^>]*><\/script>/g,
            ""
          );
 
          // Inject the new script at the end of body
          // We assume "assets/" is part of the fileName if the entryFileName includes it, which it does in the config below.
          // But wait, in the config below, entryFileNames is "assets/[name]-[hash].js".
          // The ctx.bundle fileName includes "assets/".
          // So we simply use "./" + entry.
 
          updatedHtml = updatedHtml.replace(
            "</body>",
            `<script src="${entry}"></script>\n  </body>`
          );
          return updatedHtml;
        }
        return html;
      },
    },
    {
      name: "zip-dist",
      closeBundle() {
        const distDir = path.resolve("dist");
        if (!fs.existsSync(distDir)) {
          console.log("Dist directory does not exist yet. Creating it...");
          fs.mkdirSync(distDir, { recursive: true });
        }
        const outputPath = path.resolve(distDir, "dist.zip");
        const output = fs.createWriteStream(outputPath);
        const archive = archiver("zip", {
          zlib: { level: 9 }, // Sets the compression level.
        });
 
        output.on("close", function () {
          console.log(`Success! Total bytes: ${archive.pointer()}`);
          console.log("Dist folder has been zipped to dist/dist.zip");
        });
 
        archive.on("error", function (err) {
          throw err;
        });
 
        archive.pipe(output);
 
        // Append files from dist directory, excluding the zip file itself
        archive.glob("**/*", {
          cwd: distDir,
          ignore: ["dist.zip"],
        });
 
        archive.finalize();
      },
    },
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  base: "./", // Relative path for assets
  build: {
    outDir: "dist",
    emptyOutDir: true,
    rollupOptions: {
      output: {
        format: "iife", // Immediately Invoked Function Expression for non-module support
        entryFileNames: "assets/[name]-[hash].js",
        chunkFileNames: "assets/[name]-[hash].js",
        assetFileNames: "assets/[name]-[hash].[ext]"
        // Ensure manualChunks is disabled or handled if we want a single file, but standard chunking is fine as long as we inject the entry.
      },
    },
  },
});
 