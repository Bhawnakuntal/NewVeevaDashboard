import { createContext, useContext, useState, useEffect, useMemo } from "react";
import { getDS } from "../services/mockAdapter";

export const DashboardContext = createContext();

export async function getAccountId() {
  const ds = getDS();
  if (ds) {
    try {
      let response = await ds.getDataForCurrentObject("Account", "Id");
      return response.Account.Id;
    } catch (e) {
      console.error(e);
      return null;
    }
  }
  return null;
}

export function DashboardProvider({ children }) {
  console.log("DashboardProvider");
  const [currHcoId, setCurrHcoId] = useState("null");
  const [patientShare, setPatientShare] = useState();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    getAccountId().then((id) => {
      if (id) {
        setCurrHcoId(id);
      } else {
        setIsLoading(false);
      }
    });
  }, []);

  useEffect(() => {
    if (currHcoId && currHcoId !== "null") {
      queryPatientShareData();
    }
  }, [currHcoId]);

  const queryPatientShareData = () => {
    setIsLoading(true);
    const queryConfig = {
      object: "REG_ONC_HCO_Patient_Share__c",
      fields: [
        "Id",
        "REG_HCO_Account__c",
        "REG_ProductName__c",
        "REG_Indication__c",
        "REG_C13W_Patient_PerMarketShare__c",
        "REG_C13W_Patient_Volume__c",
        "REG_P13W_Patient_Volume__c",
        "REG_PerGrowthC13WvsP13W_Patient_Volume__c",
        "REG_C4W_Patient_PerMarketShare__c",
        "REG_C4W_Patient_Volume__c",
        "REG_P4W_Patient_Volume__c",
        "REG_PerGrowthC4WvsP4W_Patient_Volume__c",
        "REG_QTD_Patient_PerMarketShare__c",
        "REG_QTD_Patient_Volume__c",
        "REG_PQTD_Patient_Volume__c",
        "REG_PerGrowthQTDvsPQTD_Patient_Volume__c",
      ],
      where: `REG_HCO_Account__c = '${currHcoId}'`,
    };

    const ds = getDS();

    ds.runQuery(queryConfig)
      .then((resp) => {
        console.log("REG_ONC_HCO_Patient_Share__c", resp);
        setPatientShare(resp.data);
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <DashboardContext.Provider
      value={{
        patientShare,
        setPatientShare,
        currHcoId,
        setCurrHcoId,
        isLoading,
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  return useContext(DashboardContext);
}
