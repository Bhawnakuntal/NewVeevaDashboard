import Dashboard from "../pages/Dashboard.jsx";

function App() {
  return <Dashboard />;
}

export default App;
