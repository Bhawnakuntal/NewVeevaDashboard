import { useDashboard } from "../context/DashboardContext";

/* 
   KPI MAPPINGS (Crucial for getKpi logic)
*/
const KPI_KEY_MAP = {
  Volume: {
    C4W: { value: "REG_LIBTAYO_C4W_Volume__c", delta: "REG_LIBTAYO_PerGrowthC4WvsP4W_Volume__c" },
    C13W: { value: "REG_LIBTAYO_C13W_Volume__c", delta: "REG_LIBTAYO_PerGrowthC13WvsP13W_Volume__c" },
    QTD: { value: "REG_LIBTAYO_QTD_Volume__c", delta: "REG_LIBTAYO_PerGrowthQTDvsPQTD_Volume__c" },
  },
  HCO_Events_Attended: {
    C4W: { value: "REG_LIBTAYO_C4W_HCO_Events_Attended__c", delta: "REG_LIBTAYO_PerGrowthC4WvsP4W_HCO_Events_Attended__c" },
    C13W: { value: "REG_LIBTAYO_C13W_HCO_Events_Attended__c", delta: "REG_LIBTAYO_PerGrowthC13WvsP13W_HCO_Events_Attended__c" },
    QTD: { value: "REG_LIBTAYO_QTD_HCO_Events_Attended__c", delta: "REG_LIBTAYO_PerGrowthQTDvsPQTD_HCO_Events_Attended__c" },
  },
  HCO_Patient_Count: {
    C4W: { value: "REG_LIBTAYO_C4W_HCO_Patient_Count__c", delta: "REG_LIBTAYO_PerGrowthC4WvsP4W_HCO_Patient_Count__c" },
    C13W: { value: "REG_LIBTAYO_C13W_HCO_Patient_Count__c", delta: "REG_LIBTAYO_PerGrowthC13WvsP13W_HCO_Patient_Count__c" },
    QTD: { value: "REG_LIBTAYO_QTD_HCO_Patient_Count__c", delta: "REG_LIBTAYO_PerGrowthQTDvsPQTD_HCO_Patient_Count__c" },
  },
  AffiliatedHCP_Engaged_Count: {
    C4W: { value: "REG_LIBTAYO_C4W_AffiliatedHCP_Engaged_Count__c", delta: "REG_LIBTAYO_PerGrowthC4WvsP4W_AffiliatedHCP_Engaged_Count__c" },
    C13W: { value: "REG_LIBTAYO_C13W_AffiliatedHCP_Engaged_Count__c", delta: "REG_LIBTAYO_PerGrowthC13WvsP13W_AffiliatedHCP_Engaged_Count__c" },
    QTD: { value: "REG_LIBTAYO_QTD_AffiliatedHCP_Engaged_Count__c", delta: "REG_LIBTAYO_PerGrowthQTDvsPQTD_AffiliatedHCP_Engaged_Count__c" },
  },
};

/* =====================================================
   MAIN ROW - Unified Container
===================================================== */
export default function FirstRow() {
  const { timePeriod, setTimePeriod, territory } = useDashboard();
  
  if (!territory || !territory.length === 0) {
    return (
      <div className="w-full h-[6.6rem] bg-white border flex items-center justify-center text-red-500 font-bold">
        Error: JSON Data not found.
      </div>
    );
  }
  
  const record = territory[0]; 

  return (
    <div className="w-full flex flex-nowrap items-stretch h-[6.6rem] bg-white border border-[#D8DDE6] rounded-[6px] shadow-md divide-x divide-[#D8DDE6] overflow-hidden">
      <PrimaryAddressCard />
      <LastInteractionCard />
      <TierCard record={record} />
      <LibtayoVialsCard record={record} timePeriod={timePeriod} />
      <DaysSinceOrderCard record={record} />
      
      {/* Restored KpiCard calls */}
      <KpiCard title="Vials" metric="Volume" record={record} timePeriod={timePeriod} width="w-[9%]" />
      <KpiCard title="Events Attended" metric="HCO_Events_Attended" record={record} timePeriod={timePeriod} width="w-[9%]" />
      <KpiCard title="Patients" metric="HCO_Patient_Count" record={record} timePeriod={timePeriod} width="w-[9%]" />
      <KpiCard title="HCP Engaged" metric="AffiliatedHCP_Engaged_Count" record={record} timePeriod={timePeriod} width="w-[9%]" />
      
      <TimePeriodCard timePeriod={timePeriod} setTimePeriod={setTimePeriod} />
    </div>
  );
}

/* =====================================================
   SUB-COMPONENTS
===================================================== */

function KpiCard({ title, metric, record, timePeriod, width }) {
  const { value, delta } = getKpi(record, metric, timePeriod);
  return (
    <Card title={title} width={width}>
      <div className="text-[0.9rem] font-bold text-gray-700 text-center">{value}</div>
      <Delta delta={delta} period={timePeriod} />
    </Card>
  );
}

function PrimaryAddressCard() {
  return (
    <div className="w-[11%] h-full pt-2 flex flex-col">
      <div className="text-gray-700 text-[0.9rem] font-bold text-center pb-2 tracking-tight">Primary Address</div>
      <div className="text-[0.8rem] font-medium text-gray-500 leading-tight break-words text-center px-1">
        123 Main st,<br />Houston TX
      </div>
    </div>
  );
}

function LastInteractionCard() {
  return (
    <div className="w-[15%] h-full pt-2 flex flex-col">
      <div className="text-gray-700 text-[0.9rem] font-bold text-center pb-1 tracking-tight">Last Personal Interaction</div>
      <div className="text-[0.71rem] font-medium text-gray-500 leading-tight text-center">2 HCP Attendees</div>
      <div className="text-[0.71rem] font-medium text-gray-500 leading-tight text-center">Feb 19, 2025 – John Smith</div>
      <div className="text-[0.71rem] text-[#0176D3] font-bold cursor-pointer text-center mt-1">View Interaction</div>
    </div>
  );
}

function TierCard({ record }) {
  const tierDisplay = record?.REG_Account_Tier__c?.value || "";
  return (
    <div className="w-[7%] h-full pt-2 flex flex-col items-center justify-center">
      <div className="flex flex-col gap-[0.25rem]">
        <TierCheckbox label="Tier 1" checked={tierDisplay === "Tier 1"} />
        <TierCheckbox label="Tier 2" checked={tierDisplay === "Tier 2"} />
        <TierCheckbox label="Tier 3" checked={tierDisplay === "Tier 3"} />
      </div>
    </div>
  );
}

function TierCheckbox({ label, checked }) {
  return (
    <label className="flex items-center gap-1.5 text-[0.8rem] text-gray-600 font-semibold">
      <input type="checkbox" checked={checked} readOnly className="w-3 h-3 accent-[#0176D3]" />
      <span>{label}</span>
    </label>
  );
}

function LibtayoVialsCard({ record, timePeriod }) {
  const { current, previous } = getLibtayoVolumes(record, timePeriod);
  return (
    <div className="w-[10%] h-full pt-2 flex flex-col">
      <div className="text-gray-700 text-[0.9rem] font-bold text-center pb-1 tracking-tight">Libtayo Vials</div>
      <div className="flex justify-around items-center h-full">
        <ValueBlock value={previous} label={`P${timePeriod.slice(1)}`} muted />
        <ValueBlock value={current} label={timePeriod} highlight />
      </div>
    </div>
  );
}

function DaysSinceOrderCard({ record }) {
  const lastOrderValue = record?.REG_Date_of_Last_Order__c?.value;
  const weeks = lastOrderValue ? Math.floor((new Date() - new Date(lastOrderValue)) / (1000 * 60 * 60 * 24 * 7)) : "N/A";
  return (
    <div className="w-[11.4%] h-full flex flex-col justify-center">
      <div className="text-gray-700 text-[0.9rem] font-bold text-center leading-none">Time Since</div>
      <div className="text-gray-700 text-[0.9rem] font-bold text-center">Last Libtayo Order</div>
      <div className="text-[1rem] font-bold text-gray-700 text-center">{weeks}</div>
      <div className="text-[0.7rem] text-gray-500 text-center">Weeks</div>
    </div>
  );
}

function TimePeriodCard({ timePeriod, setTimePeriod }) {
  return (
    <div className="flex-1 h-full pt-2 flex flex-col">
      <div className="text-gray-700 text-[0.8rem] font-bold text-center pb-1">Time Periods</div>
      <div className="flex flex-col gap-1 justify-center items-center h-full pb-2">
        {["C4W", "C13W", "QTD"].map((p) => (
          <button
            key={p}
            onClick={() => setTimePeriod(p)}
            className={`w-[50%] rounded-[3px] py-[0.1rem] text-[0.6rem] font-bold ${
              timePeriod === p ? "bg-[#0176D3] text-white" : "bg-gray-100 text-gray-500"
            }`}
          >
            {p}
          </button>
        ))}
      </div>
    </div>
  );
}

/* =====================================================
   HELPERS
===================================================== */

function Card({ title, width, children }) {
  return (
    <div className={`${width} flex flex-col h-full flex-shrink-0 pt-2 px-1`}>
      <div className="text-[0.9rem] text-gray-700 font-bold text-center tracking-tight">
        {title}
      </div>
      <div className="flex-1 flex flex-col justify-center items-center">
        {children}
      </div>
    </div>
  );
}

function ValueBlock({ value, label, highlight }) {
  return (
    <div className="flex flex-col items-center">
      <div className="text-[0.9rem] font-bold text-gray-700">{value}</div>
      <div className={`text-[0.75rem] pb-4 font-bold ${highlight ? "text-[#0176D3]" : "text-gray-500"}`}>
        {label}
      </div>
    </div>
  );
}

function Delta({ delta, period }) {
  const isNeg = delta < 0;
  return (
    <div className={`text-[0.7rem] pb-4 font-bold ${isNeg ? "text-[#BA0517]" : "text-[#2E844A]"} text-center`}>
      {isNeg ? "▼" : "▲"} {Math.abs(delta)}%
      <span className="text-gray-500 ml-1 font-normal text-[0.7rem]">vs P{period.slice(1)}</span>
    </div>
  );
}

function getLibtayoVolumes(record, timePeriod) {
  if (!record) return { current: "0", previous: "0" };
  if (timePeriod === "C4W") return { current: record.REG_LIBTAYO_C4W_Volume__c?.display, previous: record.REG_LIBTAYO_P4W_Volume__c?.display };
  if (timePeriod === "C13W") return { current: record.REG_LIBTAYO_C13W_Volume__c?.display, previous: record.REG_LIBTAYO_P13W_Volume__c?.display };
  if (timePeriod === "QTD") return { current: record.REG_LIBTAYO_QTD_Volume__c?.display, previous: record.REG_LIBTAYO_PQTD_Volume__c?.display };
  return { current: "0", previous: "0" };
}

function getKpi(record, metric, timePeriod) {
  if (!record) return { value: "0", delta: 0 };
  const config = KPI_KEY_MAP[metric]?.[timePeriod];
  if (!config) return { value: "0", delta: 0 };
  return { value: record[config.value]?.value ?? "0", delta: record[config.delta]?.value ?? 0 };
}