import { useState, useMemo } from "react";
import { useDashboard } from "../../context/DashboardContext";

/* ================= CONSTANTS ================= */
const PRODUCTS = ["Libtayo", "Avastin", "Keytruda", "Opdivo"];
const COLORS = {
  Libtayo: "#2ECC71",
  Avastin: "#0e4dabff",
  Keytruda: "#B5BD00",
  Opdivo: "#B0128E",
};
const INDICATIONS = ["All", "Skin", "Lung", "Adjuvant"];
const GRID_COLS = "grid-cols-[20%_20%_23%_38%]";

/* ================= MAIN COMPONENT ================= */
export default function PatientShareTable() {
  const { patientShare, currHcoId, isLoading } = useDashboard();
  console.log(patientShare);

  const [indication, setIndication] = useState("All");

  /* ---------- FILTER ---------- */
  const filtered = useMemo(() => {
    if (!patientShare || !Array.isArray(patientShare)) return [];

    // 1. Filter by Indication first
    let data =
      indication === "All"
        ? patientShare
        : patientShare.filter((d) => d.REG_Indication__c?.value === indication);

    // 2. 🚀 Filter by the Global currHcoId (from context)
    // If currHcoId is "null", we show all data for the territory
    if (currHcoId !== "null") {
      data = data.filter((r) => r.REG_HCO_Account__c?.value === currHcoId);
    }

    return data;
  }, [indication, patientShare, currHcoId]);

  /* ---------- AGGREGATE ---------- */
  const rows = useMemo(() => {
    // Hardcoded to C13W as per previous request
    const currKey = `REG_C13W_Patient_Volume__c`;
    const prevKey = `REG_P13W_Patient_Volume__c`;

    const totalMarket =
      filtered.reduce((a, c) => a + Number(c[currKey]?.value ?? 0), 0) || 1;

    return PRODUCTS.map((product) => {
      const items = filtered.filter(
        (r) => r.REG_ProductName__c?.value === product
      );
      const patients = items.reduce(
        (s, r) => s + Number(r[currKey]?.value ?? 0),
        0
      );
      const prevPatients = items.reduce(
        (s, r) => s + Number(r[prevKey]?.value ?? 0),
        0
      );

      const deltaAbs = patients - prevPatients;
      const deltaPct = prevPatients !== 0 ? (deltaAbs / prevPatients) * 100 : 0;
      const share = (patients / totalMarket) * 100;

      return { product, patients, share, deltaAbs, deltaPct };
    });
  }, [filtered]);

  if (isLoading) return <div>Loading...</div>;

  return (
    <div className="w-[34%] bg-white border border-[#D8DDE6] rounded-[6px] p-2 shadow-md h-full flex flex-col font-sans">
      {/* ================= HEADER ================= */}
      <div className="relative flex items-center justify-center mb-1 border-b border-gray-100 flex-shrink-0">
        <IndicationDropdown value={indication} onChange={setIndication} />
        <div className="text-[1rem] font-bold text-gray-700 tracking-tight py-1">
          Patient Share
        </div>
      </div>

      <div className="flex gap-1 flex-1 items-stretch mt-1 overflow-hidden">
        <StackBar rows={rows} />

        <div className="flex-1 flex flex-col border border-[#D8DDE6] rounded-t overflow-hidden w-full">
          {/* ---- HEADER ---- */}
          <div
            className={`grid ${GRID_COLS} bg-[#44546A] text-white text-[0.8rem] px-2 h-[3rem] flex-shrink-0 items-center font-bold`}
          >
            <div>Product</div>
            <div className="text-right">% Share</div>
            <div className="text-right">Patients</div>
            <div className="text-right">vs P13W</div>
          </div>

          {/* ---- ROWS ---- */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {rows.map((r) => (
              <div
                key={r.product}
                className={`grid ${GRID_COLS} flex-1 px-2 items-center text-[0.7rem] border-b border-[#EEF1F6] last:border-0`}
              >
                <div className="flex items-center gap-1 min-w-0 font-bold text-black">
                  <span
                    className="w-[0.6rem] h-[0.6rem] rounded-full flex-shrink-0"
                    style={{ backgroundColor: COLORS[r.product] }}
                  />
                  <span className="truncate">{r.product}</span>
                </div>

                <div className="text-right text-black font-bold whitespace-nowrap">
                  {r.share.toFixed(1)}%
                </div>
                <div className="text-right text-black font-bold whitespace-nowrap">
                  {r.patients.toLocaleString()}
                </div>

                <div className="font-bold whitespace-nowrap text-black text-right">
                  <span
                    className={`text-[0.8rem] mr-0.5 ${
                      r.deltaAbs < 0 ? "text-[#BA0517]" : "text-[#2E844A]"
                    }`}
                  >
                    {r.deltaAbs < 0 ? "▼" : "▲"}
                  </span>
                  {Math.abs(r.deltaPct).toFixed(1)}%
                  <span className="ml-1 text-[0.7rem] text-gray-500 font-bold">
                    ({r.deltaAbs.toLocaleString()})
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= SUB COMPONENTS ================= */

function IndicationDropdown({ value, onChange }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="absolute left-0 text-[0.6rem] z-20">
      <div
        onClick={() => setOpen(!open)}
        className="bg-[#F4F6F9] px-2 py-1 rounded cursor-pointer border border-gray-400 text-black text-[110%] font-bold whitespace-nowrap"
      >
        Indication: {value} ▼
      </div>

      {open && (
        <div className="bg-white border border-gray-300 mt-[2px] rounded absolute w-full shadow-lg overflow-hidden">
          {INDICATIONS.map((i) => (
            <div
              key={i}
              onClick={() => {
                onChange(i);
                setOpen(false);
              }}
              className="px-2 py-[0.4rem] hover:bg-[#F4F6F9] hover:text-[#0070D2] cursor-pointer text-black font-bold border-b border-gray-100 last:border-0"
            >
              {i}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StackBar({ rows }) {
  const total = rows.reduce((s, r) => s + r.patients, 0) || 1;
  return (
    <div className="w-[2.5rem] flex flex-col overflow-hidden border border-[#D8DDE6] h-full rounded-sm">
      {rows.map((r) => (
        <div
          key={r.product}
          style={{
            height: `${(r.patients / total) * 100}%`,
            backgroundColor: COLORS[r.product],
          }}
          className="transition-all duration-300"
        />
      ))}
    </div>
  );
}
