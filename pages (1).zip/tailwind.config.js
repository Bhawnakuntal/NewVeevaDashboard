/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        veevaOrange: '#F28C38',
        veevaBlue: '#00A1E0',
        veevaBg: '#F4F6F9',
        veevaBorder: '#D8DDE6',
        veevaText: '#080707',
        veevaLabel: '#54698D',
      },
      aspectRatio: {
        'ipad': '4 / 3',
      },
    },
  },
  plugins: [],
}