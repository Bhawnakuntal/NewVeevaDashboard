import FirstRow from "../src/components/FirstRow";
import PatientShareTable from "../src/components/Row2/PatientShareTable";
import VialsAndGrowthCard from "../src/components/Row2/VialsAndGrowthCard";
import EngagementMetricsCard from "../src/components/Row2/EngagementMetricsCard";
import Top5PayersTable from "../src/components/Row3/Top5PayersTable";
import PatientShareByCompetitor from "../src/components/Row3/PatientShareByCompetitor";
import MembersCard from "../src/components/Row3/MembersCard";

export default function Dashboard() {
  console.log("Dashboard");
  return (
    <div className="w-full h-screen bg-gray-100 p-1 flex flex-col space-y-1 overflow-hidden">
            
      <div className="flex-shrink-0">
        <FirstRow />
      </div>

      <div className="w-full flex gap-1 flex-1 min-h-0">
        <PatientShareTable />
        <VialsAndGrowthCard />
        <EngagementMetricsCard />
      </div>

      <div className="w-full flex gap-1 flex-1 min-h-0">
        <Top5PayersTable />
        <PatientShareByCompetitor />
        <MembersCard />
      </div>

      <div className=" flex-shrink-0" />
    </div>
  );
}
