import { createContext, useContext, useState, useEffect } from "react";
import { getDS } from "../services/mockAdapter";

export const DashboardContext = createContext();

// Helper to calculate QTD weeks
function getWeeksInCurrentQuarter() {
  const today = new Date();
  const quarterStartMonth = Math.floor(today.getMonth() / 3) * 3;
  const quarterStart = new Date(today.getFullYear(), quarterStartMonth, 1);

  const startOfThisWeek = new Date(today);
  const day = startOfThisWeek.getDay() || 7;
  startOfThisWeek.setDate(startOfThisWeek.getDate() - day + 1);

  const diffMs = startOfThisWeek - quarterStart;
  const diffWeeks = Math.floor(diffMs / (7 * 24 * 60 * 60 * 1000)) + 1;

  return Math.max(diffWeeks, 1);
}

export async function getAccountId() {
  const ds = getDS();
  if (ds) {
    try {
      let response = await ds.getDataForCurrentObject("Account", "Id");
      return response.Account.Id;
    } catch (e) {
      console.error(e);
      return null;
    }
  }
  return null;
}

export function DashboardProvider({ children }) {
  const [currHcoId, setCurrHcoId] = useState("null");
  const [patientShare, setPatientShare] = useState([]);
  const [qtdWeeks, setQtdWeeks] = useState(getWeeksInCurrentQuarter());
  const [isLoading, setIsLoading] = useState(true);
  const [territory, setTerritory] = useState([]);
  const [timePeriod, setTimePeriod] = useState("C4W");
  const [trend, setTrend] = useState([]);
  const [engagement, setEngagement] = useState([]);
  const [competitorShare, setCompetitorShare] = useState([]);
  const [payers, setPayers] = useState([]);

  // 1. Update QTD weeks when time period changes
  useEffect(() => {
    if (timePeriod === "QTD") {
      setQtdWeeks(getWeeksInCurrentQuarter());
    }
  }, [timePeriod]);

  // 2. Get initial Account ID on mount
  useEffect(() => {
    getAccountId().then((id) => {
      if (id) {
        setCurrHcoId(id);
      } else {
        setIsLoading(false); // Stop loading if no ID found
      }
    });
  }, []);

  // 3. Fetch all data when HCO ID changes
  useEffect(() => {
    if (currHcoId && currHcoId !== "null") {
      fetchAllData();
    }
  }, [currHcoId]);

  // Unified fetching function to handle all parallel requests
  const fetchAllData = async () => {
    setIsLoading(true);
    try {
      // We run these in parallel for performance
      await Promise.all([
        queryPatientShareData(),
        queryTerritoryData(),
        queryTrendData(),
        queryEngagementData(),
        queryCompetitorData(),
        queryPayerData()
      ]);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const queryPatientShareData = () => {
    setIsLoading(true);
    const queryConfig = {
      object: "REG_ONC_HCO_Patient_Share",
      fields: [
        "Id",
        "REG_HCO_Account__c",
        "REG_ProductName__c",
        "REG_Indication__c",
        "REG_C13W_Patient_PerMarketShare__c",
        "REG_C13W_Patient_Volume__c",
        "REG_P13W_Patient_Volume__c",
        "REG_PerGrowthC13WvsP13W_Patient_Volume__c",
        "REG_C4W_Patient_PerMarketShare__c",
        "REG_C4W_Patient_Volume__c",
        "REG_P4W_Patient_Volume__c",
        "REG_PerGrowthC4WvsP4W_Patient_Volume__c",
        "REG_QTD_Patient_PerMarketShare__c",
        "REG_QTD_Patient_Volume__c",
        "REG_PQTD_Patient_Volume__c",
        "REG_PerGrowthQTDvsPQTD_Patient_Volume__c",
      ],
      where: `REG_HCO_Account__c = '${currHcoId}'`,
    };

    const ds = getDS();

    ds.runQuery(queryConfig)
      .then((resp) => {
        console.log("REG_ONC_HCO_Patient_Share__c", resp);
        setPatientShare(resp.data);
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  const queryTerritoryData = () =>{
    setIsLoading(true);
    const queryConfig = {
      object: "REG_ONC_LIBTAYO_HCO_Territory_Detail",
      fields: [
        "REG_UserTerritoryId__c",
        "REG_HCO_Account__c",
        "REG_Account_Name__c",
        "REG_Territory_Name__c",
        "REG_Account_Tier__c",
        "REG_Navigator_Address__c",
        "REG_Navigator_AccountGroup__c",
        "REG_PE_Applicable__c",
        "REG_Date_of_Last_Order__c",
        "REG_LIBTAYO_C13W_Volume__c",
        "REG_LIBTAYO_P13W_Volume__c",
        "REG_LIBTAYO_PerGrowthC13WvsP13W_Volume__c",
        "REG_LIBTAYO_C4W_Volume__c",
        "REG_LIBTAYO_P4W_Volume__c",
        "REG_LIBTAYO_PerGrowthC4WvsP4W_Volume__c",
        "REG_LIBTAYO_QTD_Volume__c",
        "REG_LIBTAYO_PQTD_Volume__c",
        "REG_LIBTAYO_PerGrowthQTDvsPQTD_Volume__c",
        "REG_LIBTAYO_C13W_HCO_Calls__c",
        "REG_LIBTAYO_P13W_HCO_Calls__c",
        "REG_LIBTAYO_PerGrowthC13WvsP13W_HCO_Calls__c",
        "REG_LIBTAYO_C4W_HCO_Calls__c",
        "REG_LIBTAYO_PerGrowthC4WvsP4W_HCO_Calls__c",
        "REG_LIBTAYO_QTD_HCO_Calls__c",
        "REG_LIBTAYO_PerGrowthQTDvsPQTD_HCO_Calls__c",
        "REG_LIBTAYO_C13W_AffiliatedHCP_Calls__c",
        "REG_LIBTAYO_P13W_AffiliatedHCP_Calls__c",
        "REG_LIBTAYO_PerGrowthC13WvsP13W_AffiliatedHCP_Calls__c",
        "REG_LIBTAYO_C4W_AffiliatedHCP_Calls__c",
        "REG_LIBTAYO_PerGrowthC4WvsP4W_AffiliatedHCP_Calls__c",
        "REG_LIBTAYO_QTD_AffiliatedHCP_Calls__c",
        "REG_LIBTAYO_PerGrowthQTDvsPQTD_AffiliatedHCP_Calls__c",
        "REG_LIBTAYO_C13W_HCO_Events_Attended__c",
        "REG_LIBTAYO_PerGrowthC13WvsP13W_HCO_Events_Attended__c",
        "REG_LIBTAYO_C4W_HCO_Events_Attended__c",
        "REG_LIBTAYO_PerGrowthC4WvsP4W_HCO_Events_Attended__c",
        "REG_LIBTAYO_QTD_HCO_Events_Attended__c",
        "REG_LIBTAYO_PerGrowthQTDvsPQTD_HCO_Events_Attended__c",
        "REG_LIBTAYO_C13W_HCO_Patient_Count__c",
        "REG_LIBTAYO_PerGrowthC13WvsP13W_HCO_Patient_Count__c",
        "REG_LIBTAYO_C4W_HCO_Patient_Count__c",
        "REG_LIBTAYO_PerGrowthC4WvsP4W_HCO_Patient_Count__c",
        "REG_LIBTAYO_QTD_HCO_Patient_Count__c",
        "REG_LIBTAYO_PerGrowthQTDvsPQTD_HCO_Patient_Count__c",
        "REG_LIBTAYO_C13W_AffiliatedHCP_Engaged_Count__c",
        "REG_LIBTAYO_PerGrowthC13WvsP13W_AffiliatedHCP_Engaged_Count__c",
        "REG_LIBTAYO_C4W_AffiliatedHCP_Engaged_Count__c",
        "REG_LIBTAYO_PerGrowthC4WvsP4W_AffiliatedHCP_Engaged_Count__c",
        "REG_LIBTAYO_QTD_AffiliatedHCP_Engaged_Count__c",
        "REG_LIBTAYO_PerGrowthQTDvsPQTD_AffiliatedHCP_Engaged_Count__c"
      ],
      where: `REG_UserTerritoryId__c = '${currHcoId}'`
    };
    const ds = getDS();

    ds.runQuery(queryConfig)
      .then((resp) => {
        console.log("REG_ONC_LIBTAYO_HCO_Territory_Detail", resp);
        setTerritory(resp.data);
      })
      .catch((err) => {
        console.log(err);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }

  const queryTrendData = () => {
    const queryConfig = {
      object: "REG_ONC_HCO_LIBTAYO_Weekly_trend__c",
      fields: [
        "REG_HCO_Account__c",
        "REG_Territory_Name__c", 
        "REG_CW_Volume__c",
        "REG_CW_Minus_1_Volume__c",
        "REG_CW_Minus_2_Volume__c",
        "REG_CW_Minus_3_Volume__c",
        "REG_CW_Minus_4_Volume__c",
        "REG_CW_Minus_5_Volume__c",
        "REG_CW_Minus_6_Volume__c",
        "REG_CW_Minus_7_Volume__c",
        "REG_CW_Minus_8_Volume__c",
        "REG_CW_Minus_9_Volume__c",
        "REG_CW_Minus_10_Volume__c",
        "REG_CW_Minus_11_Volume__c",
        "REG_CW_Minus_12_Volume__c"
      ],
      where: `REG_HCO_Account__c = '${currHcoId}'`,
    };
    return getDS().runQuery(queryConfig).then(res => setTrend(res.data));
  };

  const queryEngagementData = () => {
    const queryConfig = {
      object: "REG_ONC_HCO_Engagement_metrics__c",
      fields: [
        "REG_HCO_Account__c",
        "REG_Channel__c",
        "REG_Territory_Name__c", 
        "REG_CW_Engagements__c",
        "REG_CW_Minus_1_Engagements__c",
        "REG_CW_Minus_2_Engagements__c",
        "REG_CW_Minus_3_Engagements__c",
        "REG_CW_Minus_4_Engagements__c",
        "REG_CW_Minus_5_Engagements__c",
        "REG_CW_Minus_6_Engagements__c",
        "REG_CW_Minus_7_Engagements__c",
        "REG_CW_Minus_8_Engagements__c",
        "REG_CW_Minus_9_Engagements__c",
        "REG_CW_Minus_10_Engagements__c",
        "REG_CW_Minus_11_Engagements__c",
        "REG_CW_Minus_12_Engagements__c"
      ],
      where: `REG_HCO_Account__c = '${currHcoId}'`,
    };
    return getDS().runQuery(queryConfig)
    .then((resp) => setEngagement(resp.data || []))
    .catch((err) => console.error("Engagement Query Error:", err));
  };

  const queryCompetitorData = () => {
    const queryConfig = {
      object: "REG_ONC_HCO_Competitor_Patient_Share__c",
      fields: [
        "REG_HCO_Account__c",
        "REG_ProductName__c",
        "REG_CW_Patient_PerMarketShare__c",
        "REG_CW_Minus_1_Patient_PerMarketShare__c",
        "REG_CW_Minus_2_Patient_PerMarketShare__c",
        "REG_CW_Minus_3_Patient_PerMarketShare__c",
        "REG_CW_Minus_4_Patient_PerMarketShare__c",
        "REG_CW_Minus_5_Patient_PerMarketShare__c",
        "REG_CW_Minus_6_Patient_PerMarketShare__c",
        "REG_CW_Minus_7_Patient_PerMarketShare__c",
        "REG_CW_Minus_8_Patient_PerMarketShare__c",
        "REG_CW_Minus_9_Patient_PerMarketShare__c",
        "REG_CW_Minus_10_Patient_PerMarketShare__c",
        "REG_CW_Minus_11_Patient_PerMarketShare__c",
        "REG_CW_Minus_12_Patient_PerMarketShare__c"
      ],
      where: `REG_HCO_Account__c = '${currHcoId}'`,
    };
    return getDS().runQuery(queryConfig)
    .then((resp) => setCompetitorShare(resp.data || []))
    .catch((err) => console.error("CompetitorShare Query Error:", err));
  };

  const queryPayerData = () => {
    const queryConfig = {
      object: "REG_ONC_HCO_Top_Payers__c",
      fields: [
        "REG_Account__c", 
        "REG_Payer__c", 
        "REG_Payer_Channel__c", 
        "REG_C13W_Libtayo_Vials__c",
        "REG_C4W_Libtayo_Vials__c",
        "REG_QTD_Libtayo_Vials__c",
      ],
      where: `REG_Account__c = '${currHcoId}'`,
    };
    return getDS().runQuery(queryConfig)
    .then((resp) => setPayers(resp.data || []))
    .catch((err) => console.error("Payers Query Error:", err));
  };

  return (
    <DashboardContext.Provider
      value={{
        patientShare,
        setPatientShare,
        currHcoId,
        setCurrHcoId,
        qtdWeeks,
        setQtdWeeks,
        isLoading,
        timePeriod,
        setTimePeriod,
        territory,
        setTerritory,
        trend,
        setTrend,
        engagement,
        setEngagement,
        competitorShare,
        setCompetitorShare,
        setPayers,
        payers
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  return useContext(DashboardContext);
}
