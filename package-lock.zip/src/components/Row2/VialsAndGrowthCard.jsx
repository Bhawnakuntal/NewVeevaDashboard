import { useMemo, useState } from "react";
import { useDashboard } from "../../context/DashboardContext";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  LabelList,
  ResponsiveContainer,
  CartesianGrid,
  Cell,
  Label 
} from "recharts";

/*  CONSTANTS & HELPERS  */
const WEEK_KEYS = [
  "REG_CW_Minus_12_Volume__c", "REG_CW_Minus_11_Volume__c", "REG_CW_Minus_10_Volume__c",
  "REG_CW_Minus_9_Volume__c", "REG_CW_Minus_8_Volume__c", "REG_CW_Minus_7_Volume__c",
  "REG_CW_Minus_6_Volume__c", "REG_CW_Minus_5_Volume__c", "REG_CW_Minus_4_Volume__c",
  "REG_CW_Minus_3_Volume__c", "REG_CW_Minus_2_Volume__c", "REG_CW_Minus_1_Volume__c",
  "REG_CW_Volume__c",
];

function getStartOfWeekSafe(date = new Date()) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const day = d.getDay() || 7;
  d.setDate(d.getDate() - day + 1);
  return d;
}

function formatMMDDYYYY(date) {
  if (!(date instanceof Date) || isNaN(date)) return "";
  return date.toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" });
}

/*  MAIN */
export default function VialsAndGrowthCard() {
  const { timePeriod, currHcoId, qtdWeeks, trend, territory} = useDashboard();
  
  const [mode, setMode] = useState("VIALS");

  const DEFAULT_HCO_ID = "808623be-fa43-4554-b34e-e1e647d0bb24";

  const hcoFilteredRows = useMemo(() => {
    const activeHcoId = currHcoId || DEFAULT_HCO_ID;
    return (trend || []).filter(r => r.REG_HCO_Account__c?.value === activeHcoId);
}, [currHcoId, trend]);

  /* ---------- VIALS (DATE-BASED) ---------- */
  const weeklyCumulativeData = useMemo(() => {
    const limit = timePeriod === "C4W" ? 4 : timePeriod === "C13W" ? 13 : qtdWeeks;
    const activeKeys = WEEK_KEYS.slice(-limit);
    const startOfThisWeek = getStartOfWeekSafe(new Date());
    let runningTotal = 0;

    return activeKeys.map((key, index) => {
      const weeklySum = hcoFilteredRows.reduce((s, r) => s + Number(r[key]?.value ?? 0), 0);
      runningTotal += weeklySum;
      const weekDate = new Date(startOfThisWeek);
      weekDate.setDate(startOfThisWeek.getDate() - (limit - 1 - index) * 7);

      return {
        label: formatMMDDYYYY(weekDate),
        value: Number(runningTotal.toFixed(1)),
      };
    });
  }, [timePeriod, hcoFilteredRows, qtdWeeks]);

  /* ---------- GROWTH (DATE-BASED LABELS) ---------- */
  const growthComparisonData = useMemo(() => {
    if (!territory || territory.length === 0) return [];
  
    const t = territory[0];
    if (!t) return [];
    
    const prevLabel = timePeriod === "QTD" ? "PQTD" : `P${timePeriod.slice(1)}`;
    const startOfThisWeek = getStartOfWeekSafe(new Date());

    // Calculate dates for the two bars in Growth mode to maintain MM/DD/YYYY
    const currentDate = new Date(startOfThisWeek);
    const prevDate = new Date(startOfThisWeek);
    prevDate.setDate(startOfThisWeek.getDate() - 7); // Representative date for previous period

    return [
      { 
        label: formatMMDDYYYY(prevDate), // Changed from text label to MM/DD/YYYY
        value: t[`REG_LIBTAYO_${prevLabel}_Volume__c`]?.value ?? 0, 
        isPrev: true 
      },
      { 
        label: formatMMDDYYYY(currentDate), // Changed from text label to MM/DD/YYYY
        value: t[`REG_LIBTAYO_${timePeriod}_Volume__c`]?.value ?? 0, 
        isPrev: false 
      },
    ];
  }, [timePeriod, territory]);

  const chartData = mode === "GROWTH" ? growthComparisonData : weeklyCumulativeData;

  return (
    <div className=" relative w-[35%] h-full bg-white border border-[#D8DDE6] rounded-[6px] shadow-md p-3 flex flex-col">
        
        <div className="text-[1rem] font-bold text-gray-700 text-center mt-1 tracking-tight">
          Vials and Growth
        </div>

        <div className="absolute top-5 right-5  flex gap-3 text-[0.7rem] font-bold text-[#54698D]">
          <label className="flex items-center gap-1 cursor-pointer hover:text-[#0070D2]">
            <input
              type="radio"
              className="accent-[#0070D2] w-3 h-3"
              checked={mode === "VIALS"}
              onChange={() => setMode("VIALS")}
            />
            Vials
          </label>
          <label className="flex items-center gap-1 cursor-pointer hover:text-[#0070D2]">
            <input
              type="radio"
              className="accent-[#0070D2] w-3 h-3"
              checked={mode === "GROWTH"}
              onChange={() => setMode("GROWTH")}
            />
            Growth
          </label>
        </div>

        <div className="flex-1 mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 0, right: 10, left: 0, bottom: 20 }}>
              <CartesianGrid stroke="#d3d4d7ff" vertical={false} />
              <XAxis
                dataKey="label"
                interval={0}
                angle={-35}
                textAnchor="end"
                tick={{ fontSize: 10, fill: "#747474ff", fontWeight: 600 }}
                tickLine={false}
                axisLine={{ stroke: "#898a8cff" }}
              />
              <YAxis
                width={60} // Crucial: Provides space for the Label
                tick={{ fontSize: 11, fill: "#343536ff" }}
                axisLine={false}
                tickLine={false}
              >
                {/* Fixed Y-Axis Label Logic */}
                <Label
                  value="Vials Ordered"
                  angle={-90}
                  position="insideLeft"
                  offset={9}
                  style={{
                    textAnchor: "middle",
                    fill: "#5b5c5eff",
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                />
              </YAxis>
              <Bar
                dataKey="value"
                barSize={mode === "GROWTH" ? 50 : 35}
                
                // radius={[3, 3, 0, 0]}
              >
                <LabelList
                  dataKey="value"
                  position="center"
                  formatter={(v) => Math.round(v)}
                  angle={-90}
                  style={{
                    fill: "#FFFFFF",
                    fontSize: 11,
                    fontWeight: 700,
                    pointerEvents: "none"
                  }}
                />
                {chartData.map((entry, index) => (
                  <Cell key={index} fill= "#556ea1ff" />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      
    </div>
  );
}