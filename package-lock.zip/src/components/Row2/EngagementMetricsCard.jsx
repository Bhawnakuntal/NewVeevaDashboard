import { useMemo } from "react";
import { useDashboard } from "../../context/DashboardContext";

/* CONSTANTS */
const CHANNELS = [
  { key: "Live Calls", color: "#6e0f56" },
  { key: "Virtual Calls", color: "#F4A6B8" },
  { key: "RTEs", color: "#3030ff" },
  { key: "Speaker Programs", color: "#1E88E5" },
  { key: "Lunch & Learn", color: "#4FC3F7" },
];

const WEEK_KEYS = [
  "REG_CW_Minus_12_Engagements__c", "REG_CW_Minus_11_Engagements__c",
  "REG_CW_Minus_10_Engagements__c", "REG_CW_Minus_9_Engagements__c",
  "REG_CW_Minus_8_Engagements__c", "REG_CW_Minus_7_Engagements__c",
  "REG_CW_Minus_6_Engagements__c", "REG_CW_Minus_5_Engagements__c",
  "REG_CW_Minus_4_Engagements__c", "REG_CW_Minus_3_Engagements__c",
  "REG_CW_Minus_2_Engagements__c", "REG_CW_Minus_1_Engagements__c",
  "REG_CW_Engagements__c",
];

export default function EngagementMetricsCard() {
  const { timePeriod, currHcoId, qtdWeeks, engagement} = useDashboard();

  const hcoRows = useMemo(() => {
  // Ensure engagement exists and is an array before filtering
    if (!engagement || !Array.isArray(engagement)) return [];
    if (!currHcoId || currHcoId === "null") return engagement;
    return engagement.filter(r => r.REG_HCO_Account__c?.value === currHcoId);
  }, [currHcoId, engagement]);

  const activeWeekCount = useMemo(() => { 
    if (timePeriod === "C4W") return 4;
    if (timePeriod === "C13W") return 13; 
    return qtdWeeks; 
  }, [timePeriod, qtdWeeks]); 
  
  const activeWeekKeys = WEEK_KEYS.slice(-activeWeekCount);

  const gridData = useMemo(() => {
    return CHANNELS.map(channel => {
      const channelRow = hcoRows.find(r => r.REG_Channel__c?.value === channel.key);
      const weeks = activeWeekKeys.map(key => Number(channelRow?.[key]?.value ?? 0));
      return { channel: channel.key, color: channel.color, weeks };
    });
  }, [hcoRows, activeWeekKeys]);

  const weekLabels = useMemo(() => {
    const today = new Date();
    return activeWeekKeys.map((_, i) => {
      const d = new Date(today);
      d.setDate(today.getDate() - (activeWeekCount - 1 - i) * 7);
      // Format to MM/DD/YY as requested
      return `${(d.getMonth() + 1).toString().padStart(2, '0')}/${d.getDate().toString().padStart(2, '0')}/${d.getFullYear().toString().padStart(4, '0')}`;
    });
  }, [activeWeekCount, activeWeekKeys]);

  const GRID_STYLE = {
    display: 'grid',
    gridTemplateColumns: `100px repeat(${activeWeekCount}, 1fr)`,
    alignItems: 'center',
    width: '100%'
  };

  return (
    <div className="w-[34%] h-full bg-white border border-[#D8DDE6] rounded-[5px] shadow-md pl-3 pr-3 pt-3 flex flex-col overflow-hidden">
      
      {/* HEADER */}
      <div className="text-[1rem] font-bold text-gray-700 text-center mb-2 tracking-tight">
        {timePeriod} Engagement Metrics
      </div>

     
        <div className="text-[0.76rem] font-bold text-gray-600 uppercase mb-4 pl-5 pt-3">
          Engagement Timeline
        </div>

        {/* TIMELINE ROWS */}
        <div className="flex-1 flex flex-col justify-around ">
          {gridData.map(row => (
            <div key={row.channel} style={GRID_STYLE} className="h-6">
              <div className="text-[0.7rem] font-bold text-gray-500 pr-2 text-right truncate">
                {row.channel}
              </div>

              <div className="relative flex items-center h-full col-span-full" style={{ gridColumn: `2 / span ${activeWeekCount}` }}>
                <div className="absolute w-full h-[1px] bg-gray-300 z-0" />
                <div className="w-full h-full flex justify-around items-center z-10">
                  {row.weeks.map((val, i) => (
                    <div key={i} className="flex-1 flex justify-center items-center">
                      {val > 0 && (
                        <div 
                          className="w-[0.6rem] h-[0.6rem] rounded-full border border-white shadow-sm" 
                          style={{ backgroundColor: row.color }} 
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* X-AXIS LABELS - FIXING RESPONSIVENESS */}
        <div className="mt-1 border-t border-gray-300 pt-5 pr-5 vw-10" style={GRID_STYLE}>
          <div /> 
          <div 
            className="col-span-full flex justify-around min-h-[45px]" 
            style={{ gridColumn: `2 / span ${activeWeekCount}` }}
          >
            {weekLabels.map((date, i) => (
              <div key={i} className="flex-1 flex justify-center relative">
                {/* Tick Mark */}
                <div className="absolute top-0 w-px h-1 bg-[#D8DDE6]" />
                
                <span className="
                  absolute
                  top-2
                  text-[66%] 
                  font-semibold 
                  text-gray-500 
                  whitespace-nowrap 
                  -rotate-[35deg] 
                  origin-left
                  leading-none
                ">
                  {date}
                </span>
              </div>
            ))}
          </div>
        </div>
      
    </div>
  );
}