import { useMemo } from "react";
import { useDashboard } from "../../context/DashboardContext";

/* ================= CONSTANTS ================= */
const GRID_COLS = "grid-cols-[40%_25%_30%]";
const ROW_HEIGHT = "h-[3.1rem]"; 

export default function Top5payersTable() {
  const { timePeriod, payers, currHcoId } = useDashboard();

  /* ---------- 1. DATA PROCESSING (No Filter Mode) ---------- */
  const topPayers = useMemo(() => {
    if (!payers || !Array.isArray(payers)) return [];
    const volumeKey = `REG_${timePeriod}_Libtayo_Vials__c`;

    let filteredData = payers;
    if (currHcoId !== "null") {
      filteredData = payers.filter(r => r.REG_Account__c?.value === currHcoId);
    }

    if (filteredData.length === 0) return [];

    // 3. Map, Sort, and Slice
    return [...filteredData]
      .sort((a, b) => (b[volumeKey]?.value || 0) - (a[volumeKey]?.value || 0))
      .slice(0, 5) 
      .map(payers => ({
        name: payers.REG_Payer__c?.value || "Unknown",
        channel: payers.REG_Payer_Channel__c?.value || "N/A",
        vials: payers[volumeKey]?.value || 0
      }));
  }, [timePeriod, payers, currHcoId]);

  return (
    <div className="w-[34%] bg-white border border-[#D8DDE6] rounded-[4px] p-2 shadow-md h-full flex flex-col overflow-hidden">
      
      {/* ================= HEADER ================= */}
      <div className="flex items-center justify-center mb-2 border-b border-gray-100 pb-1 flex-shrink-0">
        <div className="text-[1rem] font-bold text-gray-700 tracking-tight">
          {timePeriod} Top 5 payers
        </div>
      </div>

      {/* ================= DATA TABLE ================= */}
      <div className="flex-1 flex flex-col border border-[#D8DDE6] rounded-t overflow-hidden mt-1">
        
        {/* ---- TABLE HEADER ---- */}
        <div className={`grid ${GRID_COLS} bg-[#44546A] text-white text-[0.8rem] px-3 h-[3rem] items-center font-bold`}>
          <div>payers</div>
          <div>Channel</div>
          <div className="text-right">Libtayo Vials</div>
        </div>

        {/* ---- TABLE BODY (Responsive Fill) ---- */}
        <div className="flex-1 flex flex-col justify-between overflow-hidden">
          {topPayers.map((payers, idx) => (
            <div
              key={`${payers.name}-${idx}`}
              className={`grid ${GRID_COLS} ${ROW_HEIGHT} px-3 flex-1 px-2 items-center text-[0.7rem] border-b border-[#EEF1F6] last:border-0`}
            >
              {/* payers Name */}
              <div className="font-semibold text-black truncate pr-2">
                {payers.name}
              </div>

              {/* Channel Badge (Figma Style) */}
              <div className="flex items-center font-semibold text-black">
                
                  {payers.channel}
                
              </div>

              {/* Vials Volume */}
              <div className="text-right font-semibold text-black">
                {payers.vials.toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}