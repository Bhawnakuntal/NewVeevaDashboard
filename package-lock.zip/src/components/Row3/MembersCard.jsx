import { useState } from "react";
import { FiMaximize2, FiX } from "react-icons/fi";

/* HARD CODED DATA */
const HCP_DATA = [
  { name: "John Smith", specialty: "Oncology", hco: "John Smith Hospital", phone: "312-969-8989" },
  { name: "John Walter", specialty: "Oncology", hco: "John Smith Hospital", phone: "912-585-2525" },
  { name: "Rick Jones", specialty: "Oncology", hco: "John Smith Hospital", phone: "414-858-8574" },
];

const MULTISITE_DATA = [
  { name: "John Smith Hospital", address: "1 Main St, Houston TX", phone: "312-969-8989" },
  { name: "John Smith Hospital", address: "1 Avery St, Dallas TX", phone: "912-585-2525" },
];

const TEAM_DATA = [
  { territory: "RR1050002", desc: "Raleigh, NC", user: "Catherine Armstrong", phone: "224-443-0523" },
  { territory: "OM4030001", desc: "Raleigh, NC", user: "Kennith Mann", phone: "919-259-8494" },
  { territory: "OD3060003", desc: "Charlotte, NC", user: "Raymond Flowers", phone: "704-713-4384" },
  { territory: "OD3060002", desc: "Raleigh, NC", user: "Lindsay Gomoll", phone: "(984) 268-3411" },
];

export default function MembersCard() {
  const [expanded, setExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState("HCP");

  /* SUB-COMPONENTS */
  function TabButton({ label, count, activeTab, setActiveTab }) {
    return (
      <div
        onClick={() => setActiveTab(label)}
        className={`w-full max-w-[170px] py-2 border-gray-900 rounded-md text-center cursor-pointer transition-all duration-200 font-sans ${
          activeTab === label
            ? "bg-[#0B95FF] text-white border-[#0B95FF] shadow-sm"
            : "bg-gray-300 border-[1px] border-gray-900 text-[#444] hover:bg-[#DADADA]"
        }`}
      >
        <div className="text-[clamp(1rem,1.5vw,1.4rem)] font-bold leading-tight">{count}</div>
        <div className="text-[clamp(0.7rem,1vw,1rem)] font-semibold">{label}</div>
      </div>
    );
  }

  const renderTable = () => {
    const dataMap = { HCP: HCP_DATA, Multisite: MULTISITE_DATA, Team: TEAM_DATA };
    const currentData = dataMap[activeTab] || TEAM_DATA;

    return (
      <div className="w-full overflow-x-auto font-sans">
        <table className="w-full border-2 border-black mt-6 min-w-[600px]">
          <thead className="bg-[#6B7C99] text-white border-b-2 border-black">
            <tr className="text-[clamp(0.8rem,1.1vw,1.1rem)]">
              {activeTab === "HCP" && <><th className="p-4 text-left">HCP Name</th><th className="p-4 text-left">Speciality</th><th className="p-4 text-left">Affiliated HCO</th><th className="p-4 text-left">Contact Number</th></>}
              {activeTab === "Multisite" && <><th className="p-4 text-left">Account Name</th><th className="p-4 text-left">Address</th><th className="p-4 text-left">Contact Number</th></>}
              {activeTab === "Team" && <><th className="p-4 text-left">Territory Name</th><th className="p-4 text-left">Description</th><th className="p-4 text-left">User Name</th><th className="p-4 text-left">Phone Number</th></>}
            </tr>
          </thead>
          <tbody>
            {currentData.map((r, i) => (
              <tr key={i} className="odd:bg-[#D6DBE0] even:bg-[#ECEFF2] hover:bg-[#C9D3E3] text-[clamp(0.75rem,1vw,1rem)] font-bold text-gray-600 border-b border-black last:border-0">
                {Object.values(r).map((val, idx) => (
                  <td key={idx} className="p-5 whitespace-nowrap">{val}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <>
      {/* DASHBOARD CARD */}
      {!expanded && (
        <div className="relative w-[34%] h-full bg-white border border-[#D8DDE6] rounded-[6px] shadow-md pt-3 px-4 flex flex-col font-sans overflow-hidden">
          
            <div className="w-full text-center">
              <span className="font-bold text-gray-700 text-[1.1rem] tracking-tight">Members</span>
            </div>

            <FiMaximize2
              className="absolute top-4 right-5 text-[1.2rem] text-gray-600 cursor-pointer hover:text-[#0070D2] transition"
              onClick={() => setExpanded(true)}
            />

            {/*Changed from absolute to flex-1 with center alignment for iPad responsiveness */}
            <div className="flex-1 flex items-center justify-around gap-2 w-full text-center">
              <div className="flex flex-col items-center">
                <span className="text-[1.5rem] font-bold text-gray-600 leading-tight">3</span>
                <span className="text-[1.2rem] text-gray-500 font-medium text-center leading-tight">See List of <br/> HCPs</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-[1.5rem] font-bold text-gray-600 leading-tight">2</span>
                <span className="text-[1.2rem] font-medium text-gray-500 text-center leading-tight">Multisite</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-[1.5rem] font-bold text-gray-600 leading-tight">4</span>
                <span className="text-[1.2rem] font-medium text-gray-500 text-center leading-tight">Regeneron <br/> Teammates</span>
              </div>
            </div>
          
        </div>
      )}

      {/* MODAL VIEW */}
      {expanded && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#080707]/50 backdrop-blur-sm p-4 font-sans">
          <div className="relative w-full max-w-[1200px] h-[90vh] bg-white rounded-[14px] border border-[#A8B3C7] shadow-2xl p-4 md:p-6 overflow-hidden flex flex-col">
            <div className="flex-1 border-[2px] border-gray-400 rounded-[28px] bg-[#FAFBFC] relative flex flex-col py-4 px-6 overflow-hidden">
              <FiX className="absolute top-5 right-5 text-gray-700 text-[1.8rem] cursor-pointer hover:text-red-500 transition" onClick={() => setExpanded(false)} />
              
              <div className="text-center text-[clamp(1.2rem,1.6vw,1.8rem)] font-bold text-gray-600 mb-6 uppercase">Members</div>
              
              <div className="flex flex-wrap justify-center gap-3 md:gap-6 mb-6">
                <TabButton label="HCP" count={3} activeTab={activeTab} setActiveTab={setActiveTab} />
                <TabButton label="Multisite" count={2} activeTab={activeTab} setActiveTab={setActiveTab} />
                <TabButton label="Regeneron Teammates" count={4} activeTab={activeTab} setActiveTab={setActiveTab}/>
              </div>
              
              <div className="border-t border-[#D8DDE6] mb-4" />
              <div className="flex-1 overflow-y-auto overflow-x-hidden">
                {renderTable()}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}