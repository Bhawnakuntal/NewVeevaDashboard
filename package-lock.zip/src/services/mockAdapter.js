// Import all your mock JSON files
import engagementData from "../data/REG_ONC_HCO_Engagement_metrics.json";
import patientShareData from "../data/REG_ONC_HCO_Patient_Share.json";
import trendData from "../data/REG_ONC_HCO_LIBTAYO_Weekly_trend.json";
import territoryData from "../data/REG_ONC_LIBTAYO_HCO_Territory_Detail.json";
import competitorShareData from "../data/REG_ONC_HCO_Competitor_Patient_Share.json";
import payerData from "../data/REG_ONC_HCO_Top_Payers.json";

const mockAdapter = {
  runQuery: (config) => {
    return new Promise((resolve, reject) => {
      let data = [];
      const { object } = config;

      // Simple routing based on object name
      switch (object) {
        case "REG_ONC_HCO_Patient_Share":
          data = patientShareData;
          break;
        case "REG_ONC_HCO_Competitor_Patient_Share__c":
          data = competitorShareData;
          break;
        case "REG_ONC_HCO_Engagement_metrics__c":
          data = engagementData;
          break;
        case "REG_ONC_HCO_LIBTAYO_Weekly_trend__c":
          data = trendData;
          break;
        case "REG_ONC_LIBTAYO_HCO_Territory_Detail":
          data = territoryData;
          break;
        case "REG_ONC_HCO_Top_Payers__c":
          data = payerData;
          break;
        default:
          console.warn(`Mock data not found for object: ${object}`);
          data = [];
      }

      resolve({
        success: true,
        data: data,
        message: "Mock data returned",
      });
    });
  },
  getDataForCurrentObject: (objectName, fieldName) => {
    return Promise.resolve({
      Account: {
        Id: "808623be-fa43-4554-b34e-e1e647d0bb24", // Mock Account ID
      },
    });
  },
};

export const getDS = () => {
  console.log("getDS()");
  return window.location.hostname === "localhost" ? mockAdapter : window.ds;
};

export default mockAdapter;
